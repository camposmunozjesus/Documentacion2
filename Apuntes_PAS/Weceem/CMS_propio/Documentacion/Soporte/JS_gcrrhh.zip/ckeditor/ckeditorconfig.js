/**
 * @license Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.html or http://ckeditor.com/license
 */

CKEDITOR.editorConfig = function( config ) {
	// Define changes to default configuration here. For example:
	 config.language = 'ca';
//	 config.uiColor = '#AADC6E';
//	 config.uiColor="red";
//	 config.uploadBasedir = "../rrhh_resources/jesus/";
	 config.allowedContent=true
	 config.extraAllowedContent = '*(*)';
	 
	 config.contentsCss = "/gcrrhh/css/contents.css"
	 
	 //config.extraPlugins = 'divDspl,listInDspl';
	 
	 config.toolbar = 'Editor';
	 
	 config.toolbar_Editor = [
//		 config.toolbar =  [
	         { name: 'document', items : [ 'Source','-','Save','NewPage','DocProps','Print'] },
  		 	 { name: 'clipboard', items : [ 'Cut','Copy','Paste','PasteText','PasteFromWord','-','Undo','Redo' ] },
 		 	 { name: 'editing', items : [ 'Find','Replace','-','SelectAll','-','SpellChecker', 'Scayt' ] },
 		 	 { name: 'forms', items : [ 'Form', 'Checkbox', 'Radio', 'TextField', 'Textarea', 'Select', 'Button', 'ImageButton', 
 		         'HiddenField' ] },
 		 	 '/',
 		 	 { name: 'basicstyles', items : [ 'Bold','Italic','Underline','Strike','Subscript','Superscript','-','RemoveFormat' ] },
 		 	 { name: 'paragraph', items : [ 'NumberedList','BulletedList','-','Outdent','Indent','-','Blockquote','CreateDiv',
 		 	 '-','JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock','-','BidiLtr','BidiRtl' ] },
 		 	 { name: 'links', items : [ 'Link','Unlink','Anchor' ] },
 		 	 { name: 'insert', items : [ 'Image','Flash','Table','HorizontalRule','Smiley','SpecialChar','PageBreak','Iframe' ] },
 		 	 '/',
 		 	 { name: 'styles', items : [ 'Styles','Format','Font','FontSize' ] },
 		 	 { name: 'colors', items : [ 'TextColor','BGColor' ] },
 		 	 { name: 'tools', items : [ 'Maximize', 'ShowBlocks'] },
 		 	 { name: 'tools', items : [ 'About'] },
 		 	 //'/',
 		 	 //{ name: 'fitxes', items : [ 'DivDspl', '-', 'ListInDspl'] }
	];
		

	config.indentOffset = 5;
	
	
	//Configuración Codemirror para CKeditor ---> Edición de código con el botón "Codi font"
	config.extraPlugins = 'codemirror';

	config.codemirror = {
		theme: 'default',
		lineNumbers: true,
		lineWrapping: true,
		matchBrackets: true,
		autoCloseTags: true,
		autoCloseBrackets: true,
		enableSearchTools: true, // Whether or not to enable search tools, CTRL+F (Find), CTRL+SHIFT+F (Replace), CTRL+SHIFT+R (Replace All), CTRL+G (Find Next), CTRL+SHIFT+G (Find Previous)
		enableCodeFolding: true,
		enableCodeFormatting: true,
		autoFormatOnStart: true,
		autoFormatOnUncomment: true,
		highlightActiveLine: true,
		highlightMatches: true,
		showFormatButton: true,
		showCommentButton: true,
		showUncommentButton: true
	};
};

//Permite la indentación cuando se envía el texto al controlador, de este modo en el TextArea GSP se ve bien.
CKEDITOR.on( 'instanceReady', function( ev ) {
	
	var blockTags = ['div'];
	
	var rules = {
		indent : true,
		breakBeforeOpen : true,
		breakAfterOpen : false,
		breakBeforeClose : true,
		breakAfterClose : true
	};
	
	for (var i=0; i<blockTags.length; i++) {
		ev.editor.dataProcessor.writer.setRules( blockTags[i], rules );
	}
	
	//
	blockTags = ['p', 'span'];strong
	
	rules = {
		indent : true,
		breakBeforeOpen : true,
		breakAfterOpen : false,
		breakBeforeClose : false,
		breakAfterClose : true
	};
	
	for (var i=0; i<blockTags.length; i++) {
		ev.editor.dataProcessor.writer.setRules( blockTags[i], rules );
	}
	
	//	
	blockTags = ['strong'];
	
	rules = {
		indent : false,
		breakBeforeOpen : false,
		breakAfterOpen : false,
		breakBeforeClose : false,
		breakAfterClose : false
	};
	
	for (var i=0; i<blockTags.length; i++) {
		ev.editor.dataProcessor.writer.setRules( blockTags[i], rules );
	}
});