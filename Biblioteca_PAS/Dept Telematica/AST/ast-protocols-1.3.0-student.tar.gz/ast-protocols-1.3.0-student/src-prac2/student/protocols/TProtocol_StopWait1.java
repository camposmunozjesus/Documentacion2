
package student.protocols;

import ast.protocols.transportCO.TProtocol;
import ast.protocols.transportCO.TCBlock;
import ast.protocols.tcp.TCPSegment;

import ast.util.CircularQueue;
import ast.util.ByteQueue;

import java.io.IOException;


/**
 * Connection oriented, stop and wait.
 * We assume an ideal IP layer with no losses and no errors in packets.
 *
 * State diagram:<pre>
                              +---------+
                              |  CLOSED |-------------
                              +---------+             \
                           LISTEN  |                   \
                           ------  |                    | CONNECT
                                   V                    | -------
                              +---------+               | snd SYN
                              |  LISTEN |               |
                              +---------+          +----------+
                                   |               | SYN_SENT |
                                   |               +----------+
                         rcv SYN   |                    |
                         -------   |                    | rcv SYN
                         snd SYN   |                    | -------
                                   |                    |
                                   V                   /
                              +---------+             /
                              |  ESTAB  |<------------
                              +---------+
                       CLOSE    |     |    rcv FIN
                      -------   |     |    -------
 +---------+          snd FIN  /       \                    +---------+
 |  FIN    |<-----------------           ------------------>|  CLOSE  |
 |  WAIT   |------------------           -------------------|  WAIT   |
 +---------+          rcv FIN  \       /   CLOSE            +---------+
                      -------   |      |  -------
                                |      |  snd FIN 
                                V      V
                              +----------+
                              |  CLOSED  |
                              +----------+
 * </pre>
 */
public class TProtocol_StopWait1 extends TProtocol {

    @Override
    protected TCBlock newTCB(int port) {
        return new TCBlock_StopWait1(this, port);
    }

    @Override
    public int getProtoNum() {
        return 202;
    }    

}


class TCBlock_StopWait1 extends TCBlock {
    protected int state;
    protected CircularQueue<TCBlock_StopWait1> acceptQueue;

    // States of FSM (see description in TProtocol_StopWait1):
    protected final static int CLOSED = 0,
                               LISTEN = 1,
                               SYN_SENT = 2,
                               ESTABLISHED = 3,
                               FIN_WAIT = 4,
                               CLOSE_WAIT = 5;

    // Sender variables:
    protected int sndMSS;        // Send maximum segment size
    protected boolean sndIsUna; // (true when bytes in (2))
        /* 1: Transmitted and acknowledged bytes
           2: Transmitted but not yet acknowledged bytes
                   1       2
              ----------+------+---------
                        :      first byte not yet transmitted
                        first transmitted byte not yet acknowledged
         */
    // Receiver variables:
    protected ByteQueue rcvQueue;

    TCBlock_StopWait1(TProtocol proto, int port) {
        super(proto, port);
    }

    // Passive open
    @Override
    public void listen(int backlog) throws IOException {
      lk.lock();
      try {
        log.debug("%1$s->listen()", this);
        if (state != CLOSED) {
            throw new IOException("connection already exists");
        }
        acceptQueue = new CircularQueue<TCBlock_StopWait1>(backlog);
        state = LISTEN;
        addListenTCB(this);
        logDebugState();
      } finally {
        lk.unlock();
      }
    }

    @Override
    public TCBlock accept() throws IOException {
      lk.lock();
      try {
        log.debug("%1$s->accept()", this);
        if (state != LISTEN) {
            throw new IOException("connection is not LISTEN");
        }
        try {
            while (acceptQueue.empty()) appCV.await(); //wait some client to connect to me
        } catch (InterruptedException ie) {
            log.warn("Interrupted Exception at accept()");
        }
        TCBlock_StopWait1 r = acceptQueue.get();
        log.debug("%1$s->accepted", this);
        return r;
      } finally {
        lk.unlock();
      }
    }

    // Active open
    @Override
    public void connect(int addr, int port) throws IOException {
      lk.lock();
      try {
        log.debug("%1$s->connect()", this);
        if (state != CLOSED) {
            throw new IOException("connection already exists");
        }
        initActive(addr, port & 0xffff, SYN_SENT);
        TCPSegment sseg = new TCPSegment();
        sseg.setSourcePort(localPort);
        sseg.setDestinationPort(remotePort);
        sseg.setFlags(TCPSegment.SYN);
        sendSegment(sseg);
        logDebugState();
        try {
            while (state != ESTABLISHED) appCV.await(); //wait SYN is received
        } catch (InterruptedException ie) {
            log.warn("Interrupted Exception in connect()");
        }
        log.debug("%1$s->connected", this);
      } finally {
        lk.unlock();
      }
    }

    // initialize for new connection
    protected void initActive(int remAddr, int remPort, int st) {
        remoteAddr = remAddr;
        remotePort = remPort;
        state = st;
        sndMSS = ipLayer.getMMS(remoteAddr) - 20; // IP message size (IP packet size - IP header size) - 20(TCP header size)
        rcvQueue = new ByteQueue(sndMSS);
        sndIsUna = false;
        addActiveTCB(this);
    }

    @Override
    public void close() throws IOException {
        lk.lock();
        try {
          log.debug("%1$s->close()", this);
          switch (state) {
            case LISTEN: {
                state = CLOSED;
                removeListenTCB(this);
                logDebugState();
                break;
            }
            case ESTABLISHED:
            case CLOSE_WAIT: {
                // Wait all data is sended and acknowleged
                while (sndIsUna) {
                    try { appCV.await();
                    } catch (InterruptedException ie) {
                        log.warn("Interrupted exception in close()");
                    }
                }
                TCPSegment sseg = new TCPSegment();
                sseg.setSourcePort(localPort);
                sseg.setDestinationPort(remotePort);
                sseg.setFlags(TCPSegment.FIN);
                sendSegment(sseg);
                if (state == ESTABLISHED) {
                    state = FIN_WAIT;
                } else {
                    state = CLOSED;
                    removeActiveTCB(this);
                }
                logDebugState();
                break;
            }
            default:
                throw new IOException("connection does not exist");
          }
        } finally {
            lk.unlock();
        }
    }

    @Override
    public void sendData(byte[] data, int data_off, int data_len) throws IOException {
        lk.lock();
        try {
            log.debug("%1$s->sendData(length=%2$d)", this, data_len);
            int n = 0;
            while (data_len > n) {
                if (state != ESTABLISHED && state != CLOSE_WAIT) {
                    // transmission is closed
                    throw new IOException("connection does not exist");
                }
                while (sndIsUna) {  // wait sender is not expecting an acknowledg
                    try { appCV.await();
                    } catch (InterruptedException ie) {
                        log.warn("Interrupted exception in sendData()");
                    }
                }
                int seglen = data_len - n;
                if (seglen > sndMSS) seglen = sndMSS;
                // seglen == min(data_len - n, sndMSS)
                byte[] segdata = new byte[seglen];
                System.arraycopy(data, data_off + n, segdata, 0, seglen);
                TCPSegment segment = new TCPSegment();
                    segment.setSourcePort(localPort);
                    segment.setDestinationPort(remotePort);
                    segment.setFlags(TCPSegment.PSH);
                    segment.setData(segdata, 0, seglen);
                sendSegment(segment);
                sndIsUna = true;
                n += seglen;
                logDebugState();
            }
        } finally {
            lk.unlock();
        }
    }

    @Override
    protected void processReceivedSegment(int sourceAddr, TCPSegment rseg) {
        lk.lock();
        try{
            switch (state) {
            case LISTEN: {
                if (rseg.isAck()) {
                    // Any acknowledgment is bad if it arrives on a connection still in
                    // the LISTEN state. Ignore it
                    return;
                }
                if (rseg.isSyn()) {
                    if (acceptQueue.full()) {
                        log.warn(
                          "%1$s->processReceivedSegment: Backlog queue is full. SYN IS LOST !!!",
                          this);
                        return;
                    }
                    // create TCB for new connection
                    TCBlock_StopWait1 ntcb = (TCBlock_StopWait1) newTCB();
                    ntcb.initActive(sourceAddr, rseg.getSourcePort(), ESTABLISHED);
                    // To be completed by the student:
                    throw new RuntimeException("NOT YET IMPLEMENTED (To be completed by the student)");
                    // prepare the created connection for accept
                    //...
                    // send SYN segment for new connection
                    //...
                    ntcb.logDebugState();
                }
                break;
            }
            case SYN_SENT: {
                if (rseg.isSyn()) {
                    // To be completed by the student:
                    throw new RuntimeException("NOT YET IMPLEMENTED (To be completed by the student)");
                    // Change state and wake up connect() thread
                    //...
                    logDebugState();
                }
                break;
            }
            case ESTABLISHED:
            case FIN_WAIT:
            case CLOSE_WAIT: {
                // Check SYN bit
                if (rseg.isSyn()) {
                    // A SYN is bad if it arrives on a connection in an active state. Ignore it
                    return;
                }
                // Check ACK
                if (rseg.isAck()) {
                    // To be completed by the student:
                    throw new RuntimeException("NOT YET IMPLEMENTED (To be completed by the student)");
                    // change sndIsUna accordingly, etc.
                    //...
                    logDebugState();
                }
                // Process segment text
                if (rseg.getDataLength() > 0) {
                    if (state == ESTABLISHED || state == FIN_WAIT) {
                        // To be completed by the student:
                        throw new RuntimeException("NOT YET IMPLEMENTED (To be completed by the student)");
                        logDebugState(); 
                    } else {
                        // This should not occur, since a FIN has been received from the
                        // remote side.  Ignore the segment text.
                    }
                }
                // Check FIN bit
                if (rseg.isFin()) {
                    if (state == ESTABLISHED) {
                        state = CLOSE_WAIT;
                    } else if (state == FIN_WAIT) {
                        state = CLOSED;
                        removeActiveTCB(this);
                    }
                    appCV.signalAll(); // wake up receiveData() thread
                    logDebugState();
                }
                break;
            }
            default:
                // Segment is ignored
            }
        } finally {
            lk.unlock();
        }
    }

    @Override
    public int receiveData(byte[] buf, int off, int len) throws IOException {
        lk.lock();
        try {
            log.debug("%1$s->receiveData()", this);
            if (state == ESTABLISHED || state == FIN_WAIT) {
            } else if (state == CLOSE_WAIT && rcvQueue.empty()) {
                throw new IOException("connection closing");
            } else {
                throw new IOException("connection does not exist");
            }
            assert state == ESTABLISHED || state == FIN_WAIT
                   || (state == CLOSE_WAIT && !rcvQueue.empty());
            // wait until receive buffer is not empty
            while (rcvQueue.empty() && !(state == CLOSE_WAIT || state == CLOSED)) {
                try { appCV.await(); } catch (InterruptedException e) {}
            }
            assert !rcvQueue.empty() || state == CLOSE_WAIT || state == CLOSED;
            if (rcvQueue.empty()) {
                // remote endpoint is closed (state is CLOSE_WAIT or CLOSED)
                return -1;
            } else {
                // To be completed by the student:
                throw new RuntimeException("NOT YET IMPLEMENTED (To be completed by the student)");
                // get data from receive queue and decide when to send an ACK
                //...
            }
        } finally {
            lk.unlock();
        }
    }

    protected void logDebugState() {
        if (log.debugEnabled()) {
            log.debug("%1$s=> state: %2$s", this, stateToString());
        }
    }

    public String stateToString() {
        StringBuilder buf = new StringBuilder();
        String sst;
        switch (state) {
            case CLOSED:      sst = "CLOSED"; break;
            case LISTEN:      sst = "LISTEN"; break;
            case SYN_SENT:    sst = "SYN_SENT"; break;
            case ESTABLISHED: sst = "ESTABLISHED"; break;
            case FIN_WAIT:    sst = "FIN_WAIT"; break;
            case CLOSE_WAIT:  sst = "CLOSE_WAIT"; break;
            default: sst = "?";
        }
        buf.append("{").append(sst);
        if (acceptQueue != null) {
            // pasive state
            buf.append(",acceptQueue.size=").append(acceptQueue.size());
        }
        if (rcvQueue != null) {
            // active state
            buf.append(",sndIsUna=").append(sndIsUna);
            buf.append(",rcvQueue.size=").append(rcvQueue.size());
        }
        return buf.append("}").toString();
    }

}


