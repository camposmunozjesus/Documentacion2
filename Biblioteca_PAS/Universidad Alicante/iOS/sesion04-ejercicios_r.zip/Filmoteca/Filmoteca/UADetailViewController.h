//
//  UADetailViewController.h
//  Filmoteca
//
//  Created by Miguel Angel Lozano on 15/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class UAPelicula;

@interface UADetailViewController : UIViewController

@property (unsafe_unretained, nonatomic) UAPelicula *pelicula;

@property (unsafe_unretained, nonatomic) IBOutlet UILabel *labelPuntuacion;
@property (unsafe_unretained, nonatomic) IBOutlet UISlider *sliderPuntuacion;
@property (unsafe_unretained, nonatomic) IBOutlet UITextField *textoTitulo;
@property (unsafe_unretained, nonatomic) IBOutlet UITextField *textoDirector;
@property (unsafe_unretained, nonatomic) IBOutlet UISegmentedControl *segmentedCalificacion;

@property (strong, nonatomic) IBOutlet UIView *viewCartel;

- (IBAction)cerrarTeclado:(id)sender;
- (IBAction)cambiarPuntuacion:(id)sender;
- (IBAction)verCartel:(id)sender;
- (IBAction)cerrarCartel:(id)sender;
- (IBAction)guardarDatos:(id)sender;

@end
