package es.ua.jtech.ajdm.multimedia;

import java.io.IOException;

import android.app.Activity;
import android.content.Context;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;

public class EjemploVideoMP extends Activity implements SurfaceHolder.Callback {
	private MediaPlayer mediaPlayer;
	private SurfaceView superficie;
	private SurfaceHolder holder;
	private Button botonReproducir;
	private Button botonPausar;
	private Button botonParar;
	boolean pausado = false;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        botonReproducir = (Button)findViewById(R.id.iniciar);
        botonPausar = (Button)findViewById(R.id.pausar);
        botonParar = (Button)findViewById(R.id.parar);
        botonPausar.setEnabled(false);
        botonParar.setEnabled(false);
        
        mediaPlayer = new MediaPlayer(); 
        superficie = (SurfaceView)findViewById(R.id.superficie); 
        holder = superficie.getHolder(); 
        holder.addCallback(this); 
        holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS); 
    }
    
    public void surfaceCreated(SurfaceHolder holder) { 
    	try { 
    		mediaPlayer.setDisplay(holder); 
    		mediaPlayer.setDataSource("/sdcard/coche.3gp");
    		mediaPlayer.prepare();
    		mediaPlayer.setScreenOnWhilePlaying(true);
    		
    		funcionalidadBotones();
    	} catch (IllegalArgumentException e) { 
    		Log.d("MEDIA_PLAYER", e.getMessage()); 
    	} catch (IllegalStateException e) { 
    		Log.d("MEDIA_PLAYER", e.getMessage()); 
    	} catch (IOException e) {
    		Log.d("MEDIA_PLAYER", e.getMessage());
    	}
    }
    
    public void surfaceDestroyed(SurfaceHolder holder) {
    	mediaPlayer.release(); 
    } 
    
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
    	
    } 
    
    private void funcionalidadBotones() {
    	// Cuando pulsamos el botón de reproducir inicializamos el media player y comenzamos la reproducción
    	// También desactivamos el botón de reproducir y activamos los otros dos botones
    	botonReproducir.setOnClickListener(new Button.OnClickListener() {
    		public void onClick(View v) {
    			mediaPlayer.seekTo(0);
    			mediaPlayer.start();
    			
    			botonReproducir.setEnabled(false);
    			botonParar.setEnabled(true);
    			botonPausar.setEnabled(true);
    			
    			pausado = false;
    		}
    	});
    	
    	mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
			public void onCompletion(MediaPlayer mp) {
				mediaPlayer.pause();
				
				botonReproducir.setEnabled(true);
    			botonParar.setEnabled(false);
    			botonPausar.setEnabled(false);
			}
		});
    	
    	// Cuando pulsamos el botón de pausar paramos la reproducción con pause (o la iniciamos, dependiendo de si ya estaba
    	// pausada antes) y cambiamos el texto del botón. 
    	botonPausar.setOnClickListener(new Button.OnClickListener() {
    		public void onClick(View v) {
    			if (pausado) {
    				mediaPlayer.start();
    				
    				botonPausar.setText(R.string.pausar);
    			
    				pausado = false;
    			}
    			else {
    				mediaPlayer.pause();
    				
    				botonPausar.setText(R.string.reiniciar);
    				
    				pausado = true;
    			}
    		}
    	});
    	
    	// Cuando pulsamos el botón de parar paramos la reproducción y liberamos el media player
    	// También desactivamos el botón de parar y de pausa y activamos el de reproducir
    	botonParar.setOnClickListener(new Button.OnClickListener() {
    		public void onClick(View v) {
    			mediaPlayer.pause();
    			
    			botonReproducir.setEnabled(true);
    			botonParar.setEnabled(false);
    			botonPausar.setEnabled(false);
    			
    			if (pausado) {
    				botonPausar.setText(R.string.pausar);
    			}
    		}
    	});
    }
}