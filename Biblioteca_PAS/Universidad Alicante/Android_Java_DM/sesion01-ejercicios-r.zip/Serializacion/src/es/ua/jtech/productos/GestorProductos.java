package es.ua.jtech.productos;

import java.util.*;
import java.io.*;

public class GestorProductos {

	private final static String FICHERO_DATOS = "prod.dat";

	private List<ProductoTO> productos;

	public GestorProductos() {
		try {
			productos = recuperar();
		} catch(Exception e) {
			productos = new ArrayList<ProductoTO>();
		}
	}

	public List<ProductoTO> obtenerProductos() {
		return productos;
	}
	
	public void nuevoProducto(ProductoTO prod) {
		productos.add(prod);
	}

	public void eliminaProducto(int indice) {
		productos.remove(indice);
	}

	public void guardar() throws IOException {
		almacenar(productos);
	}

	private static void almacenar(List<ProductoTO> productos) throws IOException {

		FileOutputStream fos = null;
		/*
		try {
			fos = new FileOutputStream(FICHERO_DATOS);
			DataOutputStream dos = new DataOutputStream(fos);

			for(ProductoTO p: productos) {
				dos.writeUTF(p.getTitulo());
				dos.writeUTF(p.getAutor());
				dos.writeFloat(p.getPrecio());
				dos.writeBoolean(p.isStock());
			}
		} finally {
			if(fos!=null) {
				fos.close();
			}
		}
		*/
		
		try {
			fos = new FileOutputStream(FICHERO_DATOS);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(productos);
		} finally {
			if(fos!=null) {
				fos.close();
			}
		}	
	}

	@SuppressWarnings("unchecked")
	private static List<ProductoTO> recuperar() throws IOException, ClassNotFoundException {
		/*
		List<ProductoTO> productos = new ArrayList<ProductoTO>();

		FileInputStream fis = null;
		
		try {
			fis = new FileInputStream(FICHERO_DATOS);
			DataInputStream dis = new DataInputStream(fis);
			
			while(true) {
				ProductoTO p = new ProductoTO();
				p.setTitulo(dis.readUTF());
				p.setAutor(dis.readUTF());
				p.setPrecio(dis.readFloat());
				p.setStock(dis.readBoolean());
				
				productos.add(p);
			}
		} catch(EOFException e) {
		} finally {
			if(fis!=null) {
				fis.close();
			}
		}
		*/
		
		List<ProductoTO> productos = null;
		FileInputStream fis = null;
		
		try {
			fis = new FileInputStream(FICHERO_DATOS);
			ObjectInputStream ois = new ObjectInputStream(fis);
			productos = (List<ProductoTO>)ois.readObject();
		} finally {
			if(fis!=null) {
				fis.close();
			}
		}
		
		return productos;
	}

}
