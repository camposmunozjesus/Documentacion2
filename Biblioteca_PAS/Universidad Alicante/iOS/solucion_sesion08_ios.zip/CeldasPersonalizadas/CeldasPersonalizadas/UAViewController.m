//
//  UAViewController.m
//  CeldasPersonalizadas
//
//  Created by Javier Aznar on 04/12/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "UAViewController.h"
#import "CeldaView.h"

@implementation UAViewController
@synthesize tableView = _tableView;
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:
(NSIndexPath *)indexPath {  
    //devolvemos altura de la celda
    return 70.0f;
}

// Customize the number of sections in the table view.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    //devolvemos el numero de secciones (1)
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    //devolvemos el numero de filas por seccion (10)
    return 10;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:
(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"TableViewCell";
    
    CeldaView *cell = (CeldaView*)[tableView dequeueReusableCellWithIdentifier:
                                           CellIdentifier];
    if (cell == nil) {
		//Completamos con el codigo necesario para cargar la vista de la celda
        // Cargamos el Nib de la celda con ese identificador
        NSArray *array = [[NSBundle mainBundle] loadNibNamed:@"CeldaView" 
                                                       owner:self 
                                                     options:nil];
        cell = [array objectAtIndex:0];
    }
    
    // Configuramos la celda
    
    return cell;
}
@end
