import gpcxf5.*

class BootStrap {

    def init = { servletContext ->
        final user = new User(username: 'admin', password: 'admin', enabled: true).save()
        final role = new Role(authority: 'ROLE_ADMIN').save()
        UserRole.create(user,role)
    }

    def destroy = {
    }
}
