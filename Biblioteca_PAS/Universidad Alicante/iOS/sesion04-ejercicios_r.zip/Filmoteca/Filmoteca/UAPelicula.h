//
//  UAPelicula.h
//  Filmoteca
//
//  Created by Miguel Angel Lozano on 20/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum {
    TP, NR7, NR13, NR18
} UACalificacionEdad;

@interface UAPelicula : NSObject

@property (nonatomic,strong) NSString *titulo;
@property (nonatomic,strong) NSString *director;
@property (nonatomic,assign) UACalificacionEdad calificacion;
@property (nonatomic,assign) CGFloat puntuacion;
@property (nonatomic,strong) NSDate *estreno;
@property (nonatomic,strong) NSArray *actores;
@property (nonatomic,strong) UIImage *cartel;

- (id)init;
- (id)initWithTitulo: (NSString*) titulo;
- (id)initWithTitulo: (NSString*) titulo director: (NSString*) director calificacion: (UACalificacionEdad) calificacion puntuacion: (CGFloat) puntuacion estreno: (NSDate*) estreno;

+ (id)pelicula;
+ (id)peliculaWithTitulo: (NSString*) titulo;
+ (id)peliculaWithTitulo: (NSString*) titulo director: (NSString*) director calificacion: (UACalificacionEdad) calificacion puntuacion: (CGFloat) puntuacion estreno: (NSDate*) estreno;

- (NSInteger) antiguedad;

@end
