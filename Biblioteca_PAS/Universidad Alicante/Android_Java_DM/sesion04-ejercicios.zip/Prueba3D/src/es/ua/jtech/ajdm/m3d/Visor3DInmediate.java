package es.ua.jtech.ajdm.m3d;

import java.io.IOException;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.m3g.Appearance;
import javax.microedition.m3g.Background;
import javax.microedition.m3g.Camera;
import javax.microedition.m3g.Graphics3D;
import javax.microedition.m3g.Image2D;
import javax.microedition.m3g.IndexBuffer;
import javax.microedition.m3g.Light;
import javax.microedition.m3g.Material;
import javax.microedition.m3g.Texture2D;
import javax.microedition.m3g.Transform;
import javax.microedition.m3g.TriangleStripArray;
import javax.microedition.m3g.VertexArray;
import javax.microedition.m3g.VertexBuffer;

public class Visor3DInmediate extends Canvas implements Runnable {

	MIDlet3D owner;
	
	Graphics3D g3d;
	Transform tCam;
	Transform tLuz;
	Transform tCubo;
	VertexBuffer vb;
	IndexBuffer tsa;
	Appearance ap;
	Camera cam;
	Light luz;
	Light luzAmbiente;
	Background fondo;
	
	short [] vertexValues = {
			0, 0, 0, // 0  
			0, 0, 1, // 1
			0, 1, 0, // 2
			0, 1, 1, // 3
			1, 0, 0, // 4  
			1, 0, 1, // 5  
			1, 1, 0, // 6  
			1, 1, 1  // 7
	};

	byte [] normalValues = {
			-1, -1, -1,
			-1, -1,  1,
			-1,  1, -1,
			-1,  1,  1,
			 1, -1, -1,
			 1, -1,  1,
			 1,  1, -1,
			 1,  1,  1
	};
	
	int [] faceIndices = {
			0, 1, 2, 3,
			7, 5, 6, 4,
			4, 5, 0, 1,
			3, 7, 2, 6,
			0, 2, 4, 6,
			1, 5, 3, 7
		};

	int [] stripSizes = {
		4, 4, 4, 4, 4, 4	
	};
	
	short [] tex = {
		0,0, 0,0, 0,1, 0,1,
		1,0, 1,0, 1,1, 1,1
	};
	
	public Visor3DInmediate(MIDlet3D owner) {
		this.owner = owner;		
		init3D();
	}

	public void init3D() {
		
		g3d = Graphics3D.getInstance();
		tCubo = new Transform();
		tCam = new Transform();
		tLuz = new Transform();

		cam = new Camera();
		cam.setPerspective(60.0f, (float)getWidth()/(float)getHeight(), 1.0f, 10.0f);
		tCam.postTranslate(0.0f, 0.0f, 2.0f);

		luz = new Light();
		luz.setColor(0x0ffffff);
		luz.setIntensity(1.0f);
		luz.setMode(Light.DIRECTIONAL);
		tLuz.postTranslate(0.0f, 0.0f, 5.0f);		
		
		luzAmbiente = new Light();
		luzAmbiente.setColor(0x0ffffff);
		luzAmbiente.setIntensity(0.5f);
		luzAmbiente.setMode(Light.AMBIENT);
		
		fondo = new Background();
		
		VertexArray va = new VertexArray(8, 3, 2);
		va.set(0, 8, vertexValues);

		VertexArray na = new VertexArray(8, 3, 1);
		na.set(0, 8, normalValues);

		VertexArray ta = new VertexArray(8, 2, 2);
		ta.set(0, 8, tex);
		
		vb = new VertexBuffer();
		vb.setPositions(va, 1.0f, null);
		vb.setNormals(na);
		vb.setTexCoords(0, ta, 1.0f, null);
		
		tsa = new TriangleStripArray(faceIndices, stripSizes);
		
		ap = new Appearance();
		Material mat = new Material();
		ap.setMaterial(mat);
		
		try {
			Image img = Image.createImage("/texture.png");
			Image2D img2d = new Image2D(Image2D.RGB, img);
			
			Texture2D tex2d = new Texture2D(img2d);
			ap.setTexture(0, tex2d);
		} catch (IOException e) {
		}
		
		
		tCubo.postTranslate(-0.5f, -0.5f, -0.5f);
	}
	
	protected void showNotify() {
		Thread t = new Thread(this);
		t.start();
	}

	public void run() {
		while(true) {
			tCubo.postTranslate(0.5f, 0.5f, 0.5f);
			tCubo.postRotate(1.0f, 1.0f, 1.0f, 1.0f);
			tCubo.postTranslate(-0.5f, -0.5f, -0.5f);
			repaint();
			try {
				Thread.sleep(25);
			} catch (InterruptedException e) {
			}
		}
	}
	
	protected void paint(Graphics g) {
		try {
			g3d.bindTarget(g);
		
			g3d.setCamera(cam, tCam);
			g3d.resetLights();
			g3d.addLight(luz, tLuz);
			g3d.addLight(luzAmbiente, null);
			g3d.clear(fondo);
			
			g3d.render(vb, tsa, ap, tCubo);
		} finally {
			g3d.releaseTarget();			
		}
	}

}
