//
//  MiToolBar.h
//  uisesion02-ejemplo3
//
//  Created by Javier Aznar de los Rios on 26/09/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MiToolBar : UIToolbar {
    
}

@end
