package es.ua.jtech.daa;

import java.util.Locale;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.*;
import android.speech.tts.TextToSpeech.Engine;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

public class SintesisVozActivity extends Activity {
	private static int TTS_DATA_CHECK = 1;
    private TextToSpeech tts = null;
    private boolean ttsIsInit = false;
    private RadioButton radioEnglish, radioSpanish;
    private TextView texto;
    private Button leer;

	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        inicializarControles();
        initTextToSpeech();
    }
    
	private void inicializarControles() {
		radioEnglish = (RadioButton)findViewById(R.id.radioEnglish);
		radioSpanish = (RadioButton)findViewById(R.id.radioSpanish);
		texto = (TextView)findViewById(R.id.texto);
		leer = (Button)findViewById(R.id.butRead);
		radioSpanish.setChecked(true);
		
		leer.setOnClickListener(butReadListener);
		radioSpanish.setOnClickListener(radioSpanishListener);
		radioEnglish.setOnClickListener(radioEnglishListener);
	}
	
	private OnClickListener butReadListener = new OnClickListener() {
		public void onClick(View v) {
			speak(texto.getText().toString());
		}
	};
	
	private OnClickListener radioSpanishListener = new OnClickListener() {

		public void onClick(View v) {
			radioSpanish.setChecked(true);
			radioEnglish.setChecked(false);
			
			Locale loc = new Locale("es","","");
			if (tts.isLanguageAvailable(loc) 
			    >= TextToSpeech.LANG_AVAILABLE)
				tts.setLanguage(loc);
		}
		
	};
	
	private OnClickListener radioEnglishListener = new OnClickListener() {

		public void onClick(View v) {
			radioSpanish.setChecked(false);
			radioEnglish.setChecked(true);
			
			Locale loc = new Locale("en","","");
			if (tts.isLanguageAvailable(loc) 
			    >= TextToSpeech.LANG_AVAILABLE)
				tts.setLanguage(loc);
		}
		
	};
	
    private void initTextToSpeech() {
    	Intent intent = new Intent(Engine.ACTION_CHECK_TTS_DATA);
    	startActivityForResult(intent, TTS_DATA_CHECK);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	if (requestCode == TTS_DATA_CHECK) {
    		if (resultCode == Engine.CHECK_VOICE_DATA_PASS) {
    			tts = new TextToSpeech(this, new OnInitListener() {
    				public void onInit(int status) {
    					if (status == TextToSpeech.SUCCESS) {
    						ttsIsInit = true;
    						Locale loc = new Locale("es","","");
    						if (tts.isLanguageAvailable(loc) 
    						    >= TextToSpeech.LANG_AVAILABLE)
    							tts.setLanguage(loc);
    						tts.setPitch(0.8f);
    						tts.setSpeechRate(1.1f);
    					}
    				}
    			});			
    		} else {
    			Intent installVoice = new Intent(Engine.ACTION_INSTALL_TTS_DATA);
    			startActivity(installVoice);
    		}
    	}
    }

    private void speak(String texto) {
    	if (tts != null && ttsIsInit) {
    		tts.speak(texto, TextToSpeech.QUEUE_ADD, null);
    	}
    }

    @Override
    public void onDestroy() {
    	if (tts != null) {
    		tts.stop();
    		tts.shutdown();
    	}	

    	super.onDestroy();
    }

}