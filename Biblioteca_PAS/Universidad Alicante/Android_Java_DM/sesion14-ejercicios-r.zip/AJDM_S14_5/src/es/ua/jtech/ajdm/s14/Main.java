package es.ua.jtech.ajdm.s14;

import android.app.Activity;
import android.content.ContentResolver;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.ContextMenu;
import android.view.View;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.View.OnClickListener;
import android.view.View.OnCreateContextMenuListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class Main extends Activity {
	/** Called when the activity is first created. */
	private TextView textView;
	private Button plegarButton;
	private ContentResolver cr;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		this.textView = (TextView) this.findViewById(R.id.TextView01);
		cr = getContentResolver();
		
		//Hacer la query:
		textView.append("Usuarios en la base de datos:\n");
		
		// Botón para plegar el campo de texto
		plegarButton = ((Button)findViewById(R.id.Button02));
		plegarButton.setOnClickListener(new OnClickListener() {
			private boolean desplegado=true;
			@Override
			public void onClick(View v) {
				if(desplegado){ //Plegar campo de texto
					textView.setLines(1);
					desplegado = false;
					plegarButton.setText(R.string.desplegar);
				}else{ //Desplegarlo
					textView.setLines(textView.getLineCount());
					desplegado = true;
					plegarButton.setText(R.string.plegar);
				}
				
			}
		});
		
		//List View
		ListView lv = (ListView)findViewById(R.id.ListView01);
		Cursor cursor = cr.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);
		cursor.setNotificationUri(cr, ContactsContract.Contacts.CONTENT_URI);
		SimpleCursorAdapter adapter = new SimpleCursorAdapter(getApplicationContext(), R.layout.textviewlayout, cursor, 
				new String[]{ContactsContract.Contacts._ID,ContactsContract.Contacts.DISPLAY_NAME}, 
				new int[]{R.id.TextView0DeLaLista,R.id.TextViewDeLaLista});
		lv.setAdapter(adapter);

		lv.setOnCreateContextMenuListener(new OnCreateContextMenuListener() {
			@Override
			public void onCreateContextMenu(ContextMenu menu, View v,
					ContextMenuInfo menuInfo) {
				Toast.makeText(getApplicationContext(), "No implementado", Toast.LENGTH_SHORT).show();
			}
		});
		
		//Inserción:
		Button insertarButton = (Button)findViewById(R.id.Button01);
		insertarButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Toast.makeText(getApplicationContext(), "No implementado", Toast.LENGTH_SHORT).show();
			}
		});
	}    
    
}