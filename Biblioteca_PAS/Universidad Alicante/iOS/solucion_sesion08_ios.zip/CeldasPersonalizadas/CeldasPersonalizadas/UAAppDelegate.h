//
//  UAAppDelegate.h
//  CeldasPersonalizadas
//
//  Created by Javier Aznar on 04/12/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class UAViewController;

@interface UAAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) UAViewController *viewController;

@end
