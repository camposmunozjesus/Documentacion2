package inicipdipas

import grails.test.mixin.TestFor
import rrhh.Test11Controller;
import spock.lang.Specification

/**
 * See the API for {@link grails.test.mixin.web.ControllerUnitTestMixin} for usage instructions
 */
@TestFor(Test11Controller)
class Test11ControllerSpec extends Specification {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
    }
}
