//
//  UAMasterViewController.h
//  BibliotecaMusical 2
//
//  Created by Javier Aznar on 04/12/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class UADetailViewController;

@interface UAMasterViewController : UITableViewController

@property (strong, nonatomic) UADetailViewController *detailViewController;

@end
