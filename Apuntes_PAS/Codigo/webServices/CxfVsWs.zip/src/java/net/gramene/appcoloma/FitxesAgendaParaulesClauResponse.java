
package net.gramene.appcoloma;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="FitxesAgendaParaulesClauResult" type="{http://www.gramene.net/appcoloma/}BeanRespostaTipus7" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "fitxesAgendaParaulesClauResult"
})
@XmlRootElement(name = "FitxesAgendaParaulesClauResponse")
public class FitxesAgendaParaulesClauResponse {

    @XmlElement(name = "FitxesAgendaParaulesClauResult")
    protected BeanRespostaTipus7 fitxesAgendaParaulesClauResult;

    /**
     * Gets the value of the fitxesAgendaParaulesClauResult property.
     * 
     * @return
     *     possible object is
     *     {@link BeanRespostaTipus7 }
     *     
     */
    public BeanRespostaTipus7 getFitxesAgendaParaulesClauResult() {
        return fitxesAgendaParaulesClauResult;
    }

    /**
     * Sets the value of the fitxesAgendaParaulesClauResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link BeanRespostaTipus7 }
     *     
     */
    public void setFitxesAgendaParaulesClauResult(BeanRespostaTipus7 value) {
        this.fitxesAgendaParaulesClauResult = value;
    }

}
