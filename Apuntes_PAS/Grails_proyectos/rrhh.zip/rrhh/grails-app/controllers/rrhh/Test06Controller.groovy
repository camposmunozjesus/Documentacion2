package rrhh

import org.weceem.content.WcmContent
import org.weceem.content.WcmSpace

/**
 * 
 * @author Jesus Campos
 * Funciona bastante aceptable, pero el probelma con Informacio_General, que encuentra un dirtorio en lugar de la p�gina hay
 * que solucionarlo -> en Test07Controller
 */
class Test06Controller {

   def index() { 
		
	   //Funcionamiento correcto
		//Carga del template
//		def pageTemplate = WcmContent.findByAliasuriAndSpace('Inici', 2711)
//		
//		//Carga de la p�gina Inici
//		def pageContent = WcmContent.findByAliasuriAndSpace('index', 2711)
//
//		def webPage = pageTemplate.content.replace("<wcm:content />", pageContent.content)
//
//		//Para Grails 2.4.3
//		webPage = webPage.replace("/Portal/PAS/", "/IniciPDIPAS/")
//		webPage = webPage.replace("\${wcm.loggedInUserName().encodeAsHTML()}", "")
//		
//		webPage = webPage.replace("\${node.title.encodeAsHTML()}", pageContent.title)
//		
//		//Redirecci�n de la p�gina
//		//${grails.util.Metadata.current.'app.name'}/${space?.name}/index/Informacio_General
//		webPage = webPage.replace("\${grails.util.Metadata.current.'app.name'}", "Portal")
//		webPage = webPage.replace("\${space?.name}", "PAS")
//		
//		render(text: webPage, contentType: "text/html", encoding: "UTF-8")
	   
//	   	def url = "/PAS/index"
//	   	def url = "/PAS/index/Informacio_General/El-PAS-a-la-UPC"
//	    def values = url.toString().split("/")
		
//		println request.forwardURI
		def values = request.forwardURI.toString().split("/")
	    //Pagina
	    def page = values[values.size()-1]
	    println "PAGINA: "+page
			   
		//Carga de la p�gina Inici
	    def pageContent = WcmContent.findAllByAliasuriAndSpace(page, 2711)
		println pageContent.identity
		pageContent = pageContent[0]
		println "TMPL: "+pageContent.tmpl	+ pageContent.identity+pageContent.type
		
		def template
		def webPage
		if(pageContent.tmpl)
		{
			template= pageContent.tmpl	
			//Carga del template
			def pageTemplate = WcmContent.findByIdentityAndSpace(template, 2711)
			
			webPage = pageTemplate.content.replace("<wcm:content />", pageContent.content)
			println "CON TMPL"
		}
		else{
			webPage = pageContent.content
			println "SIN TMPL"
		}
   		//Para Grails 2.4.3
   		webPage = webPage.replace("/Portal/PAS/", "/IniciPDIPAS/")
   		webPage = webPage.replace("\${wcm.loggedInUserName().encodeAsHTML()}", "")
   
   		webPage = webPage.replace("\${node.title.encodeAsHTML()}", pageContent.title)
   
   		//Redirecci�n de la p�gina
   		//${grails.util.Metadata.current.'app.name'}/${space?.name}/index/Informacio_General
   		webPage = webPage.replace("\${grails.util.Metadata.current.'app.name'}", "Portal")
   		webPage = webPage.replace("\${space?.name}", "PAS")
		   
		//Buscador
		if(webPage.contains("<upc:search max=\"15\" eraseplaceholder=\"no\" placeholder=\"Cercar...\" types=\"com.upc.WcmPlantillaFitxa\"></upc:search>")){
			webPage = webPage.replace("<upc:search max=\"15\" eraseplaceholder=\"no\" placeholder=\"Cercar...\" types=\"com.upc.WcmPlantillaFitxa\"></upc:search>", "<form action=\"https://melnik.upc.edu/Portal/cms/tools/search?uri=PAS%2F&amp;max=15&amp;erasePlaceHolder=no&amp;placeHolder=Cercar...&amp;types=com.upc.WcmPlantillaFitxa\" method=\"post\"><input name=\"query\" class=\"customSearchField\" placeholder=\"Cercar...\" onfocus=\"\" value=\"\" id=\"query\" type=\"text\"><input name=\"submit\" class=\"customSearchButton\" value=\"Cerca\" id=\"submit\" type=\"submit\"></form>")
		}
		  
		//P�ginas con men� lateral con la opci�n seleccionada marcada.
		if(webPage.contains("params.desplegableSelected")){
			webPage = webPage.replace("params.desplegableSelected", "\'"+page+"\'")
		}

		
   		render(text: webPage, contentType: "text/html", encoding: "UTF-8")
   }
}
