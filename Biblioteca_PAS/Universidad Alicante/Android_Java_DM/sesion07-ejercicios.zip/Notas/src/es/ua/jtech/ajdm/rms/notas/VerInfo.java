package es.ua.jtech.ajdm.rms.notas;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.rms.*;

public class VerInfo extends Form implements CommandListener {

	Command cmdAtras;

	TextField txtNombre;
	TextField txtTexto;

	MIDlet owner;
	Displayable previo;

	public VerInfo(MIDlet owner, Displayable previo, AdaptadorRMS rms) throws RecordStoreException {
		super("Memoria");
		this.owner = owner;
		this.previo = previo;

		// Añade informacion de memoria
		this.append(new StringItem("Ocupada: ", rms.getOcupado() + " bytes"));
		this.append(new StringItem("Disponible: ", rms.getLibre() + " bytes"));
		
		// Añade comandos
		cmdAtras = new Command("Atras", Command.BACK, 1);
		this.addCommand(cmdAtras);
		this.setCommandListener(this);
	}

	public synchronized void commandAction(Command cmd, Displayable disp) {
		if(cmd == cmdAtras) {
			// Vuelve atrás
			Display d = Display.getDisplay(owner);
			d.setCurrent(previo);
		} 
	}

}