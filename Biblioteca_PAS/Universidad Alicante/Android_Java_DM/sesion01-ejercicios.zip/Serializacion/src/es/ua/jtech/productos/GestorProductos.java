package es.ua.jtech.productos;

import java.util.*;
import java.io.*;

public class GestorProductos {

	private final static String FICHERO_DATOS = "prod.dat";

	private List<ProductoTO> productos;

	public GestorProductos() {
		try {
			productos = recuperar();
		} catch(IOException e) {
			productos = new ArrayList<ProductoTO>();
		}
	}

	public List<ProductoTO> obtenerProductos() {
		return productos;
	}
	
	public void nuevoProducto(ProductoTO prod) {
		productos.add(prod);
	}

	public void eliminaProducto(int indice) {
		productos.remove(indice);
	}

	public void guardar() throws IOException {
		almacenar(productos);
	}

	private static void almacenar(List<ProductoTO> productos) throws IOException {

		// TODO: Guardar los datos en el fichero FICHERO_DATOS

	}

	private static List<ProductoTO> recuperar() throws IOException {

		List<ProductoTO> productos = new ArrayList<ProductoTO>();

		// TODO: Leer los datos del fichero FICHERO_DATOS

		return productos;
	}

}
