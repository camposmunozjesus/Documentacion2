package es.ua.jtech.ajdm.red.tienda;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class DatosProducto extends Form implements CommandListener {

	MIDlet owner;
	Displayable previo;

	Command cmdAtras;

	public DatosProducto(MIDlet owner, Displayable previo, Producto prod) {
		super(prod.titulo);

		this.owner = owner;
		this.previo = previo;

		// A�ade elementos del formulario
		this.append(new StringItem("Tipo: ", prod.tipo));
		this.append(new StringItem("Autor: ", prod.autor));
		this.append(new StringItem("Precio: ", imprimeReal(prod.precio)));
		if(prod.stock) {
			this.append(new StringItem("Disponibilidad: ", "En stock"));
		} else {
			this.append(new StringItem("Disponibilidad: ", "Agotado"));
		}
		
		// A�ade comandos
		cmdAtras = new Command("Atras", Command.BACK, 1);
		this.addCommand(cmdAtras);
		this.setCommandListener(this);
	}

	private String imprimeReal(int numero) {

		// Imprime un numero entero como real de dos decimales
		int entero = numero / 100;
		int fraccion = numero % 100;

		StringBuffer real = new StringBuffer();
		real.append(entero);
		real.append('.');
		if(fraccion<10) {
			real.append('0');
		}
		real.append(fraccion);
		
		return real.toString();
	}

	public void commandAction(Command cmd, Displayable disp) {
		if(cmd == cmdAtras) {

			// Vuelve atras
			Display d = Display.getDisplay(owner);
			d.setCurrent(previo);
		}
	}

}
