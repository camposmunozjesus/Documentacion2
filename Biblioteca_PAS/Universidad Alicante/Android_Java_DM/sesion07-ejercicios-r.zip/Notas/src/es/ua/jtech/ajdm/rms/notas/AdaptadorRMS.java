package es.ua.jtech.ajdm.rms.notas;

import java.io.*;
import java.util.*;

import javax.microedition.rms.*;

public class AdaptadorRMS {

	// Nombres de los almacenes
	
	public final static String RS_DATOS = "rs_datos";

	// Almacenes de registros
	
	RecordStore rsDatos;

	public AdaptadorRMS() throws RecordStoreException {
		rsDatos = RecordStore.openRecordStore(RS_DATOS, true);
	}

	/*
	 * Obtiene todos los mensajes
	 */
	public Mensaje[] listaMensajes() throws RecordStoreException, IOException {
		RecordEnumeration re = rsDatos.enumerateRecords(null, null, false);

		Vector mensajes = new Vector();

		while (re.hasNextElement()) {
			int id = re.nextRecordId();
			byte[] datos = rsDatos.getRecord(id);

			ByteArrayInputStream bais = new ByteArrayInputStream(datos);
			DataInputStream dis = new DataInputStream(bais);

			Mensaje msg = Mensaje.deserialize(dis);
			msg.setRmsID(id);
			mensajes.addElement(msg);
		}

		Mensaje[] result = new Mensaje[mensajes.size()];
		mensajes.copyInto(result);

		return result;
	}

	public int addMensaje(Mensaje msg) throws IOException, RecordStoreException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(baos);

		msg.serialize(dos);
		byte[] datos = baos.toByteArray();

		int id = rsDatos.addRecord(datos, 0, datos.length);
		msg.setRmsID(id);
		return id;
	}

	public void updateMensaje(Mensaje msg) throws IOException, RecordStoreException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(baos);

		msg.serialize(dos);
		byte[] datos = baos.toByteArray();

		rsDatos.setRecord(msg.getRmsID(), datos, 0, datos.length);
	}

	public void removeMensaje(int id) throws RecordStoreException {
		rsDatos.deleteRecord(id);
	}

	public Mensaje getMensaje(int id) throws RecordStoreException, IOException {
		byte[] datos = rsDatos.getRecord(id);

		ByteArrayInputStream bais = new ByteArrayInputStream(datos);
		DataInputStream dis = new DataInputStream(bais);

		Mensaje msg = Mensaje.deserialize(dis);
		msg.setRmsID(id);

		return msg;
	}

	public void cerrar() throws RecordStoreException {
		rsDatos.closeRecordStore();
	}

	public int getOcupado() throws RecordStoreNotOpenException {
		return rsDatos.getSize();
	}

	public int getLibre() throws RecordStoreNotOpenException {
		return rsDatos.getSizeAvailable();
	}
}