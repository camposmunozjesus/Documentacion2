
package net.gramene.appcoloma;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ArrayOfDocImg complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ArrayOfDocImg">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DocImg" type="{http://www.gramene.net/appcoloma/}DocImg" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ArrayOfDocImg", propOrder = {
    "docImg"
})
public class ArrayOfDocImg {

    @XmlElement(name = "DocImg", nillable = true)
    protected List<DocImg> docImg;

    /**
     * Gets the value of the docImg property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the docImg property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDocImg().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DocImg }
     * 
     * 
     */
    public List<DocImg> getDocImg() {
        if (docImg == null) {
            docImg = new ArrayList<DocImg>();
        }
        return this.docImg;
    }

}
