package inicipdipas

import org.weceem.content.WcmContent
import org.weceem.content.WcmSpace

/**
 * 
 * @author Jesus Campos
 * Se incluye con �xito el buscador UPC.
 */
class Test05Controller {

    def index() { 
		
		println new Date()
		def s = WcmSpace.list()
		
		def c = WcmContent.list()
		
		//Carga del template
		def pageTemplate = WcmContent.findByAliasuriAndSpace('Inici', 2711)
//		println pageTemplate.title
//		println pageTemplate.content
//		pageTemplate.content = pageTemplate.content.replace("max=\"15\" eraseplaceholder=\"no\" placeholder=\"Cercar...\" types=\"com.", "BUSCADOR PROPIO UPC")
//		println pageTemplate.content
		
		//Carga de la p�gina Inici
		def pageContent = WcmContent.findByAliasuriAndSpace('index', 2711)
//		println pageContent.title
//		println pageContent.content
		
//		def pagina = "<div class=\"testingClass\"> HOME land<div>"
		
		def webPage = pageTemplate.content.replace("<wcm:content />", pageContent.content)
		
		//Para Grails 2.4.3
		webPage = webPage.replace("/Portal/PAS/", "/IniciPDIPAS/")
		//
		webPage = webPage.replace("\${wcm.loggedInUserName().encodeAsHTML()}", "")
		
		webPage = webPage.replace("\${node.title.encodeAsHTML()}", pageContent.title)
		
		//Redirecci�n de la p�gina
		//${grails.util.Metadata.current.'app.name'}/${space?.name}/index/Informacio_General
		webPage = webPage.replace("\${grails.util.Metadata.current.'app.name'}", "Portal")
		webPage = webPage.replace("\${space?.name}", "PAS")
		
		if(webPage.contains("<upc:search max=\"15\" eraseplaceholder=\"no\" placeholder=\"Cercar...\" types=\"com.upc.WcmPlantillaFitxa\"></upc:search>")){
			webPage = webPage.replace("<upc:search max=\"15\" eraseplaceholder=\"no\" placeholder=\"Cercar...\" types=\"com.upc.WcmPlantillaFitxa\"></upc:search>", "<form action=\"https://melnik.upc.edu/Portal/cms/tools/search?uri=PAS%2F&amp;max=15&amp;erasePlaceHolder=no&amp;placeHolder=Cercar...&amp;types=com.upc.WcmPlantillaFitxa\" method=\"post\"><input name=\"query\" class=\"customSearchField\" placeholder=\"Cercar...\" onfocus=\"\" value=\"\" id=\"query\" type=\"text\"><input name=\"submit\" class=\"customSearchButton\" value=\"Cerca\" id=\"submit\" type=\"submit\"></form>")
		}
		
		render(text: webPage, contentType: "text/html", encoding: "UTF-8")
	}
}
