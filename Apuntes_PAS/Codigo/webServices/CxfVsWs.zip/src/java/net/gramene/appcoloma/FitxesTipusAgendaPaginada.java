
package net.gramene.appcoloma;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idioma" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="idTipusAgenda" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="firstRow" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="lastRow" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "idioma",
    "idTipusAgenda",
    "firstRow",
    "lastRow"
})
@XmlRootElement(name = "fitxesTipusAgendaPaginada")
public class FitxesTipusAgendaPaginada {

    protected int idioma;
    protected int idTipusAgenda;
    protected int firstRow;
    protected int lastRow;

    /**
     * Gets the value of the idioma property.
     * 
     */
    public int getIdioma() {
        return idioma;
    }

    /**
     * Sets the value of the idioma property.
     * 
     */
    public void setIdioma(int value) {
        this.idioma = value;
    }

    /**
     * Gets the value of the idTipusAgenda property.
     * 
     */
    public int getIdTipusAgenda() {
        return idTipusAgenda;
    }

    /**
     * Sets the value of the idTipusAgenda property.
     * 
     */
    public void setIdTipusAgenda(int value) {
        this.idTipusAgenda = value;
    }

    /**
     * Gets the value of the firstRow property.
     * 
     */
    public int getFirstRow() {
        return firstRow;
    }

    /**
     * Sets the value of the firstRow property.
     * 
     */
    public void setFirstRow(int value) {
        this.firstRow = value;
    }

    /**
     * Gets the value of the lastRow property.
     * 
     */
    public int getLastRow() {
        return lastRow;
    }

    /**
     * Sets the value of the lastRow property.
     * 
     */
    public void setLastRow(int value) {
        this.lastRow = value;
    }

}
