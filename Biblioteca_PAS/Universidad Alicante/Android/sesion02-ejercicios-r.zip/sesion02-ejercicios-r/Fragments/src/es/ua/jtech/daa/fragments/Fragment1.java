package es.ua.jtech.daa.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Fragment1 extends android.app.ListFragment {
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		String[] values = new String[] { "Aristóteles",
			    "Copérnico",
			    "Descartes",
			    "Hume",
			    "Kant",
			    "Locke",
			    "Nietzsche",
			    "Ockham",
			    "Ortega y Gasset",
			    "Platón",
			    "Sócrates",
			    "Tales de Mileto",
			    "Tomás de Aquino" };
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(),
				android.R.layout.simple_list_item_1, values);
		setListAdapter(adapter);
	}

	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {
		String item = (String) getListAdapter().getItem(position);
		Fragment2 fragment = (Fragment2) getFragmentManager()
				.findFragmentById(R.id.fragmento2);
		if (fragment != null && fragment.isInLayout()) {
			fragment.setText(item);
		} else {
			Intent intent = new Intent(getActivity().getApplicationContext(),
					Fragment2Activity.class);
			intent.putExtra("value", item);
			startActivity(intent);

		}

	}
}