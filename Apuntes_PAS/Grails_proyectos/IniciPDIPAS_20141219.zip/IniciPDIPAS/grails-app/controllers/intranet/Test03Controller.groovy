package intranet

class Test03Controller {

    def index() { }
}
