package es.ua.jtech.ajdm.s14;

import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class Main extends Activity {
	/** Called when the activity is first created. */
	private TextView textView;
	private DataHelper dataHelper;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		this.textView = (TextView) this.findViewById(R.id.TextView01);

		this.dataHelper = new DataHelper(this);
		
		//TODO Utiliza el dataHelper para eliminar todos los usuarios
		
		//TODO Utiliza el dataHelper para añadir nuevos usuarios
		
		//TODO Utiliza el dataHelper para obtener la lista de usuarios
		//     y muéstralos en el textView
		
	}    
    
}