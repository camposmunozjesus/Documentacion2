package es.ua.jtech.daa.geolocalizacion;

import java.io.IOException;
import java.util.List;

import es.ua.jtech.daa.geolocalizacion.R;

import android.app.Activity;
import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;

public class ActividadGeolocalizacion extends Activity implements LocationListener {

	double latitud, longitud;
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);        
    }

	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		super.onWindowFocusChanged(hasFocus);
		
		if(hasFocus) {
	        LocationManager manager = (LocationManager)this.getSystemService(Context.LOCATION_SERVICE);
	        manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 10, this);			
		}
	}

	public String obtenerDireccion() {
		Geocoder geocoder = new Geocoder(this);
        String direccion = "";
        try {
        	List<Address> direcciones = geocoder.getFromLocation(latitud, longitud, 5);

        	if(direcciones.size() > 0) {
        		Address a = direcciones.get(0);
        		direccion = a.getAddressLine(0) + ", "  + a.getLocality() + ", " + a.getCountryName();
        	} else {
        		direccion = "No encontrada";
        	}
		} catch (IOException e) {
			direccion = "Error al obtener direccion: " + e.getMessage();
		}
				
		return direccion;
	}
	
	private class GeocodeTask extends AsyncTask<Integer, Integer, Integer>
	{
		String direccion = null;
		
		@Override
		protected Integer doInBackground(Integer... task)
		{
			direccion = obtenerDireccion();			
			return 0;
		}

		@Override
		protected void onCancelled()
		{
			super.onCancelled();
		}

		@Override
		protected void onPostExecute(Integer result)
		{		
	        TextView txtDir = (TextView)findViewById(R.id.textoDir);
	        txtDir.setText("Direccion: " + direccion);
			
			super.onPostExecute(result);
		}

		@Override
		protected void onPreExecute()
		{ 	
			super.onPreExecute();
		}

		@Override
		protected void onProgressUpdate(Integer... values)
		{
			super.onProgressUpdate(values);
		}
	};	
	
	public void onLocationChanged(Location location) {

        latitud = location.getLatitude();
        longitud = location.getLongitude();
		
		TextView txtLat = (TextView)this.findViewById(R.id.textoLat);
        TextView txtLon = (TextView)this.findViewById(R.id.textoLon);

        txtLat.setText("Latitud: " + latitud);
        txtLon.setText("Longitud: " + longitud);
        
        new GeocodeTask().execute();
	}

	public void onProviderDisabled(String provider) {
		// TODO Auto-generated method stub
		
	}

	public void onProviderEnabled(String provider) {
		// TODO Auto-generated method stub
		
	}

	public void onStatusChanged(String provider, int status, Bundle extras) {
		// TODO Auto-generated method stub
		
	}
}