package es.ua.jtech.ajdm.basico;

public class EjObjetos
{
	public static void main(String[] args)
	{
		MiObject m1 = new MiObject(3, "Hola");
		MiObject m2 = new MiObject(3, "Hola");
		MiObject m3 = new MiObject(12, "Otra prueba");
		
		System.out.println ("m1 = m2?:" + (m1.equals(m2)));
		System.out.println ("m1 = m3?:" + (m1.equals(m3)));
		
		System.out.println ("===================");
		
		System.out.println("m1 = " + m1);
		System.out.println("m2 = " + m2);
		System.out.println("m3 = " + m3);
	}
}

class MiObject
{
	int numero;
	String cadena;
	
	public MiObject(int num, String cad)
	{
		numero = num;
		cadena = cad;
	}	
}