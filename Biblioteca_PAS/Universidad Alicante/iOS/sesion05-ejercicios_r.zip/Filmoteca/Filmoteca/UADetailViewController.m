//
//  UADetailViewController.m
//  Filmoteca
//
//  Created by Miguel Angel Lozano on 15/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "UADetailViewController.h"

#import "UAPelicula.h"
#import "UACartelViewController.h"

@interface UADetailViewController ()
- (void)configureView;
@end

@implementation UADetailViewController

@synthesize pelicula = _pelicula;

@synthesize labelPuntuacion = _labelPuntuacion;
@synthesize sliderPuntuacion = _sliderPuntuacion;
@synthesize textoTitulo = _textoTitulo;
@synthesize textoDirector = _textoDirector;
@synthesize segmentedCalificacion = _segmentedCalificacion;

@synthesize viewCartel = _viewCartel;

#pragma mark - Managing the detail item

- (IBAction)cerrarTeclado:(id)sender {
    [sender resignFirstResponder];    
}

- (IBAction)cambiarPuntuacion:(id)sender {
    UISlider *slider = sender;
    self.labelPuntuacion.text = [NSString stringWithFormat:@"%1.1f", slider.value * 5.0];
}

- (void)verCartel:(id)sender {
/*
    [[NSBundle mainBundle] loadNibNamed:@"VistaImagen" owner:self options:nil];
    
    UILabel *labelCartel = (UILabel*)[self.viewCartel viewWithTag:1];
    UIImageView *imageCartel = (UIImageView*)[self.viewCartel viewWithTag:2];
    
    labelCartel.text = self.pelicula.titulo;
    imageCartel.image = self.pelicula.cartel;
    
    [self.view addSubview: self.viewCartel];
 */
    UACartelViewController *cartelController = [[UACartelViewController alloc] initWithNibName:@"UACartelView" bundle:nil];
    cartelController.pelicula = self.pelicula;
    [self presentModalViewController:cartelController animated:YES];
}

- (IBAction)cerrarCartel:(id)sender {
    [self.viewCartel removeFromSuperview];
}

- (IBAction)guardarDatos:(id)sender {
    self.pelicula.titulo = self.textoTitulo.text;
    self.pelicula.director = self.textoDirector.text;
    self.pelicula.calificacion = self.segmentedCalificacion.selectedSegmentIndex;
    self.pelicula.puntuacion = self.sliderPuntuacion.value * 5.0;

    [self.navigationController popViewControllerAnimated:YES];
}

- (void)setPelicula:(UAPelicula *)pelicula {
    _pelicula = pelicula;
    [self configureView];
}

- (void) configureView {
    [self.viewCartel removeFromSuperview];
    self.textoTitulo.text = self.pelicula.titulo;
    self.textoDirector.text = self.pelicula.director;
    self.segmentedCalificacion.selectedSegmentIndex = self.pelicula.calificacion;
    self.sliderPuntuacion.value = self.pelicula.puntuacion / 5.0;
    [self cambiarPuntuacion:self.sliderPuntuacion];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    [self configureView];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Detail", @"Detail");
    }
    return self;
}


@end
