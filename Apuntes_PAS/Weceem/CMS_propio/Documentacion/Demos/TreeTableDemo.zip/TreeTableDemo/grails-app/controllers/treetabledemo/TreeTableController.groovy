package treetabledemo

/**
 * Vol mostrar el funcionament del plugin de JS TreeTable.<br>
 * Al Bootstrap.groovy s'inicia la base de dades embedded. Per entrar a la base de dades posar al navegador
 * http://localhost:8080/TreeTableDemo/dbconsole/ i "Connect".
 * @author Jesus Campos
 * @version 10-04-2015
 */
class TreeTableController {

    def index() {
		[results:  Arxiu.list().nom]
	}
}
