//
//  UATareaViewController.m
//  TareasStoryboard
//
//  Created by Miguel Angel Lozano on 08/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "UATareaViewController.h"

@interface UATareaViewController ()

@end

@implementation UATareaViewController

@synthesize tarea = _tarea;
@synthesize indexPath = _indexPath;
@synthesize delegate = _delegate;

@synthesize textFieldTarea = _textFieldTarea;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    self.textFieldTarea.text = self.tarea;
    
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [self guardarTarea:textField];
    return YES;
}

- (void)guardarTarea:(id)sender {
    [self.delegate tareaViewController:self didChangeTarea:self.textFieldTarea.text atIndexPath:self.indexPath];
    [self.navigationController popViewControllerAnimated:YES];
}

@end
