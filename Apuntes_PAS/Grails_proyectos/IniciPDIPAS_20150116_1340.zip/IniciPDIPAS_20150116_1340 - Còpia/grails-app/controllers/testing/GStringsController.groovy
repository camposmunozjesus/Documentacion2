package testing

class GStringsController {

    def index() { }
}
