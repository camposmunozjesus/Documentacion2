
package net.gramene.appcoloma;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Idioma complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Idioma">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="intIdioma" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="strIdioma" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Idioma", propOrder = {
    "intIdioma",
    "strIdioma"
})
public class Idioma {

    protected short intIdioma;
    protected String strIdioma;

    /**
     * Gets the value of the intIdioma property.
     * 
     */
    public short getIntIdioma() {
        return intIdioma;
    }

    /**
     * Sets the value of the intIdioma property.
     * 
     */
    public void setIntIdioma(short value) {
        this.intIdioma = value;
    }

    /**
     * Gets the value of the strIdioma property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrIdioma() {
        return strIdioma;
    }

    /**
     * Sets the value of the strIdioma property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrIdioma(String value) {
        this.strIdioma = value;
    }

}
