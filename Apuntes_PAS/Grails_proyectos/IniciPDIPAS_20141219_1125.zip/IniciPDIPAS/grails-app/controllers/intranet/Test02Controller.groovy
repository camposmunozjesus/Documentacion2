package intranet

class Test02Controller {

    def index() { }
}
