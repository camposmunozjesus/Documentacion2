package es.ua.jtech.ajdm.servicios;

import android.app.Service;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

public class MiCuentaServicio extends Service {
	MiTarea miTarea;
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		Log.i("SRV", "onStartCommand");
		miTarea.execute();
		return Service.START_STICKY;
	}

	@Override
	public void onCreate() {
		super.onCreate();
		Toast.makeText(this,"Servicio creado ...", Toast.LENGTH_LONG).show();
		Log.i("SRV","onCreate");
		miTarea = new MiTarea();
	}

	
	@Override
	public void onDestroy() {
		super.onDestroy();
		Toast.makeText(this,"onDestroy: Servicio destruido ...", Toast.LENGTH_LONG).show();
		Log.i("SRV","Servicio destruido");
		miTarea.cancel(true);
	}

	@Override
	public IBinder onBind(Intent arg0) {
		
		return null;
	}

	
	private class MiTarea extends AsyncTask<String, String, String>{
		private int i;
		
		
		
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			i = 1;
		}

		@Override
		protected String doInBackground(String... params) {
			for(i=1; i<100; i++){
				Log.i("SRV", "AsyncTask: "+"Cuento hasta "+i);
				publishProgress(""+i);
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			return null;
		}

		@Override
		protected void onProgressUpdate(String... values) {
			Toast.makeText(getApplicationContext(),"Cuento hasta "+values[0], Toast.LENGTH_SHORT).show();
		}

		@Override
		protected void onCancelled() {
			super.onCancelled();
			i = 101;
		}
		
	}
}
