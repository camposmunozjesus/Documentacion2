package es.ua.jtech.daa;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;

public class UsuariosProvider extends ContentProvider {

	//Campos típicos de un ContentProvider:
	public static final Uri CONTENT_URI = Uri.parse("content://es.ua.jtech.daa/usuarios");
	private static final int ALLROWS = 1;
	private static final int SINGLE_ROW = 2;
	private static final UriMatcher uriMatcher;
	static{
		uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
		uriMatcher.addURI("es.ua.jtech.daa", "usuarios", ALLROWS);
		uriMatcher.addURI("es.ua.jtech.daa", "usuarios/#", SINGLE_ROW);
	} //NOTA: No olvides registrar el provider en AndroidManifest.xml, dentro de Application con:
	 //<provider android:name="UsuariosProvider" android:authorities="es.ua.jtech.daa"/>
	
	
	//Copiados del DataHelper del ejercicio anterior
	public static final String DATABASE_NAME = "misusuarios.db";
	public static final int DATABASE_VERSION = 2;
	public static final String TABLE_NAME = "usuarios";
	public static final String[] COLUMNAS = { "_id", "nombre" };

	private Context context;
	private SQLiteDatabase db;

	private static final String CREATE_DB = "CREATE TABLE " + TABLE_NAME + "("
			+ COLUMNAS[0] + " INTEGER PRIMARY KEY, " + COLUMNAS[1] + " TEXT)";	   
	
	
	@Override
	public boolean onCreate() {
		this.context = getContext();
		MiOpenHelper openHelper = new MiOpenHelper(this.context);
		this.db = openHelper.getWritableDatabase();
		return true;
	}

	@Override
	public String getType(Uri uri) {
		switch(uriMatcher.match(uri)){
		case ALLROWS: return "vnd.ua.cursor.dir/usuariosprovidercontent"; 
		case SINGLE_ROW: return "vnd.ua.cursor.item/usuariosprovidercontent"; 
		default: throw new IllegalArgumentException("URI no soportada: "+uri);
		}
	}

	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		int changes = 0;
		switch(uriMatcher.match(uri)) {
		case ALLROWS:
			changes = db.delete(TABLE_NAME, selection, selectionArgs);
			break;
		case SINGLE_ROW:
			String id = uri.getPathSegments().get(1);
			Log.i("SQL","delete the id " + id);
			changes = db.delete(TABLE_NAME, "_id = " + id + (!TextUtils.isEmpty(selection) ? " AND (" + selection + ")" : ""), selectionArgs);
			break;
		default:
			throw new IllegalArgumentException("URI no soportada: " + uri);
		}
		context.getContentResolver().notifyChange(uri, null);
		return changes;
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		long id = db.insert(TABLE_NAME, COLUMNAS[1], values);
		if (id > 0) {
			Uri uriInsertado = ContentUris.withAppendedId(CONTENT_URI, id);
			context.getContentResolver().notifyChange(uriInsertado, null);
			return uriInsertado;
		}
		return null;
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {
		return db.query(TABLE_NAME, COLUMNAS, selection, selectionArgs, null, null, null);
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		int changes = 0;
		switch(uriMatcher.match(uri)){
		case ALLROWS: 
			changes = db.update(TABLE_NAME, values, selection, selectionArgs);
			break;
		case SINGLE_ROW: 
			String id = uri.getPathSegments().get(1);
			Log.i("SQL", "delete the id "+id);
			changes =  db.update(TABLE_NAME, values,
					"_id = " + id + (!TextUtils.isEmpty(selection) ? " AND (" + selection + ')' : ""), 
					selectionArgs);
			break;
		default: throw new IllegalArgumentException("URI no soportada: "+uri);
		}
		context.getContentResolver().notifyChange(uri, null);
		return changes;
	}

	private static class MiOpenHelper extends SQLiteOpenHelper {

		MiOpenHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			db.execSQL(CREATE_DB);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			Log.w("SQL","onUpgrade: eliminando tabla si ésta existe, y creándola de nuevo");
			db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
			onCreate(db);
		}
	}

}
