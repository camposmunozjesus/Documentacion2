/*
 * CommonData.java
 * Copyright (C) 2009 Miguel Angel Lozano and Boyan Bonev
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package es.ua.jtech.jdm.sesion14.game.tapper.data;

import javax.microedition.lcdui.Font;

/**
 * @author Miguel Angel and Boyan
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class CommonData {

	// Numero de vidas total
	public static final int NUM_LIVES = 5;
	public static int NUM_STAGES; // Se lee de tapper.dat
	// A las siguientes se les da valor al construir el fondo, cambian en cada stage
	public static int NUM_BARRAS; 
	public static int BARRAS_Y[];
	public static int BARRAS_XIni[];
	public static int BARRAS_XFin[];
	
	
	// Dimensiones de la pantalla
	// Dependen del tamaño de Canvas en modo Fullscreen, al iniciar el SplashScreen
	public static int SCREEN_WIDTH;
	public static int SCREEN_HEIGHT;

	// Dimensiones de las celdas del fondo
	public final static int BG_TILE_WIDTH = 18;
	public final static int BG_TILE_HEIGHT = 48;

	// Dimensiones de la matriz de celdas del fondo (ancho x alto)
	// Dependen del tamaño de la pantalla
	public static int BG_H_TILES; 
	public static int BG_V_TILES; 

	// Márgenes superior e inferior mínimos (en píxeles)
	public static final int BG_MARGINTOP = 0;
	public static final int BG_MARGINBOT = 0;
	
	// Indices de los tipos de celdas del fondo
	public final static int BG_TILE_PUERTA = 1;
	public final static int BG_TILE_BARRA = 2;
	public final static int BG_TILE_FINBARRA = 3;
	public final static int BG_TILE_GRIFO = 4;
	public final static int BG_TILE_GRIFOPARED = 5;
	public final static int BG_TILE_BORDE = 6;
	public final static int BG_TILE_VACIO = 7;
	
	// Dimensiones del sprite
	public final static int SPRITE_WIDTH = 48;
	public final static int SPRITE_HEIGHT = 64;
	public final static int SPRITE_COLLISION_X = 14;
	public final static int SPRITE_COLLISION_Y = 5;
	public final static int SPRITE_COLLISION_WIDTH = 20;
	public final static int SPRITE_COLLISION_HEIGHT = 40;

	// Secuencias de frames de los movimientos del personaje
	public final static int SPRITE_STAY_LEFT = 7;
	public final static int[] SPRITE_MOVE_LEFT = { 0, 2 };
	public final static int SPRITE_STAY_RIGHT = 6;
	public final static int[] SPRITE_MOVE_RIGHT = { 1, 3 };
	public final static int SPRITE_STAY_DEAD = 8;
	public final static int[] SPRITE_SERVE = { 5, 4 };

	// Velocidad del personaje (numero de pixels que avanza en cada tick)
	public final static int SPRITE_STEP = 4;
	
	// Dimensiones de la imagen de la cara para el contador de vidas
	public final static int FACE_WIDTH = 19;
	public final static int FACE_HEIGHT = 18;

	// Dimensiones del sprite de la cerveza
	public final static int BEER_WIDTH = 24;
	public final static int BEER_HEIGHT = 29;
	public final static int BEER_STEP = 2;
	public final static int BEER_BACK_STEP = 1;
	public final static int BEER_TIMER_SERVE = 5;
	public final static int BEER_TIMER_FILL = 15;
	
	// Sprites de los clientes
	// (El 1er frame, el de la paloma, no cuenta, es para "morir" el cliente)
	public final static int CLIENT_WIDTH = 32;
	public final static int CLIENT_HEIGHT = 32;
	public final static int NUM_CLIENT_TYPES = 19;
	//En realidad hay (19+1) * 3 frames; para más info, ver la imagen
	
	// Maximo numero aleatorio al generar clientes
	public static int PROB_PERCENTAGE = 55;
	public static final int PROB_MAX_PERCENTAGE = 100;
	public static final int PROB_MIN_PERCENTAGE = 5;
	
	// Datos del texto de titulo de fase
	public final static int STAGE_TITLE_Y = 100;	
	public static final int STAGE_TITLE_COLOR = 0x0FFFF00;
	public static final Font STAGE_TITLE_FONT = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD, Font.SIZE_SMALL);
	public static final String STAGE_COMPLETED_TEXT = "Nivel completado";
	public static final Font POINTS_FONT = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD, Font.SIZE_LARGE);

	// Datos del texto de la pantalla de titulo
	public static final String GAME_START_TEXT = "PULSA START PARA COMENZAR";
	public static final int GAME_START_COLOR = 0x0FFFF00;
	public static final Font GAME_START_FONT = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD, Font.SIZE_SMALL);

	// Esta función debe ser ejecutada antes de crear el Background
	public static void initBG(int screenw, int screenh){
		CommonData.SCREEN_HEIGHT = screenh;
		CommonData.SCREEN_WIDTH = screenw;
		//Dependiendo de las dimensiones de la pantalla,
		//la matriz de tiles será de un tamaño u otro.
		CommonData.BG_V_TILES = (CommonData.SCREEN_HEIGHT - CommonData.BG_MARGINTOP - CommonData.BG_MARGINBOT)  /
								CommonData.BG_TILE_HEIGHT;
		CommonData.BG_H_TILES = (CommonData.SCREEN_WIDTH) / CommonData.BG_TILE_WIDTH;
	}

}
