//
//  UACartelViewController.h
//  Filmoteca
//
//  Created by Miguel Angel Lozano on 28/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class UAPelicula;

@interface UACartelViewController : UIViewController

- (IBAction) cerrar:(id)sender;

@property(nonatomic,unsafe_unretained) UAPelicula *pelicula;
@property(nonatomic,unsafe_unretained) IBOutlet UIImageView *ivCartel;

@end
