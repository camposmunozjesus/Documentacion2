package es.ua.jtech.daa;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DataHelper {

   private static final String DATABASE_NAME = "misusuarios.db";
   private static final int DATABASE_VERSION = 1;
   private static final String TABLE_NAME = "usuarios";
   private static final String[] COLUMNAS = {"_id","nombre"};
   
   private Context context;
   private SQLiteDatabase db;

   private SQLiteStatement insertStatement;
   private static final String INSERT = "insert into " + TABLE_NAME + 
     "("+COLUMNAS[1]+") values (?)";
   private static final String CREATE_DB = "CREATE TABLE " + TABLE_NAME + 
	 "("+COLUMNAS[0]+" INTEGER PRIMARY KEY, "+COLUMNAS[1]+" TEXT)";
   

   
   public DataHelper(Context context) {
      this.context = context;
      MiOpenHelper openHelper = new MiOpenHelper(this.context);

      //TODO utilizar openHelper para obtener una base de datos
      //     para escribir en ella y guardar la referencia en db.

      //TODO utilizar db para compilar la sentencia INSERT
      //     guardándola en insertStatement
   }

   public long insert(String nombreUsuario) {
      //TODO utilizar bindString para introducir el nombre
	  //     en la sentencia insertStatement
	   
	  //TODO ejecutar el Insert de la sentencia y devolver
	  //     el número de filas afectadas
      return 0;
   }

   public int deleteAll() {
	  //Eliminar todas las filas de la tabla de db
      return 0;
   }

   public List<String> selectAll() {
      List<String> list = new ArrayList<String>();
      Cursor cursor = db.query(TABLE_NAME, COLUMNAS, 
        null, null, null, null, null);
      if (cursor.moveToFirst()) {
         do {
            list.add(cursor.getString(1)); 
         } while (cursor.moveToNext());
      }
      if (cursor != null && !cursor.isClosed()) {
         cursor.close();
      }
      return list;
   }

   private static class MiOpenHelper extends SQLiteOpenHelper {

      MiOpenHelper(Context context) {
         super(context, DATABASE_NAME, null, DATABASE_VERSION);
      }

      @Override
      public void onCreate(SQLiteDatabase db) {
    	 //TODO Ejecutar la sentencia CREATE_DB en db
      }

      @Override
      public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
         Log.w("SQL", "onUpgrade: eliminando tabla si ésta existe, y creándola de nuevo");
         //TODO Eliminar la tabla con: "DROP TABLE IF EXISTS " + TABLE_NAME
         //TODO y volver a crearla (método onCreate(db)).
      }
   }
}
