import treetabledemo.Arxiu

class BootStrap {

    def init = { servletContext ->
		new Arxiu(nom: "Grails developer CMS doc",
			usuariCreacio: "jesus.campos",
			usuariModificacio: "cristina.garcia").save()
			
		new Arxiu(nom: "User CMS doc",
			usuariCreacio: "juan.luis.moreno",
			usuariModificacio: "cristina.garcia").save()
			
		new Arxiu(nom: "Grails developer CMS doc",
			usuariCreacio: "jesus.campos",
			usuariModificacio: "cristina.garcia").save()
			
		new Arxiu(nom: "User CMS doc",
			usuariCreacio: "juan.luis.moreno",
			usuariModificacio: "cristina.garcia").save()
			
		new Arxiu(nom: "Grails developer CMS doc",
			usuariCreacio: "jesus.campos",
			usuariModificacio: "cristina.garcia").save()
			
		new Arxiu(nom: "User CMS doc",
			usuariCreacio: "juan.luis.moreno",
			usuariModificacio: "cristina.garcia").save()

    }
    def destroy = {
    }
}
