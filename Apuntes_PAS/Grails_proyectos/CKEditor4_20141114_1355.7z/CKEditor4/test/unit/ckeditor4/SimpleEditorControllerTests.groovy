package ckeditor4



import grails.test.mixin.*
import org.junit.*

/**
 * See the API for {@link grails.test.mixin.web.ControllerUnitTestMixin} for usage instructions
 */
@TestFor(SimpleEditorController)
class SimpleEditorControllerTests {

    void testSomething() {
       fail "Implement me"
    }
}
