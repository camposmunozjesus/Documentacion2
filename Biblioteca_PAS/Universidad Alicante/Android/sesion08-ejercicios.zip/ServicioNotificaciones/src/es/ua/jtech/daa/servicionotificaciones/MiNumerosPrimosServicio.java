package es.ua.jtech.daa.servicionotificaciones;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

public class MiNumerosPrimosServicio extends Service {
	MiTarea miTarea;
	
	@Override
	public void onCreate() {
		super.onCreate();
		Toast.makeText(this,"Servicio de primos creado ...", Toast.LENGTH_LONG).show();
		Log.i("SRV","onCreate");
		miTarea = new MiTarea();
	}
	
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		Log.i("SRV", "onStartCommand");
		miTarea.execute();
		return Service.START_STICKY;
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		Toast.makeText(this,"Servicio de primos destruido ...", Toast.LENGTH_LONG).show();
		Log.i("SRV","Servicio destruido");
		miTarea.cancel(true);
	}

	@Override
	public IBinder onBind(Intent arg0) {
		return null;
	}


	//TODO Crear un método público estático que se llame
	//cerrarMiNotificacion(NotificationManager nm) y que
	//utilice el nm para cerrar la nodificación con id MiTarea.NOTIF_ID
	
	private class MiTarea extends AsyncTask<String, String, String>{
		private long i;
		private static final long MAXCOUNT = 100000;
		public static final int NOTIF_ID = 1;
		Notification notification;
		NotificationManager notificationManager;
		
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			i = 2;
			//TODO obtener el notificationManager de los servicios del sistema (getSystemService).

			//TODO crear una nueva notificación con 
			//icono R.drawable.icon, título "Primo descubierto" y tiempo System.currentTimeMillis()

		}

		@Override
		protected String doInBackground(String... params) {

			//TODO bucle hasta MAXCOUNT-1, que compruebe 
			//por cada numero i si es primo. Si lo es, 
			//publicar el progreso pasándoselo como parámetro String.

			return null;
		}

		private boolean esPrimo(long n) {
			boolean primo = true;
			for(long j = 2; j*j <= n; j++){
				if( i>= MAXCOUNT){
					primo = false; //abortar si cancelado.
					break;
				}
				try { //Pausar un poco
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
	            if (n % j == 0) {
	                primo = false;
	                break;
		        }
			}
			return primo;
		}

		@Override
		protected void onProgressUpdate(String... values) {
			
			//TODO Crear un Intent del Main.
			
			//TODO Crear un PendingIntent a partir del anterior,
			//para pasárselo a la notificación, y que ésta nos pueda devolver
			//a la actividad Main al pulsarla. (método PendingIntent.getActivity)
			
			//TODO poner setLatestEventInfo a la notificación, pasándole en
			//String la información del progreso (último primo descubierto) y
			//pasándole el PendingIntent.
			
			//TODO usar el notificationManager para notificar con la notificación
			//actualizada, y pasándole el mismo id, NOTIF_ID, para que no aparezca
			//como una nueva.
			
		}

		@Override
		protected void onCancelled() {
			super.onCancelled();
			i = MAXCOUNT;
		}
		
	}
}
