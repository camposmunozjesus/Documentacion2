package cxfserver

import javax.activation.DataHandler
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.xml.bind.annotation.XmlElement;
import javax.jws.WebService
import javax.xml.ws.soap.MTOM

import com.file.FileUploader
import grails.transaction.Transactional

@Transactional
@MTOM(enabled = true)
class MsendService {

	static expose=['cxfjax']
	
	@WebMethod(operationName="getSend") 
	String getSend(){
	  return "jesusS sssss"
	}
	
	@WebMethod(operationName="getText")
	void getText(FileUploader Dfile) {
		
		DataHandler handler = Dfile.getDfile();
		
		try {
			InputStream is = handler.getInputStream();
	
			OutputStream os = new FileOutputStream(new File("D:/uploads/texto.pdf"));
			byte[] b = new byte[100000];
			int bytesRead = 0;
			while ((bytesRead = is.read(b)) != -1) {
			os.write(b, 0, bytesRead);
			}
			os.flush();
			os.close();
			is.close();
	
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}
