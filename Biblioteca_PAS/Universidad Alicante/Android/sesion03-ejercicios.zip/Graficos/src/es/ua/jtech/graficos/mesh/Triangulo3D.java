package es.ua.jtech.graficos.mesh;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.opengles.GL10;

public class Triangulo3D {

    FloatBuffer buffer;  

    float[] vertices = { 
        -1f, -1f, 0f, 
        1f, -1f, 0f, 
        0f, 1f, 0f }; 
    

    public Triangulo3D() {
        ByteBuffer bufferTemporal = ByteBuffer.allocateDirect(vertices.length*4);
        bufferTemporal.order(ByteOrder.nativeOrder());
        buffer = bufferTemporal.asFloatBuffer();
        buffer.put(vertices);
        buffer.position(0);
    }
	
    public void dibujar(GL10 gl) {
        gl.glVertexPointer(3, GL10.GL_FLOAT, 0, buffer);
        gl.glDrawArrays(GL10.GL_TRIANGLES, 0, 3);
    }
}