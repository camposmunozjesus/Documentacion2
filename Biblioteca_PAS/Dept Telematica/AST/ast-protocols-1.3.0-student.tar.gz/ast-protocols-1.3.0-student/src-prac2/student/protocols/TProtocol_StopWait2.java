
package student.protocols;

import ast.protocols.transportCO.TProtocol;
import ast.protocols.transportCO.TCBlock;
import ast.protocols.tcp.TCPSegment;

import ast.util.CircularQueue;
import ast.util.ByteQueue;

import java.io.IOException;



// Connection oriented, stop and wait with an unsent queue.
// We assume an ideal IP layer with no losses and no errors in packets.
// See TProtocol_StopWait1 for the state diagram.
public class TProtocol_StopWait2 extends TProtocol_StopWait1 {

    @Override
    protected TCBlock newTCB(int port) {
        return new TCBlock_StopWait2(this, port);
    }

}


class TCBlock_StopWait2 extends TCBlock_StopWait1 {
    // Sender variables:
    protected static final int SND_MAXUNSENT = 10000; // Max number of bytes in unsent queue
    protected ByteQueue sndUnsentQueue; // (3)
        /* 1: Transmitted and acknowledged bytes
           2: Transmitted but not yet acknowledged bytes
           3: bytes in sndUnsentQueue (not yet transmitted)
                   1       2        3
              ----------+------+---------+---------
                        :      :        last buffered byte
                        :      first byte not yet transmitted
                        first transmitted byte not yet acknowledged
         */

    TCBlock_StopWait2(TProtocol proto, int port) {
        super(proto, port);
    }

    // initialize for new connection
    @Override
    protected void initActive(int remAddr, int remPort, int st) {
        remoteAddr = remAddr;
        remotePort = remPort;
        state = st;
        // sndMSS = IP message size (IP packet size - IP header size) - 20 (TCP header size)
        sndMSS = ipLayer.getMMS(remoteAddr) - 20;
        sndUnsentQueue = new ByteQueue(SND_MAXUNSENT);
        rcvQueue = new ByteQueue(sndMSS);
        sndIsUna = false;
        addActiveTCB(this);
    }

    @Override
    public void close() throws IOException {
        // To be completed by the student:
        throw new RuntimeException("NOT YET IMPLEMENTED (To be completed by the student)");
        // Hint: Take into account if there are bytes left in sndUnsentQueue
        //...
    }

    @Override
    public void sendData(byte[] data, int data_off, int data_len) throws IOException {
        lk.lock();
        try {
            log.debug("%1$s->sendData(length=%2$d)", this, data_len);
            int n = 0;
            while (data_len > n) {
                if (state != ESTABLISHED && state != CLOSE_WAIT) {
                    // transmission is closed
                    throw new IOException("connection does not exist");
                }
                // To be completed by the student:
                throw new RuntimeException("NOT YET IMPLEMENTED (To be completed by the student)");
                // wait send buffer space (sndUnsentQueue) is available
                //...
                // p == min(data_len - n, sndUnsentQueue.free())
                //...
                // put p bytes of data in sndUnsentQueue. Add p to n
                //...
                // Transmit segment if sender is not expecting an acknowledg
                if (! sndIsUna) {
                    // To be completed by the student:
                    throw new RuntimeException("NOT YET IMPLEMENTED (To be completed by the student)");
                    // get data from sndUnsentQueue, create segment and send it
                    //...
                }
                logDebugState();
            }
        } finally {
            lk.unlock();
        }
    }

    @Override
    protected void processReceivedSegment(int sourceAddr, TCPSegment rseg) {
        lk.lock();
        try{
            switch (state) {
            case LISTEN: {
                if (rseg.isAck()) {
                    // Any acknowledgment is bad if it arrives on a connection still in
                    // the LISTEN state. Ignore it
                    return;
                }
                if (rseg.isSyn()) {
                    if (acceptQueue.full()) {
                        log.warn(
                          "%1$s->processReceivedSegment: Backlog queue is full. SYN IS LOST !!!",
                          this);
                        return;
                    }
                    // create TCB for new connection
                    TCBlock_StopWait2 ntcb = (TCBlock_StopWait2) newTCB();
                    ntcb.initActive(sourceAddr, rseg.getSourcePort(), ESTABLISHED);
                    // To be completed by the student:
                    throw new RuntimeException("NOT YET IMPLEMENTED (To be completed by the student)");
                    // prepare the created connection for accept
                    //...
                    // send SYN segment for new connection
                    //...
                    ntcb.logDebugState();
                }
                break;
            }
            case SYN_SENT: {
                if (rseg.isSyn()) {
                    // To be completed by the student:
                    throw new RuntimeException("NOT YET IMPLEMENTED (To be completed by the student)");
                    // Change state and wake up connect() thread
                    //...
                    logDebugState();
                }
                break;
            }
            case ESTABLISHED:
            case FIN_WAIT:
            case CLOSE_WAIT: {
                // Check SYN bit
                if (rseg.isSyn()) {
                    // A SYN is bad if it arrives on a connection in an active state. Ignore it
                    return;
                }
                // Check ACK bit
                if (rseg.isAck()) {
                    // To be completed by the student:
                    throw new RuntimeException("NOT YET IMPLEMENTED (To be completed by the student)");
                    // send unsent data if any, change sndIsUna accordingly, etc.
                    //...
                    logDebugState();
                }
                // Process segment text
                if (rseg.getDataLength() > 0) {
                    if (state == ESTABLISHED || state == FIN_WAIT) {
                        // To be completed by the student:
                        throw new RuntimeException("NOT YET IMPLEMENTED (To be completed by the student)");
                        logDebugState(); 
                    } else {
                        // This should not occur, since a FIN has been received from the
                        // remote side.  Ignore the segment text.
                    }
                }
                // Check FIN bit
                if (rseg.isFin()) {
                    if (state == ESTABLISHED) {
                        state = CLOSE_WAIT;
                    } else if (state == FIN_WAIT) {
                        state = CLOSED;
                        removeActiveTCB(this);
                    }
                    appCV.signalAll(); // wake up receiveData() thread
                    logDebugState();
                }
                break;
            }
            default:
                // Segment is ignored
            }
        } finally {
            lk.unlock();
        }
    }

    @Override
    public String stateToString() {
        StringBuilder buf = new StringBuilder();
        String sst;
        switch (state) {
            case CLOSED:      sst = "CLOSED"; break;
            case LISTEN:      sst = "LISTEN"; break;
            case SYN_SENT:    sst = "SYN_SENT"; break;
            case ESTABLISHED: sst = "ESTABLISHED"; break;
            case FIN_WAIT:    sst = "FIN_WAIT"; break;
            case CLOSE_WAIT:  sst = "CLOSE_WAIT"; break;
            default: sst = "?";
        }
        buf.append("{").append(sst);
        if (acceptQueue != null) {
            // pasive state
            buf.append(",acceptQueue.size=").append(acceptQueue.size());
        } else {
            // active state
            buf.append(",sndUnsentQueue.size=").append(sndUnsentQueue.size());
            buf.append(",sndIsUna=").append(sndIsUna);
            buf.append(",rcvQueue.size=").append(rcvQueue.size());
        }
        return buf.append("}").toString();
    }

}


