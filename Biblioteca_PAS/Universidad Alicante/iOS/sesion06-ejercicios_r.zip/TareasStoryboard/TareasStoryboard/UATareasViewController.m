//
//  UATareasViewController.m
//  TareasStoryboard
//
//  Created by Miguel Angel Lozano on 08/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "UATareasViewController.h"

@interface UATareasViewController ()

@end

@implementation UATareasViewController

@synthesize tareas = _tareas;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    self.navigationItem.leftBarButtonItem = self.editButtonItem;
    self.tareas = [NSMutableArray arrayWithCapacity:10];
        
    // Carga los datos del fichero (si existe)
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    if ([paths count] > 0)
    {
        NSString *directory = [paths objectAtIndex:0];
        NSString *filename = [directory 
                              stringByAppendingPathComponent:@"tareas.plist"];

        BOOL fileExists = [[NSFileManager defaultManager] fileExistsAtPath:filename];  
        if (fileExists) {
            self.tareas = [NSMutableArray arrayWithContentsOfFile:filename];                
        }
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(save) name:UIApplicationDidEnterBackgroundNotification object:nil];
}

- (void)save {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    if ([paths count] > 0)
    {
        NSString *directory = [paths objectAtIndex:0];
        NSString *filename = [directory 
                              stringByAppendingPathComponent:@"tareas.plist"];
        
        BOOL guardado = [self.tareas writeToFile:filename 
                                      atomically:YES];
        NSLog(@"Guardado %d", guardado);
    }
}

- (void)viewDidUnload
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return [self.tareas count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"TareaCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    // Configure the cell...
    cell.textLabel.text = [self.tareas objectAtIndex:indexPath.row];
    
    return cell;
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [self.tareas removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}

// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
    NSString *tarea = [self.tareas objectAtIndex:fromIndexPath.row];
    [self.tareas removeObjectAtIndex:fromIndexPath.row];
    [self.tareas insertObject:tarea atIndex:toIndexPath.row];
}


- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if([segue.identifier isEqualToString:@"TareaSeleccionada"]) {
        UATareaViewController *controller = segue.destinationViewController;
        controller.delegate = self;
        controller.indexPath = self.tableView.indexPathForSelectedRow;
        controller.tarea = [self.tareas objectAtIndex:self.tableView.indexPathForSelectedRow.row];
    }
}

- (void)addTarea:(id)sender {
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:[self.tareas count] inSection:0];
    [self.tareas addObject:@"Tarea sin nombre"];
    [self.tableView insertRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationTop];
}

- (void)tareaViewController:(UATareaViewController *)controller didChangeTarea:(NSString *)tarea atIndexPath:(NSIndexPath *)indexPath {
    [self.tareas replaceObjectAtIndex:indexPath.row withObject:tarea];
    [self.tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
}

@end
