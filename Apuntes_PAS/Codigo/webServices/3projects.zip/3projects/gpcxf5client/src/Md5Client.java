import gpcxf5.MtomService;
import gpcxf5.MtomServiceService;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.xml.namespace.QName;
import javax.xml.ws.soap.MTOMFeature;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.Random;

public class Md5Client {

    public static final int FILE_SIZE = 1024 * 1024 * 1;

    public static void main(String args[]) throws java.lang.Exception {
        final URL wsdlLocation = Md5Client.class.getResource("mtom.xml");
        final MtomServiceService ss = new MtomServiceService(wsdlLocation, new QName("http://gpcxf5/", "MtomServiceService"));
        final MtomService port = ss.getMtomServicePort(new MTOMFeature(true, 1024));

        System.out.printf("Creating a big file (%dM)\n", FILE_SIZE / 1024 / 1024);
        final File tempFile = createTempFile();
        try {
            final FileDataSource fileDataSource = new FileDataSource(tempFile);
            final DataHandler dataHandler = new DataHandler(fileDataSource);
            System.out.println("Sending the file");
            final String s = port.md5FileCalculator(dataHandler);
            System.out.println("MD5 = " + s);
        } finally {
            if (!tempFile.delete()) {
                System.err.println("Failed to delete " + tempFile.getAbsolutePath());
            }
        }
    }

    static File createTempFile() throws IOException {
        final File tempFile = File.createTempFile("gpcxf5", null);

        try (FileOutputStream fileOutputStream = new FileOutputStream(tempFile)) {
            final byte[] buffer = new byte[1024 * 4];
            final Random random = new Random();
            for (long size = 0; size < FILE_SIZE; size += buffer.length) {
                random.nextBytes(buffer);
                fileOutputStream.write(buffer);
            }
        }
        return tempFile;
    }
}
