package org.weceem.content

class WcmContent {

	static MAX_CONTENT_SIZE = 500000
	
	int identity
	String aliasuri
//	String name
	String title
	String content
	int space
	
	
	static mapping = {
		table name: "wcm_content"
		id name:'identity'
		id generator:'assigned'
		version false
		
		identity column: 'id'
		space column: 'space_id'
	}
			
	static constraints = {
		content(nullable: false, maxSize: WcmContent.MAX_CONTENT_SIZE)
	}
}
