package es.ua.jtech.ajdm.juego;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class MIDletJuego extends MIDlet {

	protected void startApp() throws MIDletStateChangeException {
		Display d = Display.getDisplay(this);
		CanvasJuego juego = new CanvasJuego(this);
		d.setCurrent(juego);
	}

	protected void pauseApp() {

	}

	protected void destroyApp(boolean arg0) throws MIDletStateChangeException {

	}

}
