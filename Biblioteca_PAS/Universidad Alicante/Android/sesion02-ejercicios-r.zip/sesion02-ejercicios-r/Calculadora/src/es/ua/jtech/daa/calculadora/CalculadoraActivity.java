package es.ua.jtech.daa.calculadora;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class CalculadoraActivity extends Activity {
	
	private static final int SUMA = 1;
	private static final int RESTA = 2;
	private static final int MULT = 3;
	private static final int DIV = 4;
	
    
	Spinner operaciones;
	TextView resultado;
	EditText operando1, operando2;
	Button botonok;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        resultado = (TextView)findViewById(R.id.resultado);
        operando1 = (EditText)findViewById(R.id.operando1);
        operando2 = (EditText)findViewById(R.id.operando2);
        botonok = (Button)findViewById(R.id.botonok);
        operaciones = (Spinner)findViewById(R.id.operador);
        ArrayAdapter<CharSequence> adaptador = ArrayAdapter.createFromResource(
                this, R.array.operaciones, android.R.layout.simple_spinner_item);
        adaptador.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        operaciones.setAdapter(adaptador);
        
        botonok.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				String operacion = operaciones.getSelectedItem().toString();
				int operacionInt= 0;
				int operando1Int, operando2Int, resultadoInt = 0;
				
				if (operacion.equals("+")) operacionInt = SUMA;
				if (operacion.equals("-")) operacionInt = RESTA;
				if (operacion.equals("*")) operacionInt = MULT;
				if (operacion.equals("/")) operacionInt = DIV;
				
				operando1Int = Integer.parseInt(operando1.getText().toString());
				operando2Int = Integer.parseInt(operando2.getText().toString());
				
				switch(operacionInt) {
				case SUMA:
					resultadoInt = operando1Int + operando2Int;
					break;
				case RESTA:
					resultadoInt = operando1Int - operando2Int;
					break;
				case MULT:
					resultadoInt = operando1Int * operando2Int;
					break;
				case DIV:
					resultadoInt = operando1Int / operando2Int;
					break;
				}
				
				resultado.setText(new Integer(resultadoInt).toString());
			}
        });
    }
}