//
//  MiToolBar.m
//  uisesion02-ejemplo3
//
//  Created by Javier Aznar de los Rios on 26/09/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MiToolBar.h"


@implementation MiToolBar

- (void)drawRect:(CGRect)rect {

    UIColor *color = [UIColor colorWithRed:0.547 green:0.344 blue:0.118 alpha:1.000]; //wood tan color
    UIImage *img  = [UIImage imageNamed: @"fondo_madera.png"];
    [img drawInRect:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
    [img release];
    self.tintColor = color;
 
    [super drawRect:rect];
}

@end
