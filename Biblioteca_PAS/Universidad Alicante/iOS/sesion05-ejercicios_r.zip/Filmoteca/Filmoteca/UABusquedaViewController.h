//
//  BusquedaController.h
//  Filmoteca
//
//  Created by Miguel Angel Lozano on 28/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UABusquedaViewController : UITableViewController<UISearchDisplayDelegate>

@property(nonatomic,strong) NSArray *peliculas;
@property(nonatomic,strong) NSArray *peliculasFiltradas;


@end
