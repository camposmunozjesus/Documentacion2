package es.ua.jtech.daa.lectorrss;


public class Noticia {

}
