//
//  uisesion02_ejemplo3ViewController.m
//  uisesion02-ejemplo3
//
//  Created by Javier Aznar de los Rios on 24/09/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "uisesion02_ejemplo3ViewController.h"

@implementation uisesion02_ejemplo3ViewController

@synthesize segmentedControl=_segmentedControl;
@synthesize textField=_textField;
@synthesize toolBar=_toolBar;
@synthesize segmentLabel=_segmentLabel;

- (void)dealloc
{
    [super dealloc];
}

-(IBAction) segmentedControlIndexChanged{
	switch (self.segmentedControl.selectedSegmentIndex) {
		case 0:
			self.segmentLabel.text = @"Segmento 1 seleccionado.";
			break;
		case 1:
			self.segmentLabel.text = @"Segmento 2 seleccionado.";
			break;
            
		default:
            break;
    }
    
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Asignamos la imagen de fondo para el toolbar
    UIImageView *iv = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"fondo_madera.png"]];
    iv.frame = CGRectMake(0, 0, _toolBar.frame.size.width, _toolBar.frame.size.height);
    iv.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    
    // Añadimos la imagen al toolbar
    if([[[UIDevice currentDevice] systemVersion] intValue] >= 5)
        [_toolBar insertSubview:iv atIndex:1]; // iOS5 atIndex:1
    else
        [_toolBar insertSubview:iv atIndex:0]; // iOS4 atIndex:0
    
    
    // Añadimos color al Segmented Control
    [_segmentedControl setTintColor:[UIColor brownColor]];
    
    // Personalizamos el text field:
    _textField.textAlignment = UITextAlignmentCenter; //centramos el texto
    _textField.textColor = [UIColor whiteColor]; //texto de color blanco
    _textField.borderStyle = UITextBorderStyleNone; //quitamos el borde del campo
    _textField.background = [UIImage imageNamed:@"fondo_textfield.png"]; //añadimos la imagen de fondo
    [_textField setPlaceholder:@"Escribe aquí"]; //texto inicial
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
