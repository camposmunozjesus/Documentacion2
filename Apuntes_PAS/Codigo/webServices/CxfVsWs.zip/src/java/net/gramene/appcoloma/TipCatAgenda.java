
package net.gramene.appcoloma;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TipCatAgenda complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TipCatAgenda">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="intIdNivell" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="intIdNivellPare" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="intNivell" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="strNivell" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TipCatAgenda", propOrder = {
    "intIdNivell",
    "intIdNivellPare",
    "intNivell",
    "strNivell"
})
public class TipCatAgenda {

    protected long intIdNivell;
    protected long intIdNivellPare;
    protected short intNivell;
    protected String strNivell;

    /**
     * Gets the value of the intIdNivell property.
     * 
     */
    public long getIntIdNivell() {
        return intIdNivell;
    }

    /**
     * Sets the value of the intIdNivell property.
     * 
     */
    public void setIntIdNivell(long value) {
        this.intIdNivell = value;
    }

    /**
     * Gets the value of the intIdNivellPare property.
     * 
     */
    public long getIntIdNivellPare() {
        return intIdNivellPare;
    }

    /**
     * Sets the value of the intIdNivellPare property.
     * 
     */
    public void setIntIdNivellPare(long value) {
        this.intIdNivellPare = value;
    }

    /**
     * Gets the value of the intNivell property.
     * 
     */
    public short getIntNivell() {
        return intNivell;
    }

    /**
     * Sets the value of the intNivell property.
     * 
     */
    public void setIntNivell(short value) {
        this.intNivell = value;
    }

    /**
     * Gets the value of the strNivell property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrNivell() {
        return strNivell;
    }

    /**
     * Sets the value of the strNivell property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrNivell(String value) {
        this.strNivell = value;
    }

}
