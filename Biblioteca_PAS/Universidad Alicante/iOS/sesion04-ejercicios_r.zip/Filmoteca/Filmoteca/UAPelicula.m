//
//  UAPelicula.m
//  Filmoteca
//
//  Created by Miguel Angel Lozano on 20/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "UAPelicula.h"

@implementation UAPelicula

@synthesize titulo = _titulo;
@synthesize director = _director;
@synthesize calificacion = _calificacion;
@synthesize puntuacion = _puntuacion;
@synthesize estreno = _estreno;
@synthesize actores = _actores;
@synthesize cartel = _cartel;

#pragma mark Inicializadores

- (id)init {
    return [self initWithTitulo:@"Sin titulo"];
}

- (id)initWithTitulo:(NSString *)titulo {
    return [self initWithTitulo:titulo director:@"Desconocido" calificacion:TP puntuacion:-1 estreno:[NSDate date]];
}

- (id)initWithTitulo:(NSString *)titulo director:(NSString *)director calificacion:(UACalificacionEdad)calificacion puntuacion:(CGFloat)puntuacion estreno:(NSDate *)estreno {
    
    self = [super init];
    if(self!=nil) {
        _titulo = titulo;
        _director = director;
        _calificacion = calificacion;
        _puntuacion = puntuacion;   
        _estreno = estreno;
    }
    return self;
}

#pragma mark Metodos factoria

+ (id)pelicula {
    return [[self alloc] init];
}

+ (id)peliculaWithTitulo:(NSString *)titulo {
    return [[self alloc] initWithTitulo:titulo];
}

+ (id)peliculaWithTitulo:(NSString *)titulo director:(NSString *)director calificacion:(UACalificacionEdad)calificacion puntuacion:(CGFloat)puntuacion estreno:(NSDate *)estreno {
    return [[self alloc] initWithTitulo:titulo director:director calificacion:calificacion puntuacion:puntuacion estreno:estreno];
}

#pragma mark Metodos de UAPelicula

- (NSInteger)antiguedad {
    NSDateComponents *comps = [[NSCalendar currentCalendar] components: NSYearCalendarUnit fromDate:_estreno toDate:[NSDate date] options:0];
    return [comps year];
}


#pragma mark Metodos de NSObject


- (NSString *)description {
    NSDateComponents *comps = [[NSCalendar currentCalendar] components: NSYearCalendarUnit fromDate:_estreno];
    return [NSString stringWithFormat:@"%@ (%d, %@)", _titulo, [comps year], _director];
}

@end
