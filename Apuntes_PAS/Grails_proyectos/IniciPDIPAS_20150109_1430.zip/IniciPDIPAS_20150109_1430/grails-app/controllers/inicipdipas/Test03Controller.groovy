package inicipdipas

import org.weceem.content.WcmContent
import org.weceem.content.WcmSpace

/**
 * 
 * @author Jesus Campos
 * La idea es que pasada la URL la parsee y aceda a ella. Se pretende hacer el visor entero del Weceem.
 * Este FALLA. No subtituye t�tulos ni logged etc
 */
class Test03Controller {

    def index() {

//		println request.forwardURI
//		def values = request.forwardURI.toString().split("/")
//		//Pagina
//		def page = values[values.size()-1]
//		println page
//		
//		//Carga de la p�gina Inici
//		def pageContent = WcmContent.findByAliasuriAndSpace(page, 2711)
//		def template = pageContent.tmpl
//		println template
//		
//		//Carga del template
//		def pageTemplate = WcmContent.findByIdentityAndSpace(template, 2711)
//		
//		
//		def webPage = pageTemplate.content.replace("<wcm:content />", pageContent.content)
//		println pageTemplate.content
//		
//		//Para Grails 2.4.3
//		webPage = webPage.replace("/Portal/PAS/", "/IniciPDIPAS/")
//		//
//		webPage = webPage.replace("\${wcm.loggedInUserName().encodeAsHTML()}", "")
//		
//		webPage = webPage.replace("\${node.title.encodeAsHTML()}", pageContent.title)
//		
//		//Redirecci�n de la p�gina
//		//${grails.util.Metadata.current.'app.name'}/${space?.name}/index/Informacio_General
//		webPage = webPage.replace("\${grails.util.Metadata.current.'app.name'}", "Portal")
//		webPage = webPage.replace("\${space?.name}", "PAS")
//		
//		if(webPage.contains("<upc:search max=\"15\" eraseplaceholder=\"no\" placeholder=\"Cercar...\" types=\"com.upc.WcmPlantillaFitxa\"></upc:search>")){
//			webPage = webPage.replace("<upc:search max=\"15\" eraseplaceholder=\"no\" placeholder=\"Cercar...\" types=\"com.upc.WcmPlantillaFitxa\"></upc:search>", "<form action=\"https://melnik.upc.edu/Portal/cms/tools/search?uri=PAS%2F&amp;max=15&amp;erasePlaceHolder=no&amp;placeHolder=Cercar...&amp;types=com.upc.WcmPlantillaFitxa\" method=\"post\"><input name=\"query\" class=\"customSearchField\" placeholder=\"Cercar...\" onfocus=\"\" value=\"\" id=\"query\" type=\"text\"><input name=\"submit\" class=\"customSearchButton\" value=\"Cerca\" id=\"submit\" type=\"submit\"></form>")
//		}
//		
////		println webPage
//		render(text: webPage, contentType: "text/html", encoding: "UTF-8")
		
		// ******************************************************************************** //
		
		def url = "/PAS/index"
//		def url = "/PAS/index/Informacio_General/El-PAS-a-la-UPC"
		def values = url.toString().split("/")
		//Pagina
		def page = values[values.size()-1]
		println page
		
		//Carga de la p�gina Inici
		def pageContent = WcmContent.findByAliasuriAndSpace(page, 2711)
//		println pageContent.title
//		println pageContent.content
		def template
		def webPage
		if(pageContent.tmpl)
		{
			template= pageContent.tmpl
			println template
		
		
			//Carga del template
			def pageTemplate = WcmContent.findByIdentityAndSpace(template, 2711)
	//		println pageTemplate.title
	//		println pageTemplate.content
	//		pageTemplate.content = pageTemplate.content.replace("max=\"15\" eraseplaceholder=\"no\" placeholder=\"Cercar...\" types=\"com.", "BUSCADOR PROPIO UPC")
			println pageTemplate.content
			
			webPage = pageTemplate.content.replace("<wcm:content />", pageContent.content)
		}
		
		//Para Grails 2.4.3
		webPage = webPage.replace("/Portal/PAS/", "/IniciPDIPAS/")
		//
		webPage = webPage.replace("\${wcm.loggedInUserName().encodeAsHTML()}", "")
		
		if(webPage.contains("\${node.title.encodeAsHTML()}")){
			println "WEB CONTAINS TITLE"
		}
		else{
			println "WEB NOT CONTAINS TITLE"
		}
		
		
		//Redirecci�n de la p�gina
		//${grails.util.Metadata.current.'app.name'}/${space?.name}/index/Informacio_General
		webPage = webPage.replace("\${grails.util.Metadata.current.'app.name'}", "Portal")
		webPage = webPage.replace("\${space?.name}", "PAS")
		
//		//Buscador
//		if(webPage.contains("<upc:search max=\"15\" eraseplaceholder=\"no\" placeholder=\"Cercar...\" types=\"com.upc.WcmPlantillaFitxa\"></upc:search>")){
//			webPage = webPage.replace("<upc:search max=\"15\" eraseplaceholder=\"no\" placeholder=\"Cercar...\" types=\"com.upc.WcmPlantillaFitxa\"></upc:search>", "<form action=\"https://melnik.upc.edu/Portal/cms/tools/search?uri=PAS%2F&amp;max=15&amp;erasePlaceHolder=no&amp;placeHolder=Cercar...&amp;types=com.upc.WcmPlantillaFitxa\" method=\"post\"><input name=\"query\" class=\"customSearchField\" placeholder=\"Cercar...\" onfocus=\"\" value=\"\" id=\"query\" type=\"text\"><input name=\"submit\" class=\"customSearchButton\" value=\"Cerca\" id=\"submit\" type=\"submit\"></form>")
//		}
		
//		webPage = webPage.replace("\${params.", "PAS")
		
		//P�ginas con men� lateral con la opci�n seleccionada marcada.
//		if(webPage.contains("params.desplegableSelected")){
//			webPage = webPage.replace("params.desplegableSelected", page)
//		}
		

//		println webPage		
//		println pageContent.title	
		
		render(text: webPage, contentType: "text/html", encoding: "UTF-8")
	
    }
}
