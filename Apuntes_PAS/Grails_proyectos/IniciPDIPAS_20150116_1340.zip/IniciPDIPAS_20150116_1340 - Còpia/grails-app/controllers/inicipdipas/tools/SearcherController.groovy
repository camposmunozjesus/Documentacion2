package inicipdipas.tools

import org.weceem.content.WcmContent

/**
 * Buscador del CMS.
 * @author Jesus Campos
 * @version 1.0
 * @since 15 Enero de 2015
 */
class SearcherController {

	static DRAFT_VALUE = 2406
	static UNMODERATED_VALUE = 2407
	static REVIEWED_VALUE = 2408
	static APPROVED_VALUE = 2409
	static PUBLISHED_VALUE = 2410
	static ARCHIVED_VALUE = 2411
		
//	static allowedMethods = [index: "GET"]
	
	def static allowedTypes = ['org.weceem.html.WcmHTMLContent', 'com.upc.WcmPlantillaFitxa', 'com.upc.WcmPlantillaFitxa2ColGenerica', 'com.upc.WcmPlantillaFitxaGenerica']
//	def static allowedTypes = ['com.upc.WcmPlantillaFitxa', 'com.upc.WcmPlantillaFitxa2ColGenerica', 'com.upc.WcmPlantillaFitxaGenerica']
//	def static allowedTypes = ['org.weceem.html.WcmHTMLContent']
	def spaceId = 2711		//Conseguir el space a partir del perfil del usuario !!!
	def spaceName = "PAS"
	def informacioGeneralId = 2810

	def index() {
		
		params.max=10
		
		def query = {
			and{
				eq("space", spaceId)
				eq("status", PUBLISHED_VALUE)
				'in'("type", allowedTypes)
				or{
					ilike("aliasuri", "%"+ params.query +"%")
					ilike("content", "%"+ params.query +"%")
				}
			}
			
		}
		
		//Carga de las coincidencias de la b�squeda
		def resultList = WcmContent.createCriteria().list(params,query)
		def results = resultList.getTotalCount()
		
//		def regexp = /href=\"*+\/${params.query}\/\"/ -> Esto encuentra un rango muy amplio
		//Para buscar algo del tipo href="/IniciPDIPAS/..../${params.query}/...." -> Si la p�gina tiene s�lo estas coincidencias
		//ser� descartada para mostrarla en el buscador. Puede darse el caso de buscar la palabra "PAS" en el y que entren
		//en la lista de resultados todas las palabras que contengan enlaces a archivos y fichas, ejemplo:
		// <a href="/IniciPDIPAS/PAS/index/Sistema-retributiu">Sistema retributiu</a>
		def regexp = /href=.*${params.query}.*\"/

		def listaDefinitiva = []
		//Conseguir la url completa para los resultados que se mostrar�n en pantalla.
		resultList.each {
			println "iteracion i: "+i
			if(it.content =~ regexp){
				println "**************************** no es solo href "+new Date()+it.aliasuri
			}
			println "Tama�o de la busqueda simple : "+(it.content =~ /${params.query}/).size()
			println "Tama�o de la busqueda de href: "+(it.content =~ regexp).size()
			(it.content =~ regexp).each{
				println "cada ocurrencia:"
				println it
			}
			
			if((it.content =~ /${params.query}/).size()!=(it.content =~ regexp).size()){
				listaDefinitiva << it
				it.absoluteURI=getAbsoluteURI(it.identity, it.aliasuri, it.parent)
			}
				
		}
		
		if(resultList){
			 println resultList.title
			 println resultList.identity
			 println resultList.space
			 println resultList.aliasuri
			 println resultList.status
			 println "absoluteURI"+resultList.absoluteURI
		}
		
		[space:spaceName, resultList:listaDefinitiva, total:results, spaceName:spaceName]
	}
	
	/**
	 * Se sabe que una p&aacute;gina (ficha de dos columnas o ficha simple) va a estar ubicada en:<br>
	 * <ul>
	 * 	<li>En el caso de una ficha de dos columnas (com.upc.WcmPlantillaFitxa2ColGenerica): http://servidor/IniciPDIPAS/PAS/index/Informacio_General/El-PAS-a-la-UPC</li>
	 * 	<li>En el caso de una ficha (com.upc.WcmPlantillaFitxa, com.upc.WcmPlantillaFitxaGenerica): http://servidor/IniciPDIPAS/PAS/index/Informacio_General/El-PAS-a-la-UPC/Personal-Funcionari</li>
	 * </ul>
	 * Por lo que la ruta http://servidor/IniciPDIPAS/PAS/index/Informacio_General/ va a ser fija. Entonces para el caso de las
	 * fichas desplegables con dos columnas la ruta absoluta no implicar&aacute; ning&aacute;n acceso adicional a la base de datos. Se 
	 * formar&aacute; con el aliasuri de la p&aacute;gina encontrada y el String anterior. En el caso de una ficha se necesitar&aacute; un acceso a
	 * base de datos para obtener el elemento que falta, en el ejemplo "El-PAS-a-la-UPC".
	 * @param id Identificador de la p&aacute;gina de la que buscar su ruta absoluta.
	 * @param alias Nombre de la p&aacute;gina de la que buscar su ruta absoluta.
	 * @param parentId Identifidcador del elemnto padre.
	 * @return Un String con el path absoluto para poder acceder a la p&aacute;gina web.
	 */
	private String getAbsoluteURI(def id, def alias, def parentId){
		def path = "/${grails.util.Metadata.current.'app.name'}/${spaceName}/index/"
		
		if(parentId == informacioGeneralId){
			return path+alias
		}
		else{
			//Conseguir el alias uri de la ficha de dos columnas (com.upc.WcmPlantillaFitxa2ColGenerica).
			//No se controla si es nulo el resultado de la operaci�n porque no puede serlo, entre Informacio_General 
			//y la p�gina forzosamente ha de existir otra p�gina.
			//parentId es el id(�nico) de otro contenido.
			def result = WcmContent.findByIdentity(parentId)
			
			if(parentId && result.aliasuri)
				return path+result.aliasuri+"/"+alias
		}
	}
	
	def search(){
		println "Entrando en serach "+new Date()
	}
}
