package org.weceem.content

class WcmContent {

	static MAX_CONTENT_SIZE = 500000
	
	int identity
	String aliasuri
//	String name
	String title
	String content
	int space
	Integer tmpl
	String type
	
	//
	String keywords
	String menuTitle
	String htmlTitle
	String description
	Integer status
	
	//
	def absoluteURI
	Integer parent	
	
	static mapping = {
		table name: "wcm_content"
		id name:'identity'
		id generator:'assigned'
		version false
		
		identity column: 'id'
		space column: 'space_id'
		tmpl column: 'template_id'
		type column: 'class'
		menuTitle column: 'menu_title'
		htmlTitle column: 'html_title'
		status column: 'status_id'
		parent column: 'parent_id'

	}
			
	static constraints = {
		content(nullable: false, maxSize: WcmContent.MAX_CONTENT_SIZE)

	}
}

