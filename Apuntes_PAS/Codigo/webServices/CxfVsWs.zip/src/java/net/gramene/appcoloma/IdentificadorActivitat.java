
package net.gramene.appcoloma;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for IdentificadorActivitat complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="IdentificadorActivitat">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="intIdFitxa" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="strDescripcio" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="strImatge" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="strCentre" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdentificadorActivitat", propOrder = {
    "intIdFitxa",
    "strDescripcio",
    "strImatge",
    "strCentre"
})
public class IdentificadorActivitat {

    protected long intIdFitxa;
    protected String strDescripcio;
    protected String strImatge;
    protected String strCentre;

    /**
     * Gets the value of the intIdFitxa property.
     * 
     */
    public long getIntIdFitxa() {
        return intIdFitxa;
    }

    /**
     * Sets the value of the intIdFitxa property.
     * 
     */
    public void setIntIdFitxa(long value) {
        this.intIdFitxa = value;
    }

    /**
     * Gets the value of the strDescripcio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrDescripcio() {
        return strDescripcio;
    }

    /**
     * Sets the value of the strDescripcio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrDescripcio(String value) {
        this.strDescripcio = value;
    }

    /**
     * Gets the value of the strImatge property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrImatge() {
        return strImatge;
    }

    /**
     * Sets the value of the strImatge property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrImatge(String value) {
        this.strImatge = value;
    }

    /**
     * Gets the value of the strCentre property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrCentre() {
        return strCentre;
    }

    /**
     * Sets the value of the strCentre property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrCentre(String value) {
        this.strCentre = value;
    }

}
