//
//  uisesion02_ejemplo3AppDelegate.h
//  uisesion02-ejemplo3
//
//  Created by Javier Aznar de los Rios on 24/09/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class uisesion02_ejemplo3ViewController;

@interface uisesion02_ejemplo3AppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet uisesion02_ejemplo3ViewController *viewController;

@end
