/*
 * Created on 12-sep-2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package es.ua.jtech.tienda;
import java.io.*;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class Producto {
	String titulo;
	String tipo;
	String autor;
	int precio;
	boolean stock;

	public Producto(String titulo, String tipo, String autor, int precio, boolean stock) {
		this.titulo = titulo;
		this.tipo = tipo;
		this.autor = autor;
		this.precio = precio;
		this.stock = stock;
	}
	
	public void serialize(OutputStream out) throws IOException {
		DataOutputStream dos = new DataOutputStream(out);
		
		dos.writeUTF(titulo);
		dos.writeUTF(tipo);
		dos.writeUTF(autor);
		dos.writeInt(precio);
		dos.writeBoolean(stock);

	}
}
