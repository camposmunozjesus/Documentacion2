package es.ua.jtech.ajdm.s15;

import java.net.URL;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import android.app.Activity;
import android.os.Bundle;
import android.text.util.Linkify;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Main extends Activity {
    /** Called when the activity is first created. */
	TextView textView;
	EditText editText;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        textView = (TextView)findViewById(R.id.TextView01);
        editText = (EditText)findViewById(R.id.EditText01);
        editText.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(View v, int keyCode, KeyEvent event) {
		        if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)) {
		            // Perform action on key press
		        	accionDescargar();
		        	return true;
		          }
		          return false;
			}
		});
        ((Button)findViewById(R.id.Button01)).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				accionDescargar();
			}
		});

        
		
   }
   void accionDescargar(){
		try {
			URL text = new URL(editText.getText().toString());

			textView.setText("");
			
			XmlPullParserFactory parserCreator = XmlPullParserFactory
					.newInstance();
			XmlPullParser parser = parserCreator.newPullParser();
			parser.setInput(text.openStream(), null);
			int parserEvent = parser.getEventType();
			while (parserEvent != XmlPullParser.END_DOCUMENT) {
				switch (parserEvent) {
				case XmlPullParser.START_TAG:
					String tag = parser.getName();
					if (tag.equalsIgnoreCase("item")) {
						parserEvent = parser.next();
						boolean itemClosed = false;
						while (parserEvent != XmlPullParser.END_DOCUMENT && !itemClosed) {
							switch (parserEvent) {
							case XmlPullParser.START_TAG:
								tag = parser.getName();
								if (tag.equalsIgnoreCase("title")) {
									textView.append("Title: " + parser.nextText()+"\n");
								}
								if (tag.equalsIgnoreCase("link")) {
									textView.append("Link: "+parser.nextText()+"\n");
								}
								break;
							case XmlPullParser.END_TAG:
								tag = parser.getName();
								if(tag.equalsIgnoreCase("item")){
									itemClosed = true;
									textView.append("-\n");
								}
								break;
							}
							parserEvent = parser.next();
						}
					}
					break;
				}
				parserEvent = parser.next();

			}
		} catch (Exception e) {
			Log.e("Net", "Error in network call", e);
		}
		textView.append("--\n");
		Linkify.addLinks(textView, Linkify.WEB_URLS);
   }
}