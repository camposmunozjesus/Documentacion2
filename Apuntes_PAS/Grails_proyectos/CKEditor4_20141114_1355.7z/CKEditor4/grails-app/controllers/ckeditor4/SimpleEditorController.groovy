package ckeditor4

class SimpleEditorController {

    def index() { }
}
