package es.ua.jtech.ajdm.excepciones;
public class Ej2 {

	public static double logaritmo(String entrada) throws WrongParameterException {

		double num;
		try {
			num = Double.parseDouble(entrada);			
		} catch(NumberFormatException e) {
			throw new WrongParameterException("El parametro debe ser un numero", e);
		}

		if (num <= 0) {
			throw new WrongParameterException("El parametro debe ser positivo");
		}

		return Math.log(num);
	}

	public static void main(String[] args) {

		try {
			System.out.println("Logaritmo = " + logaritmo(args[0]));
		} catch (WrongParameterException e) {
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace();
		}
	}
}