package es.ua.jtech.daa.calculadora;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class CalculadoraActivity extends Activity {
	    
	Spinner operaciones;
	TextView resultado;
	EditText operando1, operando2;
	Button botonok;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        /** TODO los findViewByID( ... ) */
        
        
        /** TODO asigna un adaptador al Spinner creándolo desde el recurso R.array.operaciones **/
        
        botonok.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				String operacion = operaciones.getSelectedItem().toString();
				
				/** TODO 
				 * Los operandos se pueden obtener como cadenas de texto en 
				 * operando1 y operando2
				 * La operación es "+", "-", "*" ó "/" y se encuentra en operacion;
				 * realiza la operación correspondiente según el caso.
				 * Asigna el resultado al TextView resultado.
				 */

			}
        });
    }
}