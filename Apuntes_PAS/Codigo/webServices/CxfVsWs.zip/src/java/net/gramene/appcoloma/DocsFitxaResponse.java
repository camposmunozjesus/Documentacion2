
package net.gramene.appcoloma;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="docsFitxaResult" type="{http://www.gramene.net/appcoloma/}BeanRespostaTipus8" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "docsFitxaResult"
})
@XmlRootElement(name = "docsFitxaResponse")
public class DocsFitxaResponse {

    protected BeanRespostaTipus8 docsFitxaResult;

    /**
     * Gets the value of the docsFitxaResult property.
     * 
     * @return
     *     possible object is
     *     {@link BeanRespostaTipus8 }
     *     
     */
    public BeanRespostaTipus8 getDocsFitxaResult() {
        return docsFitxaResult;
    }

    /**
     * Sets the value of the docsFitxaResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link BeanRespostaTipus8 }
     *     
     */
    public void setDocsFitxaResult(BeanRespostaTipus8 value) {
        this.docsFitxaResult = value;
    }

}
