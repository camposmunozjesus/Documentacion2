/*
 * Created on 24/04/2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.jtech.ajdm.tapper.engine;

import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.TiledLayer;

import es.ua.jtech.ajdm.tapper.data.CommonData;
import es.ua.jtech.ajdm.tapper.data.Resources;
import es.ua.jtech.ajdm.tapper.data.StageData;

/**
 * @author Miguel Angel and Boyan
 *
 * Background with the bars for Tapper.
 */
public class Background extends TiledLayer {
	
	public Image imagen;
	
	public Background() {
		super(CommonData.BG_H_TILES, CommonData.BG_V_TILES, Resources.getImage(Resources.IMG_BG_STAGE_1), CommonData.BG_TILE_WIDTH, CommonData.BG_TILE_HEIGHT);
		this.setPosition(0, CommonData.BG_MARGINTOP);
	}

	/*
	 * Importante: Background.reset debe ser ejecutada antes de iniciar los sprites,
	 * pues deja en CommonData la información de las barras, que es necesaria para los sprites.
	 * Las posiciones Y de los sprites dependerán del número de barra en la que se encuentren.
	 * Por tanto, al resetear cada stage, lo primero será hacer reset del Background.
	 */
	public void reset(StageData stage) {
		//Comprobar cuántas "barras de bar" puede haber como máximo en esta resolución
		int maxbarras = stage.numBarras;
		if( CommonData.BG_V_TILES < maxbarras)
			maxbarras = CommonData.BG_V_TILES;
		int maxbarraspantalla = (CommonData.BG_H_TILES - 3) / 2;
		if( maxbarras > maxbarraspantalla)
			maxbarras = maxbarraspantalla;
		int primeraTile=(CommonData.BG_V_TILES-maxbarras);

		//Almacenar las coordenadas de inicio y de fin de las barras en las variables comunes
		CommonData.NUM_BARRAS = maxbarras;
		CommonData.BARRAS_Y = new int[maxbarras];
		CommonData.BARRAS_XIni = new int[maxbarras];
		CommonData.BARRAS_XFin = new int[maxbarras];
		for(int b=0;b<maxbarras;b++){
			CommonData.BARRAS_Y[b] = (b+1+primeraTile)*CommonData.BG_TILE_HEIGHT-CommonData.SPRITE_HEIGHT+5;
			CommonData.BARRAS_XIni[b] = (maxbarras-b-1)*CommonData.BG_TILE_WIDTH;
			CommonData.BARRAS_XFin[b] = CommonData.SCREEN_WIDTH-(maxbarras-b+2)*CommonData.BG_TILE_WIDTH;
		}

		//Construir la matriz de tiles del fondo
		for(int b=0;b<primeraTile-1;b++){
			for(int w=0;w<CommonData.BG_H_TILES; w++){
				this.setCell(w, b, CommonData.BG_TILE_VACIO);
			}
		}
		for(int b=primeraTile+maxbarras;b<CommonData.BG_V_TILES;b++){
			for(int w=0;w<CommonData.BG_H_TILES; w++){
				this.setCell(w, b, CommonData.BG_TILE_VACIO);
			}
		}

		int offset = maxbarras;
		if(primeraTile-1>=0){
		for(int w=offset;w<CommonData.BG_H_TILES-1-offset; w++){
			this.setCell(w, primeraTile-1, CommonData.BG_TILE_BORDE);
		}}
		offset--;
		for(int b=0; b<maxbarras; b++){
			int htile;
				htile = offset;
			this.setCell(htile++, primeraTile+b, CommonData.BG_TILE_PUERTA);
			for(int w=0;w<CommonData.BG_H_TILES-4-offset-offset; w++){
				this.setCell(htile++, primeraTile+b, CommonData.BG_TILE_BARRA);
			}
			this.setCell(htile++, primeraTile+b, CommonData.BG_TILE_FINBARRA);
			this.setCell(htile++, primeraTile+b, CommonData.BG_TILE_GRIFO);
			this.setCell(htile++, primeraTile+b, CommonData.BG_TILE_GRIFOPARED);
			offset --;
		}

		//Imagen de fondo
		imagen = Resources.getFondo(stage.numStage);
	}
}
