package rrhh

import org.weceem.content.WcmContent

/**
 * 
 * @author Jesus Campos
 * Ahora las im�genes se cargan del servidor y es capaz de cargar correctamente la p�gina Informacio_General.
 * Migas de pan: como mucho se hace una consulta a base de datos para obtenerlas, situaci�n que se da cuando entramos en una
 * ficha.
 * Cuando una URL no existe redirige a la p�gina de inicio /IniciPDIPAS/index.
 */
class Test09Controller {

	def static allowedTypes = ['org.weceem.html.WcmHTMLContent', 'com.upc.WcmPlantillaFitxa', 'com.upc.WcmPlantillaFitxa2ColGenerica', 'com.upc.WcmPlantillaFitxaGenerica']
	
	def index() {

		def values = request.forwardURI.toString().split("/")
		//Pagina
		def page = values[values.size()-1]
			   
		def query = {
			and{
				eq("space", 2711)
				eq("aliasuri", page)
				'in'("type", allowedTypes)	
			}
		}
		
		//Carga de la p�gina Inici
		def pageContent = WcmContent.createCriteria().list(query)
		
//		println pageContent.identity
		if(!pageContent){
			query = {
				and{
					eq("space", 2711)
					eq("aliasuri", "index")
					'in'("type", allowedTypes)	
				}
			}
			
			//Carga de la p�gina Inici
			pageContent = WcmContent.createCriteria().list(query)
			
			values = "/IniciPDIPAS/PAS/index/".split("/")
		}
		
		pageContent = pageContent[0]
//		println "TMPL: "+pageContent.tmpl	+" "+ pageContent.identity+" "+pageContent.type
		
		def template
		def webPage
		if(pageContent.tmpl)
		{
			template= pageContent.tmpl
			//Carga del template
			def pageTemplate = WcmContent.findByIdentityAndSpace(template, 2711)
			
			webPage = pageTemplate.content.replace("<wcm:content />", pageContent.content)
//			println "CON TMPL"
		}
		else{
			webPage = pageContent.content
//			println "SIN TMPL"
		}
		//Para Grails 2.4.3
		webPage = webPage.replace("/Portal/PAS/index", "/IniciPDIPAS/PAS/index")
	    webPage = webPage.replace("/Portal/PAS/css", "/IniciPDIPAS/css")
		webPage = webPage.replace("/Portal/PAS/js", "/IniciPDIPAS/js")

		if(!(pageContent.type == "com.upc.WcmPlantillaFitxa" || pageContent.type == "com.upc.WcmPlantillaFitxaGenerica")){
			webPage = webPage.replace("<a href=\"/Portal", "<a href=\"/IniciPDIPAS")
		}
		
		//Las tres l�neas anteriores se solucionan con regexp si en el template se tiene ${wcm.Link ...
		webPage = webPage.replace("\${wcm.loggedInUserName().encodeAsHTML()}", "")
   
		webPage = webPage.replace("\${node.title.encodeAsHTML()}", pageContent.title)
   
		 //Redirecci�n de la p�gina
		 //${grails.util.Metadata.current.'app.name'}/${space?.name}/index/Informacio_General
		 webPage = webPage.replace("\${grails.util.Metadata.current.'app.name'}", "IniciPDIPAS")
		 webPage = webPage.replace("\${space?.name}", "PAS")
		   
		   
		 //<!--breadCrumb--><br>  barra de migas de pan.
//		 def mdp = "<div class=\"breadCrumb\"> <b>Sou a <span class=\"breadCrumbSeparator firstSeparator\">&raquo;</span></b>"
		 def mdp = "<b>Sou a <span class=\"breadCrumbSeparator firstSeparator\">&raquo;</span></b>"
		 
		 
		 //Los elemetos 0 y 1 no se tienen en cuenta para las migas de pan.
		 //Construir las migas de pan (listas de ALIASURI y TITLE)
		 def mdpAliasuri = values[3..(values.size()-1)]
		 def mdpTitle = values[3..(values.size()-1)]

		 //Construir las migas de pan (TITLE)
		 mdpTitle[0]="Inici"
		 mdpTitle[1]="Informaci\u00f3 General"
		 if(mdpTitle.size()>3){
			 //Se consulta el nombre en la BD del apartado del men� izquierdo
			 def fitxa = WcmContent.findByAliasuriAndSpace(mdpAliasuri[2], 2711)
			 mdpTitle[2] = fitxa.title
			 
		 }
		 mdpTitle[mdpTitle.size()-1]=pageContent.title
		 
		 def mdpAddr = "/IniciPDIPAS/PAS"

		 //Generaci�n del mapa key(aliasuri):value(title)
		 def mdpKeys = mdpAliasuri
		 def mdpValues = mdpTitle
		 def pairs = [mdpKeys, mdpValues].transpose()
		 
		 def breadMap = [:]
		 pairs.each{ k, v -> breadMap[k] = v }
		 
		 breadMap.each{
 			 mdpAddr += "/"+it.key
 			 if (!(it.key==values.last())){
 				 mdp += "<a href=\"$mdpAddr\"><span class=\"breadCrumbItem\">"+it.value+"</span></a><span class=\"breadCrumbSeparator\">&rsaquo;</span>"
 			 }
 			 else{
 				 mdp += "<span class=\"breadCrumbLastItem\">"+it.value+"</span>"
 			 }
		 }
//		 mdp += "</div>"

		 webPage = webPage.replace("<!--breadCrumb-->", mdp)
		   
		//Buscador
		if(webPage.contains("<upc:search max=\"15\" eraseplaceholder=\"no\" placeholder=\"Cercar...\" types=\"com.upc.WcmPlantillaFitxa\"></upc:search>")){
			webPage = webPage.replace("<upc:search max=\"15\" eraseplaceholder=\"no\" placeholder=\"Cercar...\" types=\"com.upc.WcmPlantillaFitxa\"></upc:search>", "<form action=\"https://melnik.upc.edu/Portal/cms/tools/search?uri=PAS%2F&amp;max=15&amp;erasePlaceHolder=no&amp;placeHolder=Cercar...&amp;types=com.upc.WcmPlantillaFitxa\" method=\"post\"><input name=\"query\" class=\"customSearchField\" placeholder=\"Cercar...\" onfocus=\"\" value=\"\" id=\"query\" type=\"text\"><input name=\"submit\" class=\"customSearchButton\" value=\"Cerca\" id=\"submit\" type=\"submit\"></form>")
		}
		  
		render(text: webPage, contentType: "text/html", encoding: "UTF-8")
	}
}
