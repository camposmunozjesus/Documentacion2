package es.ua.jtech.graficos;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import android.opengl.GLSurfaceView;
import android.opengl.GLU;

public class RendererGraficos implements GLSurfaceView.Renderer {

	Triangulo3D triangulo;
	float angulo;
	
	public RendererGraficos() {
    	triangulo = new Triangulo3D();
    	angulo = 0;
	}
	
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {

    }

    public void onSurfaceChanged(GL10 gl, int w, int h) {
        // Al cambiar el tama�o cambia la proyecci�n
        float aspecto = (float)w/h;
    	gl.glViewport(0, 0, w, h);
        
        gl.glMatrixMode(GL10.GL_PROJECTION);
        gl.glLoadIdentity();
	    GLU.gluPerspective(gl, 45.0f, aspecto, 1.0f, 30.0f);
    }

    public void onDrawFrame(GL10 gl) {
        gl.glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
        gl.glClear(GL10.GL_COLOR_BUFFER_BIT | GL10.GL_DEPTH_BUFFER_BIT);
        
        // Dibujar gr�ficos aqu�       
        gl.glMatrixMode(GL10.GL_MODELVIEW);
        gl.glLoadIdentity();
        gl.glTranslatef(0, 0, -5.0f);
        gl.glRotatef(angulo, 0, 1, 0);

        gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);

        triangulo.dibujar(gl);
        
        angulo += 1.0f;
    }
}
