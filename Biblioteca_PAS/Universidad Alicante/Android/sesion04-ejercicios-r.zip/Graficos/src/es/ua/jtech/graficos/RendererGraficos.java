package es.ua.jtech.graficos;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import es.ua.jtech.graficos.mesh.Triangulo3D;

import android.opengl.GLSurfaceView;
import android.opengl.GLU;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

public class RendererGraficos implements GLSurfaceView.Renderer, OnTouchListener, GestureDetector.OnGestureListener {

	private final static float DECELERACION = 10.0f;
	private final static float FACTOR = 0.01f;	
	
	Triangulo3D triangulo;
	float anguloX, anguloY;
	float vel;
	float velCos, velSin;
	
	GestureDetector detectorGestos;
	
	public RendererGraficos() {
    	triangulo = new Triangulo3D();
    	anguloX = 0;
    	anguloY = 0;
    	
    	detectorGestos = new GestureDetector(this);
	}
	
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {

    }

    public void onSurfaceChanged(GL10 gl, int w, int h) {
        // Al cambiar el tama�o cambia la proyecci�n
        float aspecto = (float)w/h;
    	gl.glViewport(0, 0, w, h);
        
        gl.glMatrixMode(GL10.GL_PROJECTION);
        gl.glLoadIdentity();
	    GLU.gluPerspective(gl, 45.0f, aspecto, 1.0f, 30.0f);
    }

    public void onDrawFrame(GL10 gl) {
        gl.glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
        gl.glClear(GL10.GL_COLOR_BUFFER_BIT | GL10.GL_DEPTH_BUFFER_BIT);
        
        // Dibujar gr�ficos aqu�       
        gl.glMatrixMode(GL10.GL_MODELVIEW);
        gl.glLoadIdentity();
        gl.glTranslatef(0, 0, -5.0f);
        gl.glRotatef(anguloX, 0, 1, 0);
        gl.glRotatef(anguloY, 1, 0, 0);

        gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);

        triangulo.dibujar(gl);
        
        if(vel > 0) {
        	anguloX += FACTOR * vel * velCos;
        	anguloY += FACTOR * vel * velSin;
        	
        	vel -= DECELERACION;
        }
    }

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		// Pasamos la informaci�n al detector de gestos
		return detectorGestos.onTouchEvent(event);
	}

	@Override
	public boolean onDown(MotionEvent e) {
		// Devolvemos true para seguir procesando el gesto
		return true;
	}

	@Override
	public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
			float velocityY) {
		// Damos una velocidad de rotaci�n al objeto
		vel = (float)Math.sqrt(velocityX*velocityX + velocityY*velocityY);
		velCos = velocityX / vel;
		velSin = velocityY / vel;
		return true;
	}

	@Override
	public void onLongPress(MotionEvent e) {
	}

	@Override
	public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX,
			float distanceY) {
		// Rotamos manualmente el objeto
		anguloX -= distanceX;
		anguloY -= distanceY;
		return true;
	}

	@Override
	public void onShowPress(MotionEvent e) {
	}

	@Override
	public boolean onSingleTapUp(MotionEvent e) {
		// Paramos el objeto y lo devolvemos a su posicion original
		vel = 0;
		anguloX = 0.0f;
		anguloY = 0.0f;
		return true;
	}
}
