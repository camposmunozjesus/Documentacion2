package es.ua.jtech.flujos;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.*;

public class Ej2 {

	// ----------------------------------------------------------------------------
	//  Crea un objeto URL a partir de la cadena de la url
	// ----------------------------------------------------------------------------

	public static URL creaURL(String url_str) {
		URL url = null;

		try {
			url = new URL(url_str);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}

		return url;
	}

	// ----------------------------------------------------------------------------
	//  Lee una URL y nos devuelve su contenido en forma de cadena
	// ----------------------------------------------------------------------------

	public static String leeURL(URL url) {
		String s = "";
		String linea;

		try {
			InputStream in = url.openStream();

			BufferedReader r = new BufferedReader(new InputStreamReader(in));

			// Lee de la URL linea a linea

			while( (linea=r.readLine()) != null )
			{
				s += linea + "\n";
			}
		} catch(IOException e) {
			System.err.println("Error leyendo URL");
			System.exit(1);
		}

		return s;
	}

	public static void main(String [] args) {
		if(args.length != 1) {
			System.err.println("Uso: java Ej3 <url>");
			System.exit(1);
		}

		URL url = creaURL(args[0]);

		String texto = leeURL(url);

		System.out.println(texto);

		System.exit(0);
	}
}