package es.ua.jtech.ajdm.temporizador;

import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

public class MIDletTemporizador extends MIDlet {

	protected void startApp() throws MIDletStateChangeException {		
		Timer temp = new Timer();
		TimerTask tarea = new MiTarea();
		
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.MINUTE, 55);
		Date fecha = cal.getTime();
		
		temp.schedule(tarea, fecha);

		System.out.println("Temporizador programado");
	}

	protected void pauseApp() {

	}

	protected void destroyApp(boolean cond) throws MIDletStateChangeException {

	}

	class MiTarea extends TimerTask {
		public void run() {
			System.out.println("Se ha disparado la alarma");
		}
	}
	
}
