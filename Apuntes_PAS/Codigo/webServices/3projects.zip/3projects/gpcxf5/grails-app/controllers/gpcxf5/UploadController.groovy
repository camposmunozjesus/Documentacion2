package gpcxf5

import org.springframework.web.multipart.MultipartFile

class UploadController {
    def md5Service

    def index() { }

    def upload(){
        MultipartFile multipartFile = request.getFile('thefile')
        InputStream inputStream = multipartFile.getInputStream()
        try {
            def md5 = md5Service.calc(inputStream)
            flash.message = "MD5=" + md5
            redirect(action: 'index')
        } finally {
            inputStream.close()
        }
    }
}
