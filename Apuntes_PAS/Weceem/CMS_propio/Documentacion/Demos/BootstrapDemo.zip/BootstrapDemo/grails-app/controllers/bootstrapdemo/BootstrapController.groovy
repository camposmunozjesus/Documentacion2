package bootstrapdemo

/**
 * Aplicaci&oacute; de mostra del correcte funcionament del framework Bootstrap a una aplicaci&oacute; Grails.<br>
 * @author Jesus Campos
 * @version 09-04-2015
 *
 */
class BootstrapController {
	/**
	 *  * El controlador nom&eacute;s redirecciona a la vista.
	 * @return
	 */
    def index() { }
}
