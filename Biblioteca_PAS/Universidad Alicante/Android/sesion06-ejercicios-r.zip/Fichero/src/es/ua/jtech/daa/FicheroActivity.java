package es.ua.jtech.daa;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class FicheroActivity extends Activity {
	Button boton;
	TextView texto;
	EditText entrada;
	final String NOMBRE_FICHERO = "fichero.txt";
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        texto = (TextView)findViewById(R.id.texto);
        texto.setClickable(true);
        entrada = (EditText)findViewById(R.id.entrada);
        boton = (Button)findViewById(R.id.boton);
        boton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				try {
					FileOutputStream fos = openFileOutput(NOMBRE_FICHERO, Context.MODE_APPEND);
					fos.write(entrada.getText().toString().getBytes());
					fos.write('\n');
					fos.close();
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
        });
        
        texto.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				try {
					FileInputStream fis = openFileInput(NOMBRE_FICHERO);
					texto.setText("");
					byte read[] = new byte[5000];
					int ret = fis.read(read);
					while (ret != -1) {
						texto.append(new String(read));
						ret = fis.read(read);
					}
					fis.close();
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
        });
    }
}