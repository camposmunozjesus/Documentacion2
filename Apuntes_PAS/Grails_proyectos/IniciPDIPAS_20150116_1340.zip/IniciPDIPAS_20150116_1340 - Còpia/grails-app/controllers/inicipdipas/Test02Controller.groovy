package inicipdipas

/**
 * 
 * @author Jesus Campos
 * Pruebas:  se puede visualizar en la p�gina GSP, al entrar en el controlador qu� direcci�n utiliza para cargar los css y js.
 */
class Test02Controller {

    def index_() { 
		redirect (action: 'index') 
	}

	def index(){
		println "index 2"+new Date()
		params.desplegableSelected = "El-PAS-a-la-UPC"
	}
}
