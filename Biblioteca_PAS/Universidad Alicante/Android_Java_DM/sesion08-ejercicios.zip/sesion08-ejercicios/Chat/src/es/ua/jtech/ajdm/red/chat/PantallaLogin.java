package es.ua.jtech.ajdm.red.chat;

import java.io.*;
import javax.microedition.io.*;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class PantallaLogin extends TextBox implements CommandListener, Runnable {

	private final static String URL_LOGIN = "http://www.jtech.ua.es/ejemplos-j2me/servlet/ServletChat";

	MIDlet owner;

	Command cmdOK;

	public PantallaLogin(MIDlet owner) {
		super("Login", "", 8, TextField.ANY);

		this.owner = owner;

		// Crea comandos
		cmdOK = new Command("OK", Command.OK, 1);
		this.addCommand(cmdOK);
		this.setCommandListener(this);
	}

	public void commandAction(Command cmd, Displayable disp) {
		if(cmd == cmdOK) {
			Thread t = new Thread(this);
			t.start();			
		}
	}

	public void run() {
		try {
			// Introduce el login
			String url = login(this.getString()); 

			if(url != null) {
				Display d = Display.getDisplay(owner);
				ListaMensajes lm = new ListaMensajes(owner, this, url);
				d.setCurrent(lm);
			}
		} catch(IOException e) {
			Alert a = new Alert("Error", "Error en la conexion", null, AlertType.ERROR);
			Display d = Display.getDisplay(owner);
			d.setCurrent(a, d.getCurrent());
		}
	}

	private String login(String nick) throws IOException {

		//TODO abrir conexión http pasando el login en la url con ?accion=login&id=<nick_del_usuario>	
		//La petición será de tipo GET y se esperará el código de respuesta HTTP_OK (200).
		//Debemos leer la cabecera "URL-Reescrita" y devolver el valor

		return null;
	}
}