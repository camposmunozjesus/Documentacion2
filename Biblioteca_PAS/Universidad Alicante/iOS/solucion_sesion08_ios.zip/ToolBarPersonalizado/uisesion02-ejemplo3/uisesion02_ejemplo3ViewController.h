//
//  uisesion02_ejemplo3ViewController.h
//  uisesion02-ejemplo3
//
//  Created by Javier Aznar de los Rios on 24/09/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MiToolBar.h"

@interface uisesion02_ejemplo3ViewController : UIViewController {
    UIToolbar *_toolBar;
    UITextField *_textField;
    UISegmentedControl *_segmentedControl;
    UILabel *_segmentLabel;
}

@property (nonatomic, retain) IBOutlet UIToolbar *toolBar;
@property (nonatomic, retain) IBOutlet UITextField *textField;
@property (nonatomic, retain) IBOutlet UISegmentedControl *segmentedControl;
@property (nonatomic, retain) IBOutlet UILabel *segmentLabel;

-(IBAction) segmentedControlIndexChanged;

@end
