/*
 * Created on 12-sep-2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package es.ua.jtech.tienda;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ListaProductos extends HttpServlet {

	ArrayList productos;
	
	public void init() throws ServletException {
		productos = new ArrayList();
		
		productos.add(new Producto("Mulholland Drive", "DVD", "David Lynch", 2395, true));
		productos.add(new Producto("El hombre elefante", "DVD", "David Lynch", 1695, true));
	}

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		res.setContentType("application/octet-stream");
		OutputStream out = res.getOutputStream();
		
		for(int i=0;i<productos.size();i++) {
			Producto prod = (Producto)productos.get(i);
			prod.serialize(out);
		}
		
		out.close();
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		doGet(req,res);
	}

}
