package es.ua.jtech.ajdm.ts;

import javax.microedition.lcdui.*;

public class AreaDibujo extends Canvas {

	Image offScreen; 

	int cursor_x;
	int cursor_y;

	public AreaDibujo() {

		// TODO: Crear imagen mutable offscreen donde dibujaremos

		cursor_x = this.getWidth()/2;
		cursor_y = this.getHeight()/2;
		
		actualiza();
		
	}


	// TODO: Dar respuesta a los eventos de entrada del teclado

	private void mueveCursor(int x, int y) {
		cursor_x += x;
		cursor_y += y;
		
		actualiza();
	}

	private void actualiza() {

		// TODO: Dibujar un punto en la posicion del cursor en el offscreen

		// TODO: Repintar la pantalla

	}

	protected void paint(Graphics g) {

		// TODO: Volcar el contenido del offscreen a la pantalla

	}
}
