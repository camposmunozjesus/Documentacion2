package es.ua.jtech.ajdm.s15;

import java.net.URL;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import android.app.Activity;
import android.os.Bundle;
import android.text.util.Linkify;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Main extends Activity {
    /** Called when the activity is first created. */
	TextView textView;
	EditText editText;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        textView = (TextView)findViewById(R.id.TextView01);
        editText = (EditText)findViewById(R.id.EditText01);
        editText.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(View v, int keyCode, KeyEvent event) {
		        if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)) {
		            // Perform action on key press
		        	accionDescargar();
		        	return true;
		          }
		          return false;
			}
		});
        ((Button)findViewById(R.id.Button01)).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				accionDescargar();
			}
		});

        
		
   }
   void accionDescargar(){
	   		textView.setText("");

			//TODO nueva URL con el contenido del editText
			
			//TODO usar XmlPullParser para encontrar iterativamente:
			// <item> 
			//   y dentro de cada item recoger la información de 
			//   <title>
			//   <link>
			// y colocarlos en el campo de texto textView
			
			

			//Marca los links del campo de texto para que sean clickables
			Linkify.addLinks(textView, Linkify.WEB_URLS);
   }
}