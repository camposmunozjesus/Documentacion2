//
//  UAMasterViewController.m
//  Filmoteca
//
//  Created by Miguel Angel Lozano on 15/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "UAMasterViewController.h"

#import "UADetailViewController.h"
#import "UAPelicula.h"

@implementation UAMasterViewController

@synthesize detailViewController = _detailViewController;
@synthesize peliculas = _peliculas;

@synthesize swipeToDeleteEditing = _swipeToDeleteEditing;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"Tareas";
        self.tabBarItem.image = [UIImage imageNamed:@"video"];
        
        self.swipeToDeleteEditing = NO;
        
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        
        if ([paths count] > 0) {
            NSString *documentsDirectory = [paths objectAtIndex:0];
            NSString *documentsFilename = [documentsDirectory stringByAppendingPathComponent:@"peliculas.plist"];

            BOOL fileExists = [[NSFileManager defaultManager] fileExistsAtPath:documentsFilename];        
            if (fileExists) 
            {
                self.peliculas = [NSKeyedUnarchiver unarchiveObjectWithFile:documentsFilename];             
            }
        }
                
        if(!self.peliculas) {
            // Inicializa lista de peliculas por primera vez
            UAPelicula *pelicula1 = [[UAPelicula alloc] initWithTitulo:@"El Resplandor"];
            pelicula1.cartel = [UIImage imageNamed:@"resplandor.jpg"];
            UAPelicula *pelicula2 = [[UAPelicula alloc] initWithTitulo:@"Malditos Bastardos"];
            pelicula2.cartel = [UIImage imageNamed:@"bastardos.jpg"];
            pelicula2.calificacion = NR18;
            UAPelicula *pelicula3 = [[UAPelicula alloc] initWithTitulo:@"Robocop"];
            pelicula3.cartel = [UIImage imageNamed:@"robocop.jpg"];
            pelicula3.calificacion = NR13;
            
            self.peliculas = [NSMutableArray arrayWithObjects:pelicula1, pelicula2, pelicula3, nil];            
        }
    }
    return self;
}

- (void) saveData {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    if ([paths count] > 0) {
        NSString *documentsDirectory = [paths objectAtIndex:0];
        NSString *documentsFilename = [documentsDirectory stringByAppendingPathComponent:@"peliculas.plist"];
        
        [NSKeyedArchiver archiveRootObject: self.peliculas toFile: documentsFilename];
    }
}

- (void)awakeFromNib {
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];    
    // Do any additional setup after loading the view, typically from a nib.
    self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.tableView reloadData];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (void)setEditing:(BOOL)editing animated:(BOOL)animated {
    [super setEditing:editing animated:animated];

    if(!self.swipeToDeleteEditing) {
        NSArray *rows = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:[self.peliculas count] inSection:0]];
        if(editing) {
            [self.tableView insertRowsAtIndexPaths:rows withRowAnimation:UITableViewRowAnimationTop];
        } else {
            [self.tableView deleteRowsAtIndexPaths:rows withRowAnimation:UITableViewRowAnimationTop];
        }        
    }
}

// Customize the number of sections in the table view.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(self.editing) {
        return [self.peliculas count] + 1;
    } else {
        return [self.peliculas count];        
    }
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;

        UISwitch *interruptor = [[UISwitch alloc] init];
        cell.accessoryView = interruptor;
        
        [interruptor addTarget: self action:@selector(cambioInterruptor:) forControlEvents:UIControlEventValueChanged];
    }

    if(indexPath.row >= [self.peliculas count]) {
        // Insert cell
        cell.textLabel.text = @"Añadir película";
        cell.imageView.image = nil;
    } else {
        // Configure the cell.
        UAPelicula *pelicula = [self.peliculas objectAtIndex: indexPath.row];
        cell.textLabel.text = pelicula.titulo; //[NSString stringWithFormat: NSLocalizedString(@"Item", @"Posicion %d"), [indexPath row]];     
        cell.imageView.image = pelicula.cartel;        
    }
    

    return cell;
}

- (IBAction)cambioInterruptor:(id)sender {
    UISwitch *interruptor = sender;
    UITableViewCell *celda = (UITableViewCell*)interruptor.superview;
    
    if(interruptor.on) {
        celda.textLabel.textColor = [UIColor redColor];
        celda.backgroundColor = [UIColor lightGrayColor];
    } else {
        celda.textLabel.textColor = [UIColor blackColor];
        celda.backgroundColor = [UIColor whiteColor];
    }
    //[self.tableView reloadData];
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.    
    return indexPath.row < [self.peliculas count];
}
*/
- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    if(indexPath.row < [self.peliculas count]) {
        return UITableViewCellEditingStyleDelete;
    } else {
        return UITableViewCellEditingStyleInsert;
    }
}

// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source.
        [self.peliculas removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
        UAPelicula *pelicula = [UAPelicula pelicula];
        [self.peliculas addObject:pelicula];
        [tableView insertRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationTop];
    }   
}

-(void)tableView:(UITableView *)tableView willBeginEditingRowAtIndexPath:(NSIndexPath *)indexPath {
    self.swipeToDeleteEditing = YES;
}

-(void)tableView:(UITableView *)tableView didEndEditingRowAtIndexPath:(NSIndexPath *)indexPath {
    self.swipeToDeleteEditing = NO;
}

// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
    UAPelicula *pelicula = [self.peliculas objectAtIndex:fromIndexPath.row];
    [self.peliculas removeObjectAtIndex:fromIndexPath.row];
    [self.peliculas insertObject:pelicula atIndex:toIndexPath.row];        
}

- (NSIndexPath *)tableView:(UITableView *)tableView targetIndexPathForMoveFromRowAtIndexPath:(NSIndexPath *)sourceIndexPath toProposedIndexPath:(NSIndexPath *)proposedDestinationIndexPath {
    if(proposedDestinationIndexPath.row >= [self.peliculas count]) {
        return [NSIndexPath indexPathForRow:([self.peliculas count]-1) inSection:0];
    } else {
        return proposedDestinationIndexPath;
    }
}

// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return indexPath.row < [self.peliculas count];
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (!self.detailViewController) {
        self.detailViewController = [[UADetailViewController alloc] initWithNibName:@"UADetailViewController" bundle:nil];
    }
    self.detailViewController.pelicula = [self.peliculas objectAtIndex: indexPath.row];
    [self.navigationController pushViewController:self.detailViewController animated:YES];
}

@end
