package cxfvsws

import net.gramene.appcoloma.BeanRespostaTipus1
import net.gramene.appcoloma.CodiEstat
import net.gramene.appcoloma.Service1Soap

import org.tempuri.WSMeteorologicoSoap


class PruebaController {

	Service1Soap colomaClient 	//este nombre debe coincidir con el del apartado/nodo cxf - client
								//del archivo Config.groovy. NO puede ser un nombre de variable cualquiera.
	WSMeteorologicoSoap tiempoClient
	
    def index() {
		
	}
	
	def colomaCxfGetIdiomes (){
		CodiEstat ce
		
		try{
			BeanRespostaTipus1 b1 = (BeanRespostaTipus1) colomaClient.idiomesFitxa()
			ce = b1.getCodiEstat()
			println ce.getIntCodiEstat()
			println ce.getIntTotalResultats()
			println ce.getStrDescripcioEstat()
			
			
			println "[try ws]"
		
		}catch(Exception e){
			String service = e.message
			println "[>>> ws]"
			println service
			println "[<<< ws]"
		}
		
		[ce:ce]
	}
	
	def meteoCxfFecha (){
		String fecha
		try{
			fecha = tiempoClient.fecha()
			println fecha
		}
		catch(Exception e){
			String service = e.message
			println "[>>> ws]"
			println service
			println "[<<< ws]"
		}
		
		[fecha:fecha]
	}
	
}



