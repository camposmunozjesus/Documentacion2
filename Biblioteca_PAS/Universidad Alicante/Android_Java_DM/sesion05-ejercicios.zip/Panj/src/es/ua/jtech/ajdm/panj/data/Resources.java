/*
 * Resources.java
 * Copyright (C) 2004 Miguel Angel Lozano
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package es.ua.jtech.ajdm.panj.data;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.microedition.lcdui.Image;

import es.ua.jtech.ajdm.panj.MIDletPanj;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class Resources {

	// Identificadores de las imagenes
	public static final int IMG_TIT_TITULO = 0;
	public static final int IMG_TIT_FONDO = 1;
	public static final int IMG_SPR_RAYO = 2;
	public static final int IMG_SPR_PERS = 3;
	public static final int IMG_SPR_BALL_1 = 4;
	public static final int IMG_SPR_BALL_2 = 5;
	public static final int IMG_SPR_BALL_3 = 6;
	public static final int IMG_SPR_BALL_4 = 7;
	public static final int IMG_CARA = 8;

	// Imagenes y otros datos del juego
	public static Image[] img;
	public static Image blankImage;
	public static Image splashImage;
	public static StageData[] stageData;

	public static MIDletPanj midlet;

	// Nombres de los ficheros de las imagenes
	private static String[] imgNames =
		{
			"/titulo.png",
			"/fondo.png",
			"/rayo.png",
			"/pers.png",
			"/ball1.png",
			"/ball2.png",
			"/ball3.png",
			"/ball4.png",
			"/cara.png" };

	private static String splashImageFile = "/logojava.png";

	private static String stageFile = "/stages.dat";

	public static void init() throws IOException {

		loadCommonImages();

		InputStream in = stageFile.getClass().getResourceAsStream(stageFile);
		stageData = loadStageData(in);
	}

	public static void initSplash(MIDletPanj pMidlet) throws IOException {
		midlet = pMidlet;
		splashImage = Image.createImage(splashImageFile);
	}

	private static void loadCommonImages() throws IOException {
		// Carga imagenes
		int nImg = imgNames.length;

		img = new Image[nImg];

		for (int i = 0; i < nImg; i++) {
			img[i] = Image.createImage(imgNames[i]);
		}
		
		blankImage = Image.createImage(1,1);
	}

	public static StageData[] loadStageData(InputStream in)
		throws IOException {

		StageData[] stages = null;

		DataInputStream dis = new DataInputStream(in);

		int stageNum = dis.readInt();
		stages = new StageData[stageNum];

		for (int i = 0; i < stageNum; i++) {
			stages[i] = StageData.deserialize(dis);
			stages[i].loadResources();
		}

		return stages;
	}

}
