
package net.gramene.appcoloma;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the net.gramene.appcoloma package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: net.gramene.appcoloma
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link FitxesCategoriaAgenda }
     * 
     */
    public FitxesCategoriaAgenda createFitxesCategoriaAgenda() {
        return new FitxesCategoriaAgenda();
    }

    /**
     * Create an instance of {@link AgendaDatesResponse }
     * 
     */
    public AgendaDatesResponse createAgendaDatesResponse() {
        return new AgendaDatesResponse();
    }

    /**
     * Create an instance of {@link BeanRespostaTipus7 }
     * 
     */
    public BeanRespostaTipus7 createBeanRespostaTipus7() {
        return new BeanRespostaTipus7();
    }

    /**
     * Create an instance of {@link FitxesTipusAgenda }
     * 
     */
    public FitxesTipusAgenda createFitxesTipusAgenda() {
        return new FitxesTipusAgenda();
    }

    /**
     * Create an instance of {@link AgendaPaginadaDataResponse }
     * 
     */
    public AgendaPaginadaDataResponse createAgendaPaginadaDataResponse() {
        return new AgendaPaginadaDataResponse();
    }

    /**
     * Create an instance of {@link FitxesCategoriaAgendaDates }
     * 
     */
    public FitxesCategoriaAgendaDates createFitxesCategoriaAgendaDates() {
        return new FitxesCategoriaAgendaDates();
    }

    /**
     * Create an instance of {@link TipusAgenda }
     * 
     */
    public TipusAgenda createTipusAgenda() {
        return new TipusAgenda();
    }

    /**
     * Create an instance of {@link EquipamentsDisponiblesPaginadaResponse }
     * 
     */
    public EquipamentsDisponiblesPaginadaResponse createEquipamentsDisponiblesPaginadaResponse() {
        return new EquipamentsDisponiblesPaginadaResponse();
    }

    /**
     * Create an instance of {@link BeanRespostaTipus5 }
     * 
     */
    public BeanRespostaTipus5 createBeanRespostaTipus5() {
        return new BeanRespostaTipus5();
    }

    /**
     * Create an instance of {@link FitxesTipusAgendaNombreResultatsDatesResponse }
     * 
     */
    public FitxesTipusAgendaNombreResultatsDatesResponse createFitxesTipusAgendaNombreResultatsDatesResponse() {
        return new FitxesTipusAgendaNombreResultatsDatesResponse();
    }

    /**
     * Create an instance of {@link CodiEstat }
     * 
     */
    public CodiEstat createCodiEstat() {
        return new CodiEstat();
    }

    /**
     * Create an instance of {@link FitxesTipusAgendaNombreResultatsDataResponse }
     * 
     */
    public FitxesTipusAgendaNombreResultatsDataResponse createFitxesTipusAgendaNombreResultatsDataResponse() {
        return new FitxesTipusAgendaNombreResultatsDataResponse();
    }

    /**
     * Create an instance of {@link FitxesCategoriaAgendaData }
     * 
     */
    public FitxesCategoriaAgendaData createFitxesCategoriaAgendaData() {
        return new FitxesCategoriaAgendaData();
    }

    /**
     * Create an instance of {@link FitxesEquipamentPerIdDates }
     * 
     */
    public FitxesEquipamentPerIdDates createFitxesEquipamentPerIdDates() {
        return new FitxesEquipamentPerIdDates();
    }

    /**
     * Create an instance of {@link FitxesCategoriaAgendaDataResponse }
     * 
     */
    public FitxesCategoriaAgendaDataResponse createFitxesCategoriaAgendaDataResponse() {
        return new FitxesCategoriaAgendaDataResponse();
    }

    /**
     * Create an instance of {@link BeanRespostaTipus2 }
     * 
     */
    public BeanRespostaTipus2 createBeanRespostaTipus2() {
        return new BeanRespostaTipus2();
    }

    /**
     * Create an instance of {@link FitxesTipusAgendaNombreResultats }
     * 
     */
    public FitxesTipusAgendaNombreResultats createFitxesTipusAgendaNombreResultats() {
        return new FitxesTipusAgendaNombreResultats();
    }

    /**
     * Create an instance of {@link DocsFitxaResponse }
     * 
     */
    public DocsFitxaResponse createDocsFitxaResponse() {
        return new DocsFitxaResponse();
    }

    /**
     * Create an instance of {@link BeanRespostaTipus8 }
     * 
     */
    public BeanRespostaTipus8 createBeanRespostaTipus8() {
        return new BeanRespostaTipus8();
    }

    /**
     * Create an instance of {@link IdiomesFitxa }
     * 
     */
    public IdiomesFitxa createIdiomesFitxa() {
        return new IdiomesFitxa();
    }

    /**
     * Create an instance of {@link AgendaNombreResultatsData }
     * 
     */
    public AgendaNombreResultatsData createAgendaNombreResultatsData() {
        return new AgendaNombreResultatsData();
    }

    /**
     * Create an instance of {@link EquipamentsDisponiblesPaginada }
     * 
     */
    public EquipamentsDisponiblesPaginada createEquipamentsDisponiblesPaginada() {
        return new EquipamentsDisponiblesPaginada();
    }

    /**
     * Create an instance of {@link FitxesTipusAgendaPaginada }
     * 
     */
    public FitxesTipusAgendaPaginada createFitxesTipusAgendaPaginada() {
        return new FitxesTipusAgendaPaginada();
    }

    /**
     * Create an instance of {@link CategoriesAgenda }
     * 
     */
    public CategoriesAgenda createCategoriesAgenda() {
        return new CategoriesAgenda();
    }

    /**
     * Create an instance of {@link HorarisFitxaResponse }
     * 
     */
    public HorarisFitxaResponse createHorarisFitxaResponse() {
        return new HorarisFitxaResponse();
    }

    /**
     * Create an instance of {@link BeanRespostaTipus4 }
     * 
     */
    public BeanRespostaTipus4 createBeanRespostaTipus4() {
        return new BeanRespostaTipus4();
    }

    /**
     * Create an instance of {@link ImgsFitxa }
     * 
     */
    public ImgsFitxa createImgsFitxa() {
        return new ImgsFitxa();
    }

    /**
     * Create an instance of {@link DocsFitxa }
     * 
     */
    public DocsFitxa createDocsFitxa() {
        return new DocsFitxa();
    }

    /**
     * Create an instance of {@link EquipamentsDisponibles }
     * 
     */
    public EquipamentsDisponibles createEquipamentsDisponibles() {
        return new EquipamentsDisponibles();
    }

    /**
     * Create an instance of {@link FitxesTipusAgendaPaginadaDatesResponse }
     * 
     */
    public FitxesTipusAgendaPaginadaDatesResponse createFitxesTipusAgendaPaginadaDatesResponse() {
        return new FitxesTipusAgendaPaginadaDatesResponse();
    }

    /**
     * Create an instance of {@link AgendaPaginadaDatesResponse }
     * 
     */
    public AgendaPaginadaDatesResponse createAgendaPaginadaDatesResponse() {
        return new AgendaPaginadaDatesResponse();
    }

    /**
     * Create an instance of {@link AgendaData }
     * 
     */
    public AgendaData createAgendaData() {
        return new AgendaData();
    }

    /**
     * Create an instance of {@link FitxesEquipamentPerIdResponse }
     * 
     */
    public FitxesEquipamentPerIdResponse createFitxesEquipamentPerIdResponse() {
        return new FitxesEquipamentPerIdResponse();
    }

    /**
     * Create an instance of {@link AgendaPaginada }
     * 
     */
    public AgendaPaginada createAgendaPaginada() {
        return new AgendaPaginada();
    }

    /**
     * Create an instance of {@link FitxesTipusAgendaData }
     * 
     */
    public FitxesTipusAgendaData createFitxesTipusAgendaData() {
        return new FitxesTipusAgendaData();
    }

    /**
     * Create an instance of {@link FitxesTipusAgendaDates }
     * 
     */
    public FitxesTipusAgendaDates createFitxesTipusAgendaDates() {
        return new FitxesTipusAgendaDates();
    }

    /**
     * Create an instance of {@link AgendaDates }
     * 
     */
    public AgendaDates createAgendaDates() {
        return new AgendaDates();
    }

    /**
     * Create an instance of {@link FitxesCategoriaAgendaNombreResultatsResponse }
     * 
     */
    public FitxesCategoriaAgendaNombreResultatsResponse createFitxesCategoriaAgendaNombreResultatsResponse() {
        return new FitxesCategoriaAgendaNombreResultatsResponse();
    }

    /**
     * Create an instance of {@link FitxesCategoriaAgendaNombreResultatsDataResponse }
     * 
     */
    public FitxesCategoriaAgendaNombreResultatsDataResponse createFitxesCategoriaAgendaNombreResultatsDataResponse() {
        return new FitxesCategoriaAgendaNombreResultatsDataResponse();
    }

    /**
     * Create an instance of {@link AgendaResponse }
     * 
     */
    public AgendaResponse createAgendaResponse() {
        return new AgendaResponse();
    }

    /**
     * Create an instance of {@link FitxesCategoriaAgendaDatesResponse }
     * 
     */
    public FitxesCategoriaAgendaDatesResponse createFitxesCategoriaAgendaDatesResponse() {
        return new FitxesCategoriaAgendaDatesResponse();
    }

    /**
     * Create an instance of {@link DetallsFitxaActivitatResponse }
     * 
     */
    public DetallsFitxaActivitatResponse createDetallsFitxaActivitatResponse() {
        return new DetallsFitxaActivitatResponse();
    }

    /**
     * Create an instance of {@link AgendaNombreResultatsResponse }
     * 
     */
    public AgendaNombreResultatsResponse createAgendaNombreResultatsResponse() {
        return new AgendaNombreResultatsResponse();
    }

    /**
     * Create an instance of {@link EquipamentsFitxaResponse }
     * 
     */
    public EquipamentsFitxaResponse createEquipamentsFitxaResponse() {
        return new EquipamentsFitxaResponse();
    }

    /**
     * Create an instance of {@link BeanRespostaTipus6 }
     * 
     */
    public BeanRespostaTipus6 createBeanRespostaTipus6() {
        return new BeanRespostaTipus6();
    }

    /**
     * Create an instance of {@link FitxesCategoriaAgendaPaginada }
     * 
     */
    public FitxesCategoriaAgendaPaginada createFitxesCategoriaAgendaPaginada() {
        return new FitxesCategoriaAgendaPaginada();
    }

    /**
     * Create an instance of {@link AgendaNombreResultatsDataResponse }
     * 
     */
    public AgendaNombreResultatsDataResponse createAgendaNombreResultatsDataResponse() {
        return new AgendaNombreResultatsDataResponse();
    }

    /**
     * Create an instance of {@link HorarisFitxa }
     * 
     */
    public HorarisFitxa createHorarisFitxa() {
        return new HorarisFitxa();
    }

    /**
     * Create an instance of {@link ImgsFitxaResponse }
     * 
     */
    public ImgsFitxaResponse createImgsFitxaResponse() {
        return new ImgsFitxaResponse();
    }

    /**
     * Create an instance of {@link FitxesEquipamentPerIdDataResponse }
     * 
     */
    public FitxesEquipamentPerIdDataResponse createFitxesEquipamentPerIdDataResponse() {
        return new FitxesEquipamentPerIdDataResponse();
    }

    /**
     * Create an instance of {@link FitxesTipusAgendaDatesResponse }
     * 
     */
    public FitxesTipusAgendaDatesResponse createFitxesTipusAgendaDatesResponse() {
        return new FitxesTipusAgendaDatesResponse();
    }

    /**
     * Create an instance of {@link FitxesTipusAgendaPaginadaResponse }
     * 
     */
    public FitxesTipusAgendaPaginadaResponse createFitxesTipusAgendaPaginadaResponse() {
        return new FitxesTipusAgendaPaginadaResponse();
    }

    /**
     * Create an instance of {@link FitxesTipusAgendaPaginadaDataResponse }
     * 
     */
    public FitxesTipusAgendaPaginadaDataResponse createFitxesTipusAgendaPaginadaDataResponse() {
        return new FitxesTipusAgendaPaginadaDataResponse();
    }

    /**
     * Create an instance of {@link DetallsFitxaActivitat }
     * 
     */
    public DetallsFitxaActivitat createDetallsFitxaActivitat() {
        return new DetallsFitxaActivitat();
    }

    /**
     * Create an instance of {@link FitxesCategoriaAgendaNombreResultats }
     * 
     */
    public FitxesCategoriaAgendaNombreResultats createFitxesCategoriaAgendaNombreResultats() {
        return new FitxesCategoriaAgendaNombreResultats();
    }

    /**
     * Create an instance of {@link AgendaPaginadaResponse }
     * 
     */
    public AgendaPaginadaResponse createAgendaPaginadaResponse() {
        return new AgendaPaginadaResponse();
    }

    /**
     * Create an instance of {@link FitxesAgendaParaulesClauResponse }
     * 
     */
    public FitxesAgendaParaulesClauResponse createFitxesAgendaParaulesClauResponse() {
        return new FitxesAgendaParaulesClauResponse();
    }

    /**
     * Create an instance of {@link CategoriesAgendaResponse }
     * 
     */
    public CategoriesAgendaResponse createCategoriesAgendaResponse() {
        return new CategoriesAgendaResponse();
    }

    /**
     * Create an instance of {@link BeanRespostaTipus3 }
     * 
     */
    public BeanRespostaTipus3 createBeanRespostaTipus3() {
        return new BeanRespostaTipus3();
    }

    /**
     * Create an instance of {@link FitxesEquipamentPerIdDatesResponse }
     * 
     */
    public FitxesEquipamentPerIdDatesResponse createFitxesEquipamentPerIdDatesResponse() {
        return new FitxesEquipamentPerIdDatesResponse();
    }

    /**
     * Create an instance of {@link FitxesAgendaParaulesClau }
     * 
     */
    public FitxesAgendaParaulesClau createFitxesAgendaParaulesClau() {
        return new FitxesAgendaParaulesClau();
    }

    /**
     * Create an instance of {@link FitxesTipusAgendaPaginadaDates }
     * 
     */
    public FitxesTipusAgendaPaginadaDates createFitxesTipusAgendaPaginadaDates() {
        return new FitxesTipusAgendaPaginadaDates();
    }

    /**
     * Create an instance of {@link EquipamentsFitxa }
     * 
     */
    public EquipamentsFitxa createEquipamentsFitxa() {
        return new EquipamentsFitxa();
    }

    /**
     * Create an instance of {@link FitxesTipusAgendaResponse }
     * 
     */
    public FitxesTipusAgendaResponse createFitxesTipusAgendaResponse() {
        return new FitxesTipusAgendaResponse();
    }

    /**
     * Create an instance of {@link AgendaNombreResultats }
     * 
     */
    public AgendaNombreResultats createAgendaNombreResultats() {
        return new AgendaNombreResultats();
    }

    /**
     * Create an instance of {@link FitxesCategoriaAgendaPaginadaDatesResponse }
     * 
     */
    public FitxesCategoriaAgendaPaginadaDatesResponse createFitxesCategoriaAgendaPaginadaDatesResponse() {
        return new FitxesCategoriaAgendaPaginadaDatesResponse();
    }

    /**
     * Create an instance of {@link AgendaPaginadaDates }
     * 
     */
    public AgendaPaginadaDates createAgendaPaginadaDates() {
        return new AgendaPaginadaDates();
    }

    /**
     * Create an instance of {@link EquipamentsDisponiblesNombreResultatsResponse }
     * 
     */
    public EquipamentsDisponiblesNombreResultatsResponse createEquipamentsDisponiblesNombreResultatsResponse() {
        return new EquipamentsDisponiblesNombreResultatsResponse();
    }

    /**
     * Create an instance of {@link AgendaDataResponse }
     * 
     */
    public AgendaDataResponse createAgendaDataResponse() {
        return new AgendaDataResponse();
    }

    /**
     * Create an instance of {@link FitxesCategoriaAgendaNombreResultatsDates }
     * 
     */
    public FitxesCategoriaAgendaNombreResultatsDates createFitxesCategoriaAgendaNombreResultatsDates() {
        return new FitxesCategoriaAgendaNombreResultatsDates();
    }

    /**
     * Create an instance of {@link FitxesCategoriaAgendaResponse }
     * 
     */
    public FitxesCategoriaAgendaResponse createFitxesCategoriaAgendaResponse() {
        return new FitxesCategoriaAgendaResponse();
    }

    /**
     * Create an instance of {@link FitxesTipusAgendaNombreResultatsDates }
     * 
     */
    public FitxesTipusAgendaNombreResultatsDates createFitxesTipusAgendaNombreResultatsDates() {
        return new FitxesTipusAgendaNombreResultatsDates();
    }

    /**
     * Create an instance of {@link EquipamentsDisponiblesNombreResultats }
     * 
     */
    public EquipamentsDisponiblesNombreResultats createEquipamentsDisponiblesNombreResultats() {
        return new EquipamentsDisponiblesNombreResultats();
    }

    /**
     * Create an instance of {@link DetallsFitxaEquipamentResponse }
     * 
     */
    public DetallsFitxaEquipamentResponse createDetallsFitxaEquipamentResponse() {
        return new DetallsFitxaEquipamentResponse();
    }

    /**
     * Create an instance of {@link FitxesCategoriaAgendaNombreResultatsDatesResponse }
     * 
     */
    public FitxesCategoriaAgendaNombreResultatsDatesResponse createFitxesCategoriaAgendaNombreResultatsDatesResponse() {
        return new FitxesCategoriaAgendaNombreResultatsDatesResponse();
    }

    /**
     * Create an instance of {@link Agenda }
     * 
     */
    public Agenda createAgenda() {
        return new Agenda();
    }

    /**
     * Create an instance of {@link FitxesCategoriaAgendaPaginadaDates }
     * 
     */
    public FitxesCategoriaAgendaPaginadaDates createFitxesCategoriaAgendaPaginadaDates() {
        return new FitxesCategoriaAgendaPaginadaDates();
    }

    /**
     * Create an instance of {@link DetallsFitxaEquipament }
     * 
     */
    public DetallsFitxaEquipament createDetallsFitxaEquipament() {
        return new DetallsFitxaEquipament();
    }

    /**
     * Create an instance of {@link FitxesCategoriaAgendaPaginadaResponse }
     * 
     */
    public FitxesCategoriaAgendaPaginadaResponse createFitxesCategoriaAgendaPaginadaResponse() {
        return new FitxesCategoriaAgendaPaginadaResponse();
    }

    /**
     * Create an instance of {@link FitxesCategoriaAgendaPaginadaData }
     * 
     */
    public FitxesCategoriaAgendaPaginadaData createFitxesCategoriaAgendaPaginadaData() {
        return new FitxesCategoriaAgendaPaginadaData();
    }

    /**
     * Create an instance of {@link FitxesCategoriaAgendaPaginadaDataResponse }
     * 
     */
    public FitxesCategoriaAgendaPaginadaDataResponse createFitxesCategoriaAgendaPaginadaDataResponse() {
        return new FitxesCategoriaAgendaPaginadaDataResponse();
    }

    /**
     * Create an instance of {@link AgendaNombreResultatsDates }
     * 
     */
    public AgendaNombreResultatsDates createAgendaNombreResultatsDates() {
        return new AgendaNombreResultatsDates();
    }

    /**
     * Create an instance of {@link FitxesTipusAgendaDataResponse }
     * 
     */
    public FitxesTipusAgendaDataResponse createFitxesTipusAgendaDataResponse() {
        return new FitxesTipusAgendaDataResponse();
    }

    /**
     * Create an instance of {@link TipusAgendaResponse }
     * 
     */
    public TipusAgendaResponse createTipusAgendaResponse() {
        return new TipusAgendaResponse();
    }

    /**
     * Create an instance of {@link EquipamentsDisponiblesResponse }
     * 
     */
    public EquipamentsDisponiblesResponse createEquipamentsDisponiblesResponse() {
        return new EquipamentsDisponiblesResponse();
    }

    /**
     * Create an instance of {@link FitxesTipusAgendaPaginadaData }
     * 
     */
    public FitxesTipusAgendaPaginadaData createFitxesTipusAgendaPaginadaData() {
        return new FitxesTipusAgendaPaginadaData();
    }

    /**
     * Create an instance of {@link FitxesTipusAgendaNombreResultatsResponse }
     * 
     */
    public FitxesTipusAgendaNombreResultatsResponse createFitxesTipusAgendaNombreResultatsResponse() {
        return new FitxesTipusAgendaNombreResultatsResponse();
    }

    /**
     * Create an instance of {@link FitxesEquipamentPerIdData }
     * 
     */
    public FitxesEquipamentPerIdData createFitxesEquipamentPerIdData() {
        return new FitxesEquipamentPerIdData();
    }

    /**
     * Create an instance of {@link FitxesCategoriaAgendaNombreResultatsData }
     * 
     */
    public FitxesCategoriaAgendaNombreResultatsData createFitxesCategoriaAgendaNombreResultatsData() {
        return new FitxesCategoriaAgendaNombreResultatsData();
    }

    /**
     * Create an instance of {@link FitxesTipusAgendaNombreResultatsData }
     * 
     */
    public FitxesTipusAgendaNombreResultatsData createFitxesTipusAgendaNombreResultatsData() {
        return new FitxesTipusAgendaNombreResultatsData();
    }

    /**
     * Create an instance of {@link FitxesEquipamentPerId }
     * 
     */
    public FitxesEquipamentPerId createFitxesEquipamentPerId() {
        return new FitxesEquipamentPerId();
    }

    /**
     * Create an instance of {@link AgendaPaginadaData }
     * 
     */
    public AgendaPaginadaData createAgendaPaginadaData() {
        return new AgendaPaginadaData();
    }

    /**
     * Create an instance of {@link IdiomesFitxaResponse }
     * 
     */
    public IdiomesFitxaResponse createIdiomesFitxaResponse() {
        return new IdiomesFitxaResponse();
    }

    /**
     * Create an instance of {@link BeanRespostaTipus1 }
     * 
     */
    public BeanRespostaTipus1 createBeanRespostaTipus1() {
        return new BeanRespostaTipus1();
    }

    /**
     * Create an instance of {@link AgendaNombreResultatsDatesResponse }
     * 
     */
    public AgendaNombreResultatsDatesResponse createAgendaNombreResultatsDatesResponse() {
        return new AgendaNombreResultatsDatesResponse();
    }

    /**
     * Create an instance of {@link FitxaActivitat }
     * 
     */
    public FitxaActivitat createFitxaActivitat() {
        return new FitxaActivitat();
    }

    /**
     * Create an instance of {@link ArrayOfIdentificadorEquipament }
     * 
     */
    public ArrayOfIdentificadorEquipament createArrayOfIdentificadorEquipament() {
        return new ArrayOfIdentificadorEquipament();
    }

    /**
     * Create an instance of {@link ArrayOfIdentificadorActivitat }
     * 
     */
    public ArrayOfIdentificadorActivitat createArrayOfIdentificadorActivitat() {
        return new ArrayOfIdentificadorActivitat();
    }

    /**
     * Create an instance of {@link TipCatAgenda }
     * 
     */
    public TipCatAgenda createTipCatAgenda() {
        return new TipCatAgenda();
    }

    /**
     * Create an instance of {@link ArrayOfDocImg }
     * 
     */
    public ArrayOfDocImg createArrayOfDocImg() {
        return new ArrayOfDocImg();
    }

    /**
     * Create an instance of {@link FitxaEquipament }
     * 
     */
    public FitxaEquipament createFitxaEquipament() {
        return new FitxaEquipament();
    }

    /**
     * Create an instance of {@link ArrayOfFitxaEquipament }
     * 
     */
    public ArrayOfFitxaEquipament createArrayOfFitxaEquipament() {
        return new ArrayOfFitxaEquipament();
    }

    /**
     * Create an instance of {@link ArrayOfFitxaActivitat }
     * 
     */
    public ArrayOfFitxaActivitat createArrayOfFitxaActivitat() {
        return new ArrayOfFitxaActivitat();
    }

    /**
     * Create an instance of {@link DocImg }
     * 
     */
    public DocImg createDocImg() {
        return new DocImg();
    }

    /**
     * Create an instance of {@link FitxaHorari }
     * 
     */
    public FitxaHorari createFitxaHorari() {
        return new FitxaHorari();
    }

    /**
     * Create an instance of {@link ArrayOfFitxaHorari }
     * 
     */
    public ArrayOfFitxaHorari createArrayOfFitxaHorari() {
        return new ArrayOfFitxaHorari();
    }

    /**
     * Create an instance of {@link ArrayOfTipCatAgenda }
     * 
     */
    public ArrayOfTipCatAgenda createArrayOfTipCatAgenda() {
        return new ArrayOfTipCatAgenda();
    }

    /**
     * Create an instance of {@link Idioma }
     * 
     */
    public Idioma createIdioma() {
        return new Idioma();
    }

    /**
     * Create an instance of {@link IdentificadorEquipament }
     * 
     */
    public IdentificadorEquipament createIdentificadorEquipament() {
        return new IdentificadorEquipament();
    }

    /**
     * Create an instance of {@link ArrayOfIdioma }
     * 
     */
    public ArrayOfIdioma createArrayOfIdioma() {
        return new ArrayOfIdioma();
    }

    /**
     * Create an instance of {@link IdentificadorActivitat }
     * 
     */
    public IdentificadorActivitat createIdentificadorActivitat() {
        return new IdentificadorActivitat();
    }

}
