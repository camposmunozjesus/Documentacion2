package rrhh

import org.weceem.content.WcmContent

/**
 * 
 * @author Jesus Campos
 * <br>Ahora las im�genes se cargan del servidor y es capaz de cargar correctamente la p�gina Informacio_General.
 * Migas de pan: como mucho se hace una consulta a base de datos para obtenerlas, situaci�n que se da cuando entramos en una
 * ficha.
 * Cuando una URL no existe redirige a la p�gina de inicio /IniciPDIPAS/index.
 */
class Test10Controller {

	def static allowedTypes = ['org.weceem.html.WcmHTMLContent', 'com.upc.WcmPlantillaFitxa', 'com.upc.WcmPlantillaFitxa2ColGenerica', 'com.upc.WcmPlantillaFitxaGenerica']
	def actualSpace = 2711

	def index() {
		def template
		def webPage
		def values = request.forwardURI.toString().split("/")
		
		//Captura el aliasuri de la p�gina visitada.
		def page = values[values.size()-1]
			   
		def query = {
			and{
				eq("space", actualSpace)
				eq("aliasuri", page)
				'in'("type", allowedTypes)	
			}
		}
		
		//Carga de la p�gina Inici
		def pageContent = WcmContent.createCriteria().list(query)
		
		//Si la p�gina buscada no existe nos redirecciona al /IniciPDIPAS/PAS/index/, y esta p�gina s� existir�.
		if(!pageContent){
			query = {
				and{
					eq("space", actualSpace)
					eq("aliasuri", "index")
					'in'("type", allowedTypes)	
				}
			}
			
			//Carga de la p�gina Inici
			pageContent = WcmContent.createCriteria().list(query)
			
			values = "/IniciPDIPAS/PAS/index/".split("/")
		}
		
		pageContent = pageContent[0]
		
		if(pageContent.tmpl)
		{
			template= pageContent.tmpl
			//Carga del template
			def pageTemplate = WcmContent.findByIdentityAndSpace(template, actualSpace)
			
			webPage = pageTemplate.content.replace("<wcm:content />", pageContent.content)
		}
		else{
			webPage = pageContent.content
		}
		
		//Para Grails 2.4.3
		webPage = webPage.replace("/Portal/PAS/index", "/IniciPDIPAS/PAS/index")
	    webPage = webPage.replace("/Portal/PAS/css", "/IniciPDIPAS/css")
		webPage = webPage.replace("/Portal/PAS/js", "/IniciPDIPAS/js")
		//Las tres l�neas anteriores se solucionan con regexp si en el template se tiene ${wcm.Link ...
		if(!(pageContent.type == "com.upc.WcmPlantillaFitxa" || pageContent.type == "com.upc.WcmPlantillaFitxaGenerica")){
			webPage = webPage.replace("<a href=\"/Portal", "<a href=\"/IniciPDIPAS")
		}
		
		webPage = webPage.replace("\${wcm.loggedInUserName().encodeAsHTML()}", "")
   
		webPage = webPage.replace("\${node.title.encodeAsHTML()}", pageContent.title)
   
		 //Redirecci�n de la p�gina
		 //${grails.util.Metadata.current.'app.name'}/${space?.name}/index/Informacio_General
		 webPage = webPage.replace("\${grails.util.Metadata.current.'app.name'}", "IniciPDIPAS")
		 webPage = webPage.replace("\${space?.name}", "PAS")
		   
		 //S�lo las consulto si estoy en una ficha.
		 if(pageContent.type == "com.upc.WcmPlantillaFitxa" || pageContent.type == "com.upc.WcmPlantillaFitxaGenerica"){
			 webPage = webPage.replace("<!--breadCrumb-->", getBreadCrumb( values[3..(values.size()-1)], pageContent.title))
		 }
		   
		//Buscador
		if(webPage.contains("<upc:search max=\"15\" eraseplaceholder=\"no\" placeholder=\"Cercar...\" types=\"com.upc.WcmPlantillaFitxa\"></upc:search>")){
			webPage = webPage.replace("<upc:search max=\"15\" eraseplaceholder=\"no\" placeholder=\"Cercar...\" types=\"com.upc.WcmPlantillaFitxa\"></upc:search>", "<form action=\"https://melnik.upc.edu/Portal/cms/tools/search?uri=PAS%2F&amp;max=15&amp;erasePlaceHolder=no&amp;placeHolder=Cercar...&amp;types=com.upc.WcmPlantillaFitxa\" method=\"post\"><input name=\"query\" class=\"customSearchField\" placeholder=\"Cercar...\" onfocus=\"\" value=\"\" id=\"query\" type=\"text\"><input name=\"submit\" class=\"customSearchButton\" value=\"Cerca\" id=\"submit\" type=\"submit\"></form>")
		}
		  
		render(text: webPage, contentType: "text/html", encoding: "UTF-8")
	}
	
	/**
	 * Migas de Pan<br>
	 * Est�n hardcoded en las p�ginas de Inici, Informaci� General y Desplegables con dos columnas. Por lo tanto s�lo se 
	 * utilizar� este m�todo para las fichas.
	 * El String devuelto substituir� al comentario <!--breadCrumb--> en la p�gina.
	 * @param	urlList		Sirve para formar la URL a la que enlaza cada miga de pan y para los t�tulos que se ver�n. Se usa values[3..(values.size()-1)] debido a que los primeros valores de este vector son "", "index", "PAS", y no hacen falta
	 * @param	pageTitle	Es el t�tulo de la p�gina actual
	 * @return 	Devuelve un String, con el correspondiente formato HTML, para las migas de pan del InciciPDIPAS.
	 */
	private String getBreadCrumb( urlList, pageTitle){
		def mdpAddr = "/IniciPDIPAS/PAS"
		def mdpStr = "<b>Sou a <span class=\"breadCrumbSeparator firstSeparator\">&raquo;</span></b>"
				 
		def mdpAliasuri = urlList
		def mdpTitle = urlList

		//TITLE: Los dos primeros valores son siempre los mismos. En el caso de Rac� Personal, sobreescribir� Informaci� General.
		mdpTitle[0]="Inici"
		mdpTitle[1]="Informaci\u00f3 General"
		if(mdpTitle.size()>3){
			//Si estamos en una ficha, se consulta el nombre en la BD del apartado del men� izquierdo.
			def fitxa = WcmContent.findByAliasuriAndSpace(mdpAliasuri[2], actualSpace)
			mdpTitle[2] = fitxa.title
			
		}
		mdpTitle[mdpTitle.size()-1]=pageTitle

		//Generaci�n del mapa key(aliasuri):value(title)
		def pairs = [mdpAliasuri, mdpTitle].transpose()
		def breadMap = [:]
		pairs.each{ k, v -> breadMap[k] = v }
		
		//Generaci�n del String con key(aliasuri):value(title).
		breadMap.each{
			 mdpAddr += "/"+it.key
			 if (!(it.key==urlList.last())){
				 mdpStr += "<a href=\"$mdpAddr\"><span class=\"breadCrumbItem\">"+it.value+"</span></a><span class=\"breadCrumbSeparator\">&rsaquo;</span>"
			 }
			 else{
				 mdpStr += "<span class=\"breadCrumbLastItem\">"+it.value+"</span>"
			 }
		}
		
		return mdpStr
	}
}
