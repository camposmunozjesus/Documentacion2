
package net.gramene.appcoloma;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="equipamentsDisponiblesResult" type="{http://www.gramene.net/appcoloma/}BeanRespostaTipus5" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "equipamentsDisponiblesResult"
})
@XmlRootElement(name = "equipamentsDisponiblesResponse")
public class EquipamentsDisponiblesResponse {

    protected BeanRespostaTipus5 equipamentsDisponiblesResult;

    /**
     * Gets the value of the equipamentsDisponiblesResult property.
     * 
     * @return
     *     possible object is
     *     {@link BeanRespostaTipus5 }
     *     
     */
    public BeanRespostaTipus5 getEquipamentsDisponiblesResult() {
        return equipamentsDisponiblesResult;
    }

    /**
     * Sets the value of the equipamentsDisponiblesResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link BeanRespostaTipus5 }
     *     
     */
    public void setEquipamentsDisponiblesResult(BeanRespostaTipus5 value) {
        this.equipamentsDisponiblesResult = value;
    }

}
