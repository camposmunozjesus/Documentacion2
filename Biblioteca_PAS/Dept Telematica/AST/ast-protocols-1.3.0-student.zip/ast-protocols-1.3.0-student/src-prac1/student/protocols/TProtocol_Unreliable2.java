
package student.protocols;

import ast.protocols.transportCO.TProtocol;
import ast.protocols.transportCO.TCBlock;
import ast.protocols.tcp.TCPSegment;

import ast.util.ByteQueue;

import java.io.IOException;


public class TProtocol_Unreliable2 extends TProtocol_Unreliable1 {
    @Override
    protected TCBlock newTCB(int port) {
        return new TCBlock_Unreliable2(this, port);
    }
}

class TCBlock_Unreliable2 extends TCBlock_Unreliable1 {
    protected int sndMSS;   // Send maximum segment size

    TCBlock_Unreliable2(TProtocol proto, int port) {
        super(proto, port);
    }

    // initialize for new connection
    @Override
    protected void initActive(int remAddr, int remPort, int st) {
        // To be completed by the student:
        throw new RuntimeException("NOT YET IMPLEMENTED (To be completed by the student)");
    }

    @Override
    public void sendData(byte[] data, int data_off, int data_len) throws IOException {
        // To be completed by the student:
        throw new RuntimeException("NOT YET IMPLEMENTED (To be completed by the student)");
    }
}

