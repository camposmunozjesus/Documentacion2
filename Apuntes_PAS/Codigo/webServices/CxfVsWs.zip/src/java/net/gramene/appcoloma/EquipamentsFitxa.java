
package net.gramene.appcoloma;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idFitxa" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "idFitxa"
})
@XmlRootElement(name = "equipamentsFitxa")
public class EquipamentsFitxa {

    protected int idFitxa;

    /**
     * Gets the value of the idFitxa property.
     * 
     */
    public int getIdFitxa() {
        return idFitxa;
    }

    /**
     * Sets the value of the idFitxa property.
     * 
     */
    public void setIdFitxa(int value) {
        this.idFitxa = value;
    }

}
