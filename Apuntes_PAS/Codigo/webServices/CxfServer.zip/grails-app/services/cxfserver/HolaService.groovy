package cxfserver

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.xml.bind.annotation.XmlElement;

import grails.transaction.Transactional

@Transactional
class HolaService {

	static expose=['cxfjax']
	
	@WebMethod(operationName="getTotes") 
	String getTotes(){
	  return "jesus"
	}
}
