package cxfserver

import javax.activation.DataHandler
import javax.activation.DataSource
import javax.activation.FileDataSource
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.xml.bind.annotation.XmlElement;
import javax.jws.WebService
import javax.xml.ws.soap.MTOM

import com.cxf.demo.SimpleResponse;
import com.file.FileUploader
import cxf.mtom.server.bean.ResponseDownloadFile



@MTOM(enabled = true)
class SendFileService {
	
	static transactional = false

	static expose=['cxfjax']
	
	@WebMethod(operationName="getFichero") 
	String getFichero(){
	  return "fichero"
	}
	
	@WebMethod(operationName="getSR")
	String getSR(){
		SimpleResponse sr = new SimpleResponse();
		sr.isOld=true
		sr.status="pruebas"
	  return sr
	}
	
	@WebMethod(operationName="sendFile")
	ResponseDownloadFile sendFile(){
        ResponseDownloadFile rdf = new ResponseDownloadFile();
        rdf.setFileName("d:/uploads/readme.txt");
        rdf.setFileType("plain/text");
        rdf.setFile(new DataHandler(new FileDataSource(new File("D:/uploads/readme.txt"))));
        return rdf;
	}
}
