package es.ua.jtech.ajdm.s14;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Main extends Activity {
    /** Called when the activity is first created. */
	private static final String FILENAME = "mytextfile.txt";
	Button escribirButton; 
	EditText editText;
	TextView textView;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        editText = (EditText)findViewById(R.id.EditText01);
        escribirButton = (Button)findViewById(R.id.Button01);
        escribirButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				try {
					  OutputStreamWriter out = new OutputStreamWriter(
							  openFileOutput(FILENAME,Context.MODE_APPEND));
					  out.append(editText.getText()+"\n");
					  editText.setText("");
					  out.close();
					} catch (java.io.IOException e) {
					  Log.e("FILE", "IOError while writing "+ FILENAME);
					}				
				
			}
		});

        textView = (TextView)findViewById(R.id.TextView01);
        textView.setClickable(true);
        textView.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				  textView.setText("");
				  try {
					    InputStream inputStream = openFileInput(FILENAME);
					    if (inputStream != null) {
					      InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
					      BufferedReader buffreader = new BufferedReader(inputStreamReader);
					      String line=null;
					      //Leer línea a línea
					      line = buffreader.readLine();
					      while (line != null) {
					    	  textView.append(line+"\n");
					    	  line = buffreader.readLine();
					      }
					    }
					 
					    // close the file again
					    inputStream.close();
					  } catch (java.io.FileNotFoundException e) {
						  Log.e("FILE", "File not found: "+ FILENAME);
					  } catch (IOException e) {
						  Log.e("FILE", "IOError while reading "+ FILENAME);
					  }
					  Toast.makeText(getApplicationContext(), 
							  R.string.recargado, Toast.LENGTH_LONG).show();

			}
		});
    }
	@Override
	protected void onResume() {
		super.onResume();
		Toast.makeText(getApplicationContext(), R.string.recargar, Toast.LENGTH_LONG).show();
	}
    
   
}