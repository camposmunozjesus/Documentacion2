//
//  UAPelicula.m
//  Filmoteca
//
//  Created by Miguel Angel Lozano on 20/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "UAPelicula.h"

@implementation UAPelicula

#pragma mark Inicializadores

- (id)init {
    return [self initWithTitulo:@"Sin titulo"];
}

- (id)initWithTitulo:(NSString *)titulo {
    return [self initWithTitulo:titulo director:@"Desconocido" calificacion:TP puntuacion:-1 estreno:[NSDate date]];
}

- (id)initWithTitulo:(NSString *)titulo director:(NSString *)director calificacion:(UACalificacionEdad)calificacion puntuacion:(CGFloat)puntuacion estreno:(NSDate *)estreno {
    
    self = [super init];
    if(self!=nil) {
        _titulo = [titulo retain];
        _director = [director retain];
        _calificacion = calificacion;
        _puntuacion = puntuacion;   
        _estreno = [estreno retain];
    }
    return self;
}

#pragma mark Metodos factoria

+ (id)pelicula {
    return [[[self alloc] init] autorelease];
}

+ (id)peliculaWithTitulo:(NSString *)titulo {
    return [[[self alloc] initWithTitulo:titulo] autorelease];
}

+ (id)peliculaWithTitulo:(NSString *)titulo director:(NSString *)director calificacion:(UACalificacionEdad)calificacion puntuacion:(CGFloat)puntuacion estreno:(NSDate *)estreno {
    return [[[self alloc] initWithTitulo:titulo director:director calificacion:calificacion puntuacion:puntuacion estreno:estreno] autorelease];
}

#pragma mark Metodos de UAPelicula

- (NSInteger)antiguedad {
    NSDateComponents *comps = [[NSCalendar currentCalendar] components: NSYearCalendarUnit fromDate:_estreno toDate:[NSDate date] options:0];
    return [comps year];
}


#pragma mark Metodos de NSObject

- (void)dealloc {
    [_titulo release];
    [_director release];
    [_estreno release];
    [super dealloc];
}

- (NSString *)description {
    NSDateComponents *comps = [[NSCalendar currentCalendar] components: NSYearCalendarUnit fromDate:_estreno];
    return [NSString stringWithFormat:@"%@ (%d, %@)", _titulo, [comps year], _director];
}

@end
