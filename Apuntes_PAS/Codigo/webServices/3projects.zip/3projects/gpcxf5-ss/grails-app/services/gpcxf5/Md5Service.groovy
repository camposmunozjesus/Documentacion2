package gpcxf5

import org.apache.commons.codec.digest.DigestUtils

class Md5Service {

    String calc(InputStream inputStream) {
        return DigestUtils.md5Hex(inputStream)
    }
}
