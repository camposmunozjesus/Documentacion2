package es.ua.jtech.daa.geolocalizacion;

import android.app.Activity;
import android.os.Bundle;

public class ActividadGeolocalizacion extends Activity {

	double latitud, longitud;
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);        
    }

	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		super.onWindowFocusChanged(hasFocus);
		
		if(hasFocus) {
			// TODO Iniciar actualizacion de posicion
		}
	}

}