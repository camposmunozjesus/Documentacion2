package es.ua.jtech.graficos;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.egl.EGLSurface;
import javax.microedition.khronos.opengles.GL10;

import android.content.Context;
import android.opengl.GLU;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class VistaGraficos3D extends SurfaceView implements
		SurfaceHolder.Callback {

	HiloDibujo hilo = null;

	public VistaGraficos3D(Context context) {
		super(context);

		SurfaceHolder holder = this.getHolder();
		holder.addCallback(this);
	}

	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {
		// La superficie ha cambiado (formato o dimensiones)
	}

	public void surfaceCreated(SurfaceHolder holder) {
		hilo = new HiloDibujo(holder, this);
		hilo.start();
	}

	public void surfaceDestroyed(SurfaceHolder holder) {

		hilo.detener();
		try {
			hilo.join();
		} catch (InterruptedException e) {
		}
	}

	class HiloDibujo extends Thread {
		SurfaceHolder holder;
		VistaGraficos3D vista;
		boolean continuar = true;
		
		EGL10 egl;
		GL10 gl;
		EGLDisplay display;
		EGLSurface surface;
		EGLContext contexto;
		EGLConfig config;

		public HiloDibujo(SurfaceHolder holder, VistaGraficos3D vista) {
			this.holder = holder;
			this.vista = vista;
			continuar = true;
		}

		public void detener() {
			continuar = false;
			try {
				this.join();
			} catch (InterruptedException e) { 				
			} finally {
				this.cleanupGL();
			}			
		}

		private void initEGL() {
		    egl = (EGL10)EGLContext.getEGL();
		    display = egl.eglGetDisplay(EGL10.EGL_DEFAULT_DISPLAY);
					
		    int [] version = new int[2];
		    egl.eglInitialize(display, version);
					
		    int [] atributos = new int[] {
		        EGL10.EGL_RED_SIZE, 5,
		        EGL10.EGL_GREEN_SIZE, 6,
		        EGL10.EGL_BLUE_SIZE, 5,
		        EGL10.EGL_DEPTH_SIZE, 16,
		        EGL10.EGL_NONE					
		    };
					
		    EGLConfig [] configs = new EGLConfig[1];
		    int [] numConfigs = new int[1];
		    egl.eglChooseConfig(display, atributos, configs, 1, numConfigs);
				
		    config = configs[0];			
		    surface = egl.eglCreateWindowSurface(display, config, holder, null);			
		    contexto = egl.eglCreateContext(display, config, EGL10.EGL_NO_CONTEXT, null);
		    egl.eglMakeCurrent(display, surface, surface, contexto);
					
		    gl = (GL10)contexto.getGL();
		}
		
		private void initGL() {
		    int width = vista.getWidth();
		    int height = vista.getHeight();
		    gl.glViewport(0, 0, width, height);
		    gl.glMatrixMode(GL10.GL_PROJECTION);
		    gl.glLoadIdentity();
					
		    float aspecto = (float)width/height;
		    GLU.gluPerspective(gl, 45.0f, aspecto, 1.0f, 30.0f);
		    gl.glClearColor(0.5f, 0.5f, 0.5f, 1);			
		}
		
		private void cleanupGL() { 
		    egl.eglMakeCurrent(display, EGL10.EGL_NO_SURFACE,
		            EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_CONTEXT); 
		    egl.eglDestroySurface(display, surface); 
		    egl.eglDestroyContext(display, contexto); 
		    egl.eglTerminate(display);
		}
		
		@Override
		public void run() {
		    initEGL();
		    initGL();
						         
		    Triangulo3D triangulo = new Triangulo3D();
					
		    float angulo = 0.0f;
		    
		    while(continuar) {
		        gl.glClear(GL10.GL_COLOR_BUFFER_BIT | GL10.GL_DEPTH_BUFFER_BIT);

		        // Dibujar gr�ficos aqu�       
		        gl.glMatrixMode(GL10.GL_MODELVIEW);
		        gl.glLoadIdentity();
		        gl.glTranslatef(0, 0, -5.0f);
		        gl.glRotatef(angulo, 0, 1, 0);

		        gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);
			    
		        triangulo.dibujar(gl);

		        angulo += 1.0f;

		        egl.eglSwapBuffers(display, surface);
		    }
		}
	}
}
