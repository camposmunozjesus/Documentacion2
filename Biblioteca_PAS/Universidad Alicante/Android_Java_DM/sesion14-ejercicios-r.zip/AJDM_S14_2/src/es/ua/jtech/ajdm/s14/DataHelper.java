package es.ua.jtech.ajdm.s14;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DataHelper {

   private static final String DATABASE_NAME = "misusuarios.db";
   private static final int DATABASE_VERSION = 2;
   private static final String TABLE_NAME = "usuarios";
   private static final String[] COLUMNAS = {"_id","nombre"};
   
   private Context context;
   private SQLiteDatabase db;

   private SQLiteStatement insertStatement;
   private static final String INSERT = "insert into " + TABLE_NAME + 
     "("+COLUMNAS[1]+") values (?)";
   private static final String CREATE_DB = "CREATE TABLE " + TABLE_NAME + 
	 "("+COLUMNAS[0]+" INTEGER PRIMARY KEY, "+COLUMNAS[1]+" TEXT)";
   

   
   public DataHelper(Context context) {
      this.context = context;
      MiOpenHelper openHelper = new MiOpenHelper(this.context);
      this.db = openHelper.getWritableDatabase();
      this.insertStatement = this.db.compileStatement(INSERT);
   }

   public long insert(String name) {
      this.insertStatement.bindString(1, name);
      return this.insertStatement.executeInsert();
   }

   public int deleteAll() {
      return db.delete(TABLE_NAME, null, null);
   }

   public List<String> selectAll() {
      List<String> list = new ArrayList<String>();
      Cursor cursor = db.query(TABLE_NAME, COLUMNAS, 
        null, null, null, null, null);
      if (cursor.moveToFirst()) {
         do {
            list.add(cursor.getString(1)); 
         } while (cursor.moveToNext());
      }
      if (cursor != null && !cursor.isClosed()) {
         cursor.close();
      }
      return list;
   }

   private static class MiOpenHelper extends SQLiteOpenHelper {

      MiOpenHelper(Context context) {
         super(context, DATABASE_NAME, null, DATABASE_VERSION);
      }

      @Override
      public void onCreate(SQLiteDatabase db) {
         db.execSQL(CREATE_DB);
      }

      @Override
      public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
         Log.w("SQL", "onUpgrade: eliminando tabla si ésta existe, y creándola de nuevo");
         db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
         onCreate(db);
      }
   }
}
