modules = {
    application {
        resource url:'js/application.js'
    }
}