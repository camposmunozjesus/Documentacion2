package es.ua.jtech.daa.appwidget;


import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import android.app.PendingIntent;
import android.app.Service;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.IBinder;
import android.widget.RemoteViews;

public class MiWidget extends AppWidgetProvider {

	@Override
	public void onUpdate(Context context, AppWidgetManager appWidgetManager,
			int[] appWidgetIds) {
        context.startService(new Intent(context, UpdateService.class));
	}

	public static class UpdateService extends Service {

		@Override
		public int onStartCommand(Intent intent, int flags, int startId) {
			RemoteViews updateViews = new RemoteViews(getPackageName(), R.layout.miwidget_layout);

    		String ipstring = "Unknown IP";
    		
            try {
    			URL url = new URL("http://www.whatismyip.org");
    			HttpURLConnection http = (HttpURLConnection)url.openConnection();
    			InputStream is = http.getInputStream();
    			byte[] buffer = new byte[20];
    			is.read(buffer, 0, 20);
    			ipstring = "IP: "+new String(buffer);
            } catch (MalformedURLException e) {
    			e.printStackTrace();
    		} catch (IOException e) {
    			e.printStackTrace();
    		}
    		
    		updateViews.setTextViewText(R.id.TextView01,ipstring);

    		Intent defineIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.whatismyip.org"));
            PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 0, defineIntent, 0);
            updateViews.setOnClickPendingIntent(R.id.miwidget, pendingIntent);
    		
			ComponentName thisWidget = new ComponentName(this, MiWidget.class);
            AppWidgetManager.getInstance(this).updateAppWidget(thisWidget, updateViews);
			return Service.START_STICKY;
		}

		@Override
		public IBinder onBind(Intent intent) {
			return null;
		}
		
	}
}
