package es.ua.jtech.daa.servicionotificaciones;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Main extends Activity {
	Main main;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        main = this;
        
        ((Button)findViewById(R.id.Button01)).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startService(new Intent(main, MiNumerosPrimosServicio.class));
			}
		});
        ((Button)findViewById(R.id.Button02)).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
		    	//stopService(new Intent(main,miServicio.getClass()));
				stopService(new Intent(main,MiNumerosPrimosServicio.class));
			}
		});
        
        
    }

    //TODO Sobrecargar onResume() para cerrar la notificación que
    //nuestro servicio haya podido dejarse abierta. Para ello tenemos
    //que conocer el ID de la notificación. Si efectuamos el cierre
    //en un método estático de MiNumerosPrimosServicio, entonces
    //tendremos que pasarle como parámetro el NotificationsManager,
    //ya que no lo podemos obtener desde un código estático.
   
}