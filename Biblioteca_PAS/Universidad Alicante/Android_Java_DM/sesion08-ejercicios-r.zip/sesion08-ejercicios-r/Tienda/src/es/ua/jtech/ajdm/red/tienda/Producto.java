package es.ua.jtech.ajdm.red.tienda;

import java.io.*;

public class Producto {
	String titulo;
	String tipo;
	String autor;
	int precio;
	boolean stock;

	public Producto(String titulo, String tipo, String autor, int precio, boolean stock) {
		this.titulo = titulo;
		this.tipo = tipo;
		this.autor = autor;
		this.precio = precio;
		this.stock = stock;
	}
	
	public void serialize(OutputStream out) throws IOException {
		DataOutputStream dos = new DataOutputStream(out);
		
		dos.writeUTF(titulo);
		dos.writeUTF(tipo);
		dos.writeUTF(autor);
		dos.writeInt(precio);
		dos.writeBoolean(stock);
	}

	public static Producto deserialize(InputStream in) throws IOException {
		DataInputStream dis = new DataInputStream(in);
		
		String titulo = dis.readUTF();
		String tipo = dis.readUTF();
		String autor = dis.readUTF();
		int precio = dis.readInt();
		boolean stock = dis.readBoolean();
		
		return new Producto(titulo, tipo, autor, precio, stock);
	}

}
