/*
 * Created on 08/06/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.jtech.jdm.sesion14.game.tapper.data;

import java.io.DataInputStream;
import java.io.IOException;

/**
 * @author Miguel Angel
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class StageData {

	public String title;
	public byte numStage; //Este no es leído del fichero
	public byte numBarras;
	public byte numClients;
	public byte probClients;
	public byte probReturn;
	
	public static StageData deserialize(DataInputStream dis) throws IOException {
		StageData data = new StageData();
		data.title = dis.readUTF();
		data.numBarras = dis.readByte();
		data.numClients = dis.readByte();
		data.probClients = dis.readByte();
		data.probReturn = dis.readByte();
		return data;
	}
	
}
