/*
 * Created on 13-sep-2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package es.ua.jtech.mensajes;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ServletMensajes extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		ServletContext sc = this.getServletContext();
		ListaMensajes lista = (ListaMensajes)sc.getAttribute("mensajes");

		// Lee informacion del cliente
		
		InputStream in = req.getInputStream();
		DataInputStream dis = new DataInputStream(in);
		
		long tsCliente = dis.readLong();
		int nMensajesCliente = dis.readInt();
		
		Mensaje [] mensajesCliente = new Mensaje[nMensajesCliente];
		
		for(int i=0;i<nMensajesCliente;i++) {
			mensajesCliente[i] = Mensaje.deserialize(dis);
		}

		// Sincroniza la informacion
		
		SyncItem datosCliente = new SyncItem(tsCliente, mensajesCliente);
		SyncItem datosServidor = lista.sincroniza(datosCliente);
		
		// Envia informacion al cliente
		
		res.setContentType("application/octet-stream");
		OutputStream out = res.getOutputStream();
		DataOutputStream dos = new DataOutputStream(out);
		
		long tsServidor = datosServidor.getTs();
		Mensaje [] mensajesServidor = datosServidor.getMensajes();
		int nMensajesServidor = mensajesServidor.length;
		
		dos.writeLong(tsServidor);
		dos.writeInt(nMensajesServidor);
		for(int i=0;i<nMensajesServidor;i++) {
			mensajesServidor[i].serialize(dos);
		}	
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		doGet(req,res);
	}

}
