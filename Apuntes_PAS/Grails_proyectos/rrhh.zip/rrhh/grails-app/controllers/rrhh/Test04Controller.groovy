package rrhh

import org.weceem.content.WcmContent
import org.weceem.content.WcmSpace

/**
 * 
 * @author Jesus Campos
 * Carga la p�gina de Inici del Portal.
 */
class Test04Controller {

    def index() { 
//		def p = Persona.list()
//		println p.nom
		
		def s = WcmSpace.list()
//		println s.name
		
		def c = WcmContent.list()
//		println c.title
//		println c.space
		
		//Carga del template
		def pageTemplate = WcmContent.findByAliasuriAndSpace('Inici', 2711)
//		println pageTemplate.title
//		println pageTemplate.content
//		pageTemplate.content = pageTemplate.content.replace("max=\"15\" eraseplaceholder=\"no\" placeholder=\"Cercar...\" types=\"com.", "BUSCADOR PROPIO UPC")
//		println pageTemplate.content
		
		//Carga de la p�gina Inici
		def pageContent = WcmContent.findByAliasuriAndSpace('index', 2711)
//		println pageContent.title
//		println pageContent.content
		
//		def pagina = "<div class=\"testingClass\"> HOME land<div>"
		
		def webPage = pageTemplate.content.replace("<wcm:content />", pageContent.content)
//		def webPage = pageTemplate.content.replace("<wcm:content />", pagina)
		
//		webPage = pageTemplate.content.replace("\${wcm.createLink(path:'css/", "\${resource(dir:'css',file:'bootstrap/")
		
//		webPage = pageTemplate.content.replace("<link rel=\"shortcut icon\" href=\"\${wcm.createLink(path:'images/favicon.ico')}\" type=\"image/x-icon\" />", "<!-- -->")
//		webPage = pageTemplate.content.replace("<script type=\"text/javascript\" src=\"\${wcm.createLink(path:'js/jquery/jquery-1.11.1.min.js')}\"></script>", "<!-- -->")
//		webPage = pageTemplate.content.replace("<script type=\"text/javascript\" src=\"\${wcm.createLink(path:'js/bootstrap.min.js')}\"></script>", "<!-- -->")
		
//		webPage = pageTemplate.content.replace("\${wcm.createLink(path:'css/", "\${resource(dir:'css',file:'bootstrap/")
		//La siguiente no sirve porque no se toma como variable el segundo arg
//		webPage = pageTemplate.content.replace("\${wcm.createLink(path:'", "\${resource(dir:'',file:'")
		//JS Y CSS : /Portal/PAS/ por /IniciPDIPAS/static/
//		webPage = webPage.replace("/Portal/PAS/", "/IniciPDIPAS/static/")
		//Para Grails 2.4.3
		webPage = webPage.replace("/Portal/PAS/", "/IniciPDIPAS/")
		//
//		webPage = webPage.replace("\${wcm.createLinkToFile(path:", "{(")
		webPage = webPage.replace("\${wcm.loggedInUserName().encodeAsHTML()}", "")
		
		webPage = webPage.replace("\${node.title.encodeAsHTML()}", pageContent.title)
		
		//Redirecci�n de la p�gina
		//${grails.util.Metadata.current.'app.name'}/${space?.name}/index/Informacio_General
		webPage = webPage.replace("\${grails.util.Metadata.current.'app.name'}", "Portal")
		webPage = webPage.replace("\${space?.name}", "PAS")
		
//		if(webPage.contains("<upc:search max=\"15\" eraseplaceholder=\"no\" placeholder=\"Cercar...\" types=\"com.upc.WcmPlantillaFitxa\"></upc:search>")){
//			println "LOC OCNTIENE"+new Date()
//		}
//		else{
//			println "NO LO CONTIENE"+new Date()
//		}
//		webPage = webPage.replace("\${wcm.createLink(path:'js/", "\${resource(dir:'js',file:'")
		
//		webPage = webPage.replace("<link rel=\"shortcut icon\" href=\"\${wcm.createLink(path:'images/favicon.ico')}\" type=\"image/x-icon\" />", "<!-- -->")
//		webPage = webPage.replace("<script type=\"text/javascript\" src=\"\${wcm.createLink(path:'js/jquery/jquery-1.11.1.min.js')}\"></script>", "<!-- -->")
//		webPage = webPage.replace("<script type=\"text/javascript\" src=\"\${wcm.createLink(path:'js/bootstrap.min.js')}\"></script>", "<!-- -->")
		
		//A eliminar
		 
		
		
//		println "PAG DEF"
//		println webPage
		
//		
//		[pagina:pagina]
//		render(text: "<br>HOME<br>", contentType: "text/html", encoding: "UTF-8")
		
		render(text: webPage, contentType: "text/html", encoding: "UTF-8")
	}
}

