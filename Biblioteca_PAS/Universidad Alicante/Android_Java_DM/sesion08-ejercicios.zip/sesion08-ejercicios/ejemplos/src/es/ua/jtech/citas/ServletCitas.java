/*
 * Created on 13-sep-2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package es.ua.jtech.citas;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ServletCitas extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		ServletContext sc = this.getServletContext();
		ListaCitas lista = (ListaCitas)sc.getAttribute("citas");

		// Lee informacion del cliente
		
		InputStream in = req.getInputStream();
		DataInputStream dis = new DataInputStream(in);
		
		long tsCliente = dis.readLong();
		int nCitasCliente = dis.readInt();
		
		Cita [] citasCliente = new Cita[nCitasCliente];
		
		for(int i=0;i<nCitasCliente;i++) {
			citasCliente[i] = Cita.deserialize(dis);
		}

		// Sincroniza la informacion
		
		SyncItem datosCliente = new SyncItem(tsCliente, citasCliente);
		SyncItem datosServidor = lista.sincroniza(datosCliente);
		
		// Envia informacion al cliente
		
		res.setContentType("application/octet-stream");
		OutputStream out = res.getOutputStream();
		DataOutputStream dos = new DataOutputStream(out);
		
		long tsServidor = datosServidor.getTs();
		Cita [] citasServidor = datosServidor.getCitas();
		int nCitasServidor = citasServidor.length;
		
		dos.writeLong(tsServidor);
		dos.writeInt(nCitasServidor);
		for(int i=0;i<nCitasServidor;i++) {
			citasServidor[i].serialize(dos);
		}	
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		doGet(req,res);
	}

}
