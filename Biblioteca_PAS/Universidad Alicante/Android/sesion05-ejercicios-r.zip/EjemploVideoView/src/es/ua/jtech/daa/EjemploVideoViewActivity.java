package es.ua.jtech.daa;

import android.app.Activity;
import android.content.Context;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.VideoView;

public class EjemploVideoViewActivity extends Activity {
	private Button butPlay, butPause, butStop;
	VideoView vv;
	boolean paused = false;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        inicializarVideoView();
        initialize();
    }
    
    // Inicializa el MediaPlayer especificando la fuente de datos
    private void inicializarVideoView() {
    	vv = (VideoView)findViewById(R.id.superficie);
    	vv.setKeepScreenOn(true);
    	vv.setVideoPath("/sdcard/coche.3gp");
    }
    
    // Inicializa los botones de la aplicación
    private void initialize() {
    	butPlay = (Button)findViewById(R.id.playbutton);
    	butPause = (Button)findViewById(R.id.pausebutton);
    	butStop = (Button)findViewById(R.id.stopbutton);
    	
    	butPause.setEnabled(false);
    	butStop.setEnabled(false);
    	
    	
    	butPlay.setOnClickListener(playListener);
    	butPause.setOnClickListener(pauseListener);
    	butStop.setOnClickListener(stopListener);
    	
    	vv.setOnCompletionListener(terminarListener);
    }
    
    private OnClickListener playListener = new OnClickListener() {
		public void onClick(View v) {
			vv.seekTo(0);
			vv.start();
	
			butPlay.setEnabled(false);
			butPause.setEnabled(true);
			butStop.setEnabled(true);
		}
    };
    
    private OnClickListener pauseListener = new OnClickListener() {
		public void onClick(View v) {
			if (!paused) {
				vv.pause();
				
				butPause.setText(R.string.resumebutton);
				
				paused = true;
			} else {
				vv.start();
				
				butPause.setText(R.string.pausebutton);
				
				paused = false;
			}
		}
    };
    
    private OnCompletionListener terminarListener = new OnCompletionListener() {
		public void onCompletion(MediaPlayer mp) {
			mp.pause();
			
			butPlay.setEnabled(true);
			butPause.setEnabled(false);
			butStop.setEnabled(false);
		}	
    };
    
    private OnClickListener stopListener = new OnClickListener() {
		public void onClick(View v) {
			vv.pause();
			
			butPlay.setEnabled(true);
			butPause.setEnabled(false);
			butStop.setEnabled(false);
		}
    };
}