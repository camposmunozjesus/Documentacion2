package inicipdipas

import org.weceem.content.WcmContent

class Test01Controller {

	def static allowedTypes = ['org.weceem.html.WcmHTMLContent', 'com.upc.WcmPlantillaFitxa', 'com.upc.WcmPlantillaFitxa2ColGenerica', 'com.upc.WcmPlantillaFitxaGenerica']
	
    def index() {
		println "Entrando Test01Controller INDEX"+params
		def query = {
			and{
				eq("space", 2711)
//				eq("aliasuri", "El-PAS-a-la-UPC")
				eq("aliasuri", "Informacio_General")
				eq("type", 'org.weceem.html.WcmHTMLContent')
			}
		}
		
		//Carga de la p�gina Inici
		def resultList = WcmContent.createCriteria().list(query)
		resultList.each {  
			println it.aliasuri
			println it.identity println "***"
		}
	}
	
	def index2(){
		println "Entrando TESt02Controller INDEX"+params+new Date()
	}
}
