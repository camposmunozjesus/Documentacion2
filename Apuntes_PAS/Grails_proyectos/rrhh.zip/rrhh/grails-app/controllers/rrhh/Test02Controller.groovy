package rrhh

import org.weceem.content.WcmContent

/**
 * 
 * @author Jesus Campos
 * Pruebas:  se puede visualizar en la p�gina GSP, al entrar en el controlador qu� direcci�n utiliza para cargar los css y js.
 */
class Test02Controller {

	def static allowedTypes = ['org.weceem.html.WcmHTMLContent', 'com.upc.WcmPlantillaFitxa', 'com.upc.WcmPlantillaFitxa2ColGenerica', 'com.upc.WcmPlantillaFitxaGenerica']
	def spaceId = 2711
	def spaceName = "PAS"
	
    def index_() { 
		println "index_"
//		redirect(action: 'index')
		redirect(action: 'tmpl')
	}

	def index(){
		println "index s"+new Date()
		params.desplegableSelected = "El-PAS-a-la-UPC"
	}
	
	def tmpl() {
		println "TMPL"+new Date()
		def template
		def webPage
		
		def values = request.forwardURI.toString().split("/")
		
		//Captura el aliasuri de la p�gina visitada.
		def page = values[values.size()-1]
		
		def query = {
			and{
				eq("space", spaceId)
				eq("aliasuri", "El-PAS-a-la-UPC")
				'in'("type", allowedTypes)
			}
		}
		
		//Carga de la p�gina Inici
		def pageContent = WcmContent.createCriteria().list(query)
		
		//Si la p�gina buscada no existe nos redirecciona al /IniciPDIPAS/PAS/index/, y esta p�gina s� existir�.
		if(!pageContent){
			query = {
				and{
					eq("space", spaceId)
					eq("aliasuri", "index")
					'in'("type", allowedTypes)
				}
			}
			
			//Carga de la p�gina Inici
			pageContent = WcmContent.createCriteria().list(query)
			
			//Ej: "/IniciPDIPAS/PAS/index/"
			values = "/${grails.util.Metadata.current.'app.name'}/${spaceName}/index/".split("/")
		}

		pageContent = pageContent[0]
		
//		//Weceem no deja guardar una p�gina, template, widget, etc sin contenido.
//		if(pageContent.tmpl)
//		{
//			template= pageContent.tmpl
//			//Carga del template
//			def pageTemplate = WcmContent.findByIdentityAndSpace(template, spaceId)
//			
//			//Poner el contenido de la p�gina donde toca
//			webPage = pageTemplate.content.replace("<wcm:content />", pageContent.content)
//		}
//		else{
//			
//		}
		
		webPage = pageContent.content
		
		//Para Grails 2.4.3
		/* *** */
		webPage = webPage.replace("/Portal/WeceemFiles/${spaceName}/", "/rrhh_resources/${spaceName}/")
		webPage = webPage.replace("/Portal/${spaceName}/images/", "/rrhh_resources/${spaceName}/images/")
		/* *** */
		
		webPage = webPage.replace("/Portal/${spaceName}/index", "/${grails.util.Metadata.current.'app.name'}/${spaceName}/index")
		webPage = webPage.replace("/Portal/${spaceName}/css", "/${grails.util.Metadata.current.'app.name'}/css")
		webPage = webPage.replace("/Portal/${spaceName}/js", "/${grails.util.Metadata.current.'app.name'}/js")
		//Las tres l�neas anteriores se solucionan con regexp si en el template se tiene ${wcm.Link ...
		
		webPage = webPage.replace("\${wcm.loggedInUserName().encodeAsHTML()}", "")
		
		webPage = webPage.replace("\${node.title.encodeAsHTML()}", pageContent.title)
   
		 //Redirecci�n de la p�gina
		 //${grails.util.Metadata.current.'app.name'}/${space?.name}/index/Informacio_General
		 webPage = webPage.replace("\${grails.util.Metadata.current.'app.name'}", "${grails.util.Metadata.current.'app.name'}") // => En el contenido de la p�gina NO se puede linkar con ${grails.util.Metadata.current.'app.name'}
		 webPage = webPage.replace("\${space?.name}", spaceName)
		   
		 //S�lo consulto las migas de pan si estoy en una ficha.
		 if(pageContent.type == "com.upc.WcmPlantillaFitxa" || pageContent.type == "com.upc.WcmPlantillaFitxaGenerica"){
			 webPage = webPage.replace("<!--breadCrumb-->", getBreadCrumb( values[3..(values.size()-1)], pageContent.title))
		 }
		   
		//Buscador
		if(webPage.contains("<!--buscadorUPC-->")){
			webPage = webPage.replace("<!--buscadorUPC-->", "<form action=\"/rrhh/searcher/index\" method=\"get\"><input type=\"hidden\" name=\"max\" value=\"5\"><input name=\"query\" class=\"customSearchField\" placeholder=\"Cercar...\" onfocus=\"\" value=\"\" id=\"query\" type=\"text\"><input name=\"_action_index\" class=\"customSearchButton\" value=\"Cerca\" type=\"submit\"></form>")
		}
		
		  
//		render(text: webPage, template: "plantilla", contentType: "text/html", encoding: "UTF-8")
		render(template: "plantilla", model: [datos:webPage], contentType: "text/html", encoding: "UTF-8")
	}
}
