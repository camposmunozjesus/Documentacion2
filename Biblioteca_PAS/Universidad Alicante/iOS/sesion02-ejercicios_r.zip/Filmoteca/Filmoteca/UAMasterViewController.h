//
//  UAMasterViewController.h
//  Filmoteca
//
//  Created by Miguel Angel Lozano on 15/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class UADetailViewController;
@class UAPelicula;

@interface UAMasterViewController : UITableViewController {
    UAPelicula *_pelicula;
}

@property (strong, nonatomic) UADetailViewController *detailViewController;

@end
