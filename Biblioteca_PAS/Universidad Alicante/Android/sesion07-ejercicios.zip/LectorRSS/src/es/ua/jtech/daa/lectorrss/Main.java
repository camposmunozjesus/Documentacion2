package es.ua.jtech.daa.lectorrss;

import java.net.URL;
import java.util.ArrayList;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class Main extends Activity {
    /** Called when the activity is first created. */
	TextView textViewTitulo;
	EditText editText;
	ArrayList<Noticia> noticias;
	NoticiasAdapter noticiasAdapter;
	ListView listView;
	ProgressDialog progressDialog;
	TareaDescarga tarea;
	Context context;
	Main main;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        context = getApplicationContext();
        main = this;
        
        noticias = new ArrayList<Noticia>();
        noticiasAdapter = new NoticiasAdapter(context, R.layout.fila, noticias);
        listView = (ListView)findViewById(R.id.ListView01);
        listView.setAdapter(noticiasAdapter);
        
        textViewTitulo = (TextView)findViewById(R.id.TextViewTitulo);
        editText = (EditText)findViewById(R.id.EditText01);
        editText.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(View v, int keyCode, KeyEvent event) {
		        if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)) {
		            // Perform action on key press
		        	accionDescargar();
		        	return true;
		          }
		          return false;
			}
		});
        ((Button)findViewById(R.id.Button01)).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				accionDescargar();
			}
		});

        
		
   }
   void accionDescargar(){
		tarea = new TareaDescarga();
		tarea.execute((URL[])null); //TODO pasar por parámetro la URL 
   }
   
   private class TareaDescarga extends AsyncTask<URL, String, String>{
	String direccion;
	boolean error=false;
	@Override
	protected String doInBackground(URL... params) {
			noticias = new ArrayList<Noticia>();
			
			//TODO La URL la tenemos en params[0]
			
			//TODO usar XmlPullParser para encontrar iterativamente:
			// <item> 
			//   y dentro de cada item recoger la información de 
			//   <title>
			//   <link>
			// y colocarlos en una Noticia noticia = new Noticia();

			//TODO si tenemos un XmlPullParser.END_TAG a la vez que
			// tag.equalsIgnoreCase("item")
			// entonces hemos terminado de rellenar la noticia y hacemos:
			// noticias.add(noticia);
								
			//TODO Capturar las excepciones de red y
		    //si ocurre alguno, poner la variable error=true;
		return "Carga finalizada";
	}
	
	

	@Override
	protected void onPreExecute() {
		super.onPreExecute();
		noticiasAdapter.clear();
		progressDialog = ProgressDialog.show(main, "Espere...", "Descargando noticias",true,true);
		progressDialog.setOnCancelListener(new OnCancelListener() {
			
			@Override
			public void onCancel(DialogInterface dialog) {
				tarea.cancel(true);
			}
		});
	}



	@Override
	protected void onCancelled() {
		super.onCancelled();
		textViewTitulo.setText("Descarga cancelada");
	}



	@Override
	protected void onProgressUpdate(String... values) {
		super.onProgressUpdate(values);
		textViewTitulo.setText(values[0]);
	}



	@Override
	protected void onPostExecute(String result) {
		super.onPostExecute(result);
		textViewTitulo.setText(direccion);
		for(Noticia n:noticias){
			noticiasAdapter.add(n);
		}
		noticiasAdapter.notifyDataSetChanged();
		progressDialog.dismiss();
		if(error){
			Toast.makeText(context, R.string.errordered, Toast.LENGTH_LONG).show();
			textViewTitulo.setText(R.string.errordered);
		}

	}
	   
   }
   
}