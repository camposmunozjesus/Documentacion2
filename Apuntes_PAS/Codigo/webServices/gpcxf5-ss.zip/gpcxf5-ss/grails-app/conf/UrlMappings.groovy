class UrlMappings {

    static excludes = ['/services*']
//    static excludes = ['/endpoints*']

	static mappings = {
		"/$controller/$action?/$id?"{
			constraints {
				// apply constraints here
			}
		}

		"/"(view:"/index")
		"500"(view:'/error')
	}
}
