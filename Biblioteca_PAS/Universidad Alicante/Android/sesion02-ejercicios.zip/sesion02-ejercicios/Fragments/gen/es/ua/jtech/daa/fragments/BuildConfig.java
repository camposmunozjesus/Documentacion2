/** Automatically generated file. DO NOT MODIFY */
package es.ua.jtech.daa.fragments;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}