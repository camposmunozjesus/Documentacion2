package es.ua.jtech.ajdm.multimedia;

import java.util.Locale;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.Engine;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class SintesisVoz extends Activity implements RadioGroup.OnCheckedChangeListener {
	private static int TTS_DATA_CHECK = 1;
    
    private TextToSpeech tts = null;
    private boolean ttsIsInit = false;
    
    private Button botonLeer;
    private EditText texto;
    private RadioGroup idioma;
    private Locale loc;
    private RadioButton en, es;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        texto = (EditText)findViewById(R.id.texto);
        botonLeer = (Button)findViewById(R.id.leer);
        botonLeer.setOnClickListener(new Button.OnClickListener() {
    		public void onClick(View v) {
    			inicializarTextToSpeech();
    		}
    	});
        idioma = (RadioGroup)findViewById(R.id.idioma);
        idioma.setOnCheckedChangeListener(this);
        loc = new Locale("es", "","");
        en = (RadioButton)findViewById(R.id.en);
        es = (RadioButton)findViewById(R.id.es);
    }
    
    private void inicializarTextToSpeech() {
    	Intent intent = new Intent(Engine.ACTION_CHECK_TTS_DATA);
    	startActivityForResult(intent, TTS_DATA_CHECK);
    }
    
    protected void onActivityResult(int requestCode,
    		int resultCode, Intent data) {
    		if (requestCode == TTS_DATA_CHECK) {
    				if (resultCode == Engine.CHECK_VOICE_DATA_PASS) {
    					tts = new TextToSpeech(this, new OnInitListener() {
    						public void onInit(int status) {
    							if (status == TextToSpeech.SUCCESS) {
    								ttsIsInit = true;
    								if(tts.isLanguageAvailable(loc) >= TextToSpeech.LANG_AVAILABLE)
    									tts.setLanguage(loc);
    								tts.setPitch(0.8f);
    								tts.setSpeechRate(1.1f);
    								hablar();
    							}
    						}
    				});
    		} else {
    			Intent installVoice = new Intent(Engine.ACTION_INSTALL_TTS_DATA);
    			startActivity(installVoice);
    		}
    	}
    }
    
    private void hablar() {
    	if (tts != null && ttsIsInit) {
    		tts.speak(texto.getText().toString(), TextToSpeech.QUEUE_ADD, null);
    	}
    }
    		
    @Override
    public void onDestroy() {
    		if (tts != null) {
    			tts.stop();
    			tts.shutdown();
    		}
    	super.onDestroy();
    }
    
    @Override
    public void onCheckedChanged(RadioGroup arg0, int checkedId) {
    	if (checkedId==en.getId())
    		loc = new Locale("en","","");
    	else
    		loc = new Locale("es","","");
    }
}