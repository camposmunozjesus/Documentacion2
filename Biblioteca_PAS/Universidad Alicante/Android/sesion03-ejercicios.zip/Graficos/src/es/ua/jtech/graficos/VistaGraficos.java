package es.ua.jtech.graficos;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class VistaGraficos extends SurfaceView implements SurfaceHolder.Callback {

	HiloDibujo hilo = null;
	 
    public VistaGraficos(Context context) {
        super(context);
        
        SurfaceHolder holder = this.getHolder();
        holder.addCallback(this);
    }

	public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        // La superficie ha cambiado (formato o dimensiones)
    }
 
    public void surfaceCreated(SurfaceHolder holder) {
        hilo = new HiloDibujo(holder, this);
        hilo.start();
    }
 
    public void surfaceDestroyed(SurfaceHolder holder) {

            hilo.detener();
            try {
                hilo.join();
            } catch (InterruptedException e) { }
    }

    class HiloDibujo extends Thread {
        SurfaceHolder holder;
        VistaGraficos vista;
        boolean continuar = true;
     
        public HiloDibujo(SurfaceHolder holder, VistaGraficos vista) {
            this.holder = holder;
            this.vista = vista;
            continuar = true;
        }
     
        public void detener() {
            continuar = false;
        }
     
        @Override
        public void run() {
            while (continuar) {
                Canvas c = null;
                try {
                    c = holder.lockCanvas(null);
                    synchronized (holder) {
                        // Dibujar aqui los graficos
                        c.drawColor(Color.BLUE);
                    }
                } finally {
                    if (c != null) {
                        holder.unlockCanvasAndPost(c);
                    }
                }
            }
        }
    }
}


