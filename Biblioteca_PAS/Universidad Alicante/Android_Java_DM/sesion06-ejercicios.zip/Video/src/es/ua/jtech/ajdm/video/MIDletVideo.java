package es.ua.jtech.ajdm.video;

import javax.microedition.lcdui.*;
import javax.microedition.midlet.*; 

public class MIDletVideo extends MIDlet {

	protected void startApp() throws MIDletStateChangeException {
		Display d = Display.getDisplay(this);
		VisorVideo vv = new VisorVideo();
		d.setCurrent(vv);
	}

	protected void pauseApp() {

	}

	protected void destroyApp(boolean arg0) throws MIDletStateChangeException {

	}

}
