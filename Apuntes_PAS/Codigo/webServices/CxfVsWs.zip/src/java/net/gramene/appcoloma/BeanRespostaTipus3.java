
package net.gramene.appcoloma;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BeanRespostaTipus3 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BeanRespostaTipus3">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codiEstat" type="{http://www.gramene.net/appcoloma/}CodiEstat" minOccurs="0"/>
 *         &lt;element name="tipCatAgenda" type="{http://www.gramene.net/appcoloma/}ArrayOfTipCatAgenda" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BeanRespostaTipus3", propOrder = {
    "codiEstat",
    "tipCatAgenda"
})
public class BeanRespostaTipus3 {

    protected CodiEstat codiEstat;
    protected ArrayOfTipCatAgenda tipCatAgenda;

    /**
     * Gets the value of the codiEstat property.
     * 
     * @return
     *     possible object is
     *     {@link CodiEstat }
     *     
     */
    public CodiEstat getCodiEstat() {
        return codiEstat;
    }

    /**
     * Sets the value of the codiEstat property.
     * 
     * @param value
     *     allowed object is
     *     {@link CodiEstat }
     *     
     */
    public void setCodiEstat(CodiEstat value) {
        this.codiEstat = value;
    }

    /**
     * Gets the value of the tipCatAgenda property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfTipCatAgenda }
     *     
     */
    public ArrayOfTipCatAgenda getTipCatAgenda() {
        return tipCatAgenda;
    }

    /**
     * Sets the value of the tipCatAgenda property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfTipCatAgenda }
     *     
     */
    public void setTipCatAgenda(ArrayOfTipCatAgenda value) {
        this.tipCatAgenda = value;
    }

}
