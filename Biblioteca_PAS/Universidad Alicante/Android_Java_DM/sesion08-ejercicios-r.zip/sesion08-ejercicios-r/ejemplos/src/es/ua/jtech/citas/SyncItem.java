package es.ua.jtech.citas;

public class SyncItem {

	Cita [] citas;
	long ts;
	
	public SyncItem(long ts, Cita [] citas) {
		this.ts = ts;
		this.citas = citas;
	}
	
	public Cita[] getCitas() {
		return citas;
	}
	public void setCitas(Cita[] citas) {
		this.citas = citas;
	}
	public long getTs() {
		return ts;
	}
	public void setTs(long ts) {
		this.ts = ts;
	}
}
