package es.ua.jtech.daa;

import android.app.Activity;
import android.content.Context;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Audio extends Activity {
	private Button butPlay, butPause, butStop;
	private MediaPlayer mp;
	boolean paused = false;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        inicializarMediaPlayer();
        initialize();
    }
    
    // Inicializa el MediaPlayer especificando la fuente de datos
    private void inicializarMediaPlayer() {
    	Context appContext = getApplicationContext();
    	mp = MediaPlayer.create(appContext, R.raw.sad_robot);
    }
    
    // Inicializa los botones de la aplicación
    private void initialize() {
    	butPlay = (Button)findViewById(R.id.playbutton);
    	butPause = (Button)findViewById(R.id.pausebutton);
    	butStop = (Button)findViewById(R.id.stopbutton);
    	
    	butPause.setEnabled(false);
    	butStop.setEnabled(false);
    	
    	
    	butPlay.setOnClickListener(playListener);
    	butPause.setOnClickListener(pauseListener);
    	butStop.setOnClickListener(stopListener);
    	
    	mp.setOnCompletionListener(terminarListener);
    }
    
    private OnClickListener playListener = new OnClickListener() {
		public void onClick(View v) {
			mp.seekTo(0);
			mp.start();
	
			butPlay.setEnabled(false);
			butPause.setEnabled(true);
			butStop.setEnabled(true);
		}
    };
    
    private OnClickListener pauseListener = new OnClickListener() {
		public void onClick(View v) {
			if (!paused) {
				mp.pause();
				
				butPause.setText(R.string.resumebutton);
				
				paused = true;
			} else {
				mp.start();
				
				butPause.setText(R.string.pausebutton);
				
				paused = false;
			}
		}
    };
    
    private OnCompletionListener terminarListener = new OnCompletionListener() {
		public void onCompletion(MediaPlayer mp) {
			mp.pause();
			
			butPlay.setEnabled(true);
			butPause.setEnabled(false);
			butStop.setEnabled(false);
		}	
    };
    
    private OnClickListener stopListener = new OnClickListener() {
		public void onClick(View v) {
			mp.pause();
			
			butPlay.setEnabled(true);
			butPause.setEnabled(false);
			butStop.setEnabled(false);
		}
    };
}