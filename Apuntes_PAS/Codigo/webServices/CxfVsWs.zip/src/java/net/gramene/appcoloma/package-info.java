@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.gramene.net/appcoloma/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package net.gramene.appcoloma;
