package inicipdipas

class Test01Controller {

    def index() {
		println "HOLA01!"+new Date()
	}
}
