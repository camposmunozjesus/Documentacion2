package gpcxf5

import org.grails.cxf.utils.EndpointType

import javax.activation.DataHandler
import javax.jws.WebMethod
import javax.jws.WebParam
import javax.jws.WebResult
import javax.jws.WebService
import javax.xml.bind.annotation.XmlMimeType
import javax.xml.ws.soap.MTOM


@MTOM(enabled = true)
@WebService
class WorkingEndpoint {
    static expose = EndpointType.JAX_WS
    static soap12 = true

    def md5Service

    @WebResult(name = 'md5')
    @WebMethod
    String md5Calculator(@WebParam(name = "input") String input) {
        return md5Service.calc(new ByteArrayInputStream(input.bytes))
    }

    @WebResult(name = 'md5')
    @WebMethod
    public String md5FileCalculator(@WebParam(name = "input") @XmlMimeType("application/octet-stream") DataHandler fileData) {
        final inputStream = fileData.inputStream
        return md5Service.calc(inputStream)
    }
}
