//
//  UATareaViewController.h
//  TareasStoryboard
//
//  Created by Miguel Angel Lozano on 08/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class UATareaViewController;

@protocol UATareaViewControllerDelegate <NSObject>

- (void)tareaViewController:(UATareaViewController *)controller didChangeTarea:(NSString *)tarea atIndexPath:(NSIndexPath *)indexPath;

@end

@interface UATareaViewController : UITableViewController<UITextFieldDelegate>

@property (nonatomic, strong) NSString *tarea;
@property (nonatomic, strong) NSIndexPath *indexPath;

@property (nonatomic, unsafe_unretained) id<UATareaViewControllerDelegate> delegate;

@property (nonatomic, strong) IBOutlet UITextField *textFieldTarea;

- (IBAction)guardarTarea:(id)sender;

@end
