
package net.gramene.appcoloma;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CodiEstat complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CodiEstat">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="intCodiEstat" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="strDescripcioEstat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="intTotalResultats" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CodiEstat", propOrder = {
    "intCodiEstat",
    "strDescripcioEstat",
    "intTotalResultats"
})
public class CodiEstat {

    protected short intCodiEstat;
    protected String strDescripcioEstat;
    protected long intTotalResultats;

    /**
     * Gets the value of the intCodiEstat property.
     * 
     */
    public short getIntCodiEstat() {
        return intCodiEstat;
    }

    /**
     * Sets the value of the intCodiEstat property.
     * 
     */
    public void setIntCodiEstat(short value) {
        this.intCodiEstat = value;
    }

    /**
     * Gets the value of the strDescripcioEstat property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrDescripcioEstat() {
        return strDescripcioEstat;
    }

    /**
     * Sets the value of the strDescripcioEstat property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrDescripcioEstat(String value) {
        this.strDescripcioEstat = value;
    }

    /**
     * Gets the value of the intTotalResultats property.
     * 
     */
    public long getIntTotalResultats() {
        return intTotalResultats;
    }

    /**
     * Sets the value of the intTotalResultats property.
     * 
     */
    public void setIntTotalResultats(long value) {
        this.intTotalResultats = value;
    }

}
