package es.ua.jtech.daa.holamundo;

import es.ua.jtech.ajdm.holamundo.R;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class Main extends Activity {
    /** Called when the activity is first created. */
	TextView textView;
	Button   button;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        textView = (TextView)findViewById(R.id.TextView01);
        button = (Button)findViewById(R.id.Button01);

        button.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				textView.append(getString(R.string.mundo));
			}
			
		});
    }
    
}