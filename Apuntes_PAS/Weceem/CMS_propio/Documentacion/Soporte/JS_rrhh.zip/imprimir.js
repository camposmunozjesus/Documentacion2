//var url="http://www.webrecursos.com" 
//var titulo="jesus WebRecursos.com - Recursos gratis para webmasters"
//function imprimir(){
//	alert("1");
//	if (document.all){
//		//IE
//		window.external.AddFavorite(url,titulo)
//		alert("3")
//	}
////	else if (window.sidebar) { // Mozilla Firefox
////		window.external.AddFavorite("jesus", "http://asd", ""); 
////		alert("3");
////	} 
//}

$(document).ready(function(){
	$("#jQueryBookmark").click(function(e){
			alert()
	        e.preventDefault(); 
	        var bookmarkUrl = "http://www.upc.com";
	        var bookmarkTitle = "UPC";
	 
	        if (window.sidebar) { // For Mozilla Firefox Bookmark
	        	alert("1")
	                window.sidebar.addPanel(bookmarkTitle, bookmarkUrl,"");
	        } else if( window.external || document.all) { // For IE Favorite
	        	alert("2")
	                window.external.AddFavorite( bookmarkUrl, bookmarkTitle);
	        } else if(window.opera) { // For Opera Browsers
	        	alert("3")
	                $("a.jQueryBookmark").attr("href",bookmarkUrl);
	                $("a.jQueryBookmark").attr("title",bookmarkTitle);
	                $("a.jQueryBookmark").attr("rel","sidebar");
	        } else { // for other browsers which does not support
	                 alert('Your browser does not support this bookmark action');
	                 return false;
	        }
	});
});



function imprimir(){
	$('.row-contingut').addClass('col-lg-12');
	$('.row-contingut').removeClass('col-xs-12 col-vxs-8 col-sm-8 col-md-8 col-lg-9');
	window.print();
	$('.row-contingut').addClass('col-xs-12 col-vxs-8 col-sm-8 col-md-8 col-lg-9');
}