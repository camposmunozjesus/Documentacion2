//
//  UAViewController.h
//  PeliculaEnPopover
//
//  Created by Javier Aznar on 04/12/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UAViewController : UIViewController

@end
