/*
 * Created on 13-sep-2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package es.ua.jtech.mensajes;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ServletEnviaMensaje extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		ServletContext sc = this.getServletContext();
		ListaMensajes lista = (ListaMensajes)sc.getAttribute("mensajes");

		// Lee informacion del cliente

		String asunto = req.getParameter("asunto");
		String texto = req.getParameter("texto");
		
		// Crea mensaje
		
		Mensaje msg = new Mensaje();
		msg.setAsunto(asunto);
		msg.setTexto(texto);
		
		lista.addMensaje(msg);
		
		// Vuelve al menu
		
		res.sendRedirect(req.getContextPath() + "/mensajes/index.htm");		
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		doGet(req,res);
	}

}
