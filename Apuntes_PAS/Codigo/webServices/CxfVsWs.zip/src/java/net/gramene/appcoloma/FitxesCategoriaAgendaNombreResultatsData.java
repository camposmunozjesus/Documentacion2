
package net.gramene.appcoloma;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idioma" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="idCategoriaAgenda" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="data" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "idioma",
    "idCategoriaAgenda",
    "data"
})
@XmlRootElement(name = "fitxesCategoriaAgendaNombreResultatsData")
public class FitxesCategoriaAgendaNombreResultatsData {

    protected int idioma;
    protected int idCategoriaAgenda;
    protected String data;

    /**
     * Gets the value of the idioma property.
     * 
     */
    public int getIdioma() {
        return idioma;
    }

    /**
     * Sets the value of the idioma property.
     * 
     */
    public void setIdioma(int value) {
        this.idioma = value;
    }

    /**
     * Gets the value of the idCategoriaAgenda property.
     * 
     */
    public int getIdCategoriaAgenda() {
        return idCategoriaAgenda;
    }

    /**
     * Sets the value of the idCategoriaAgenda property.
     * 
     */
    public void setIdCategoriaAgenda(int value) {
        this.idCategoriaAgenda = value;
    }

    /**
     * Gets the value of the data property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getData() {
        return data;
    }

    /**
     * Sets the value of the data property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setData(String value) {
        this.data = value;
    }

}
