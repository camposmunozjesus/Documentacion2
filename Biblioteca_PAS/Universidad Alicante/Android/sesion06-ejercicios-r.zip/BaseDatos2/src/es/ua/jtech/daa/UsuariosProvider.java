package es.ua.jtech.daa;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.util.Log;

public class UsuariosProvider extends ContentProvider{
	public static final Uri CONTENT_URI = Uri.parse("content://es.ua.jtech.daa/usuarios");
	private static final int ALLROWS = 1;
	private static final int SINGLE_ROW = 2;
	private static final UriMatcher uriMatcher;
	static {
		uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
		uriMatcher.addURI("es.ua.jtech.daa","usuarios",ALLROWS);
		uriMatcher.addURI("es.ua.jtech.daa", "usuarios/#", SINGLE_ROW);
	}
	
	private static final String DATABASE_NAME = "misusuarios.db";
	private static final int DATABASE_VERSION = 2;
	private static final String TABLE_NAME = "usuarios";
	private static final String[] COLUMNAS = {"_id","nombres"};
	private static final String CREATE_DB = "CREATE TABLE " + TABLE_NAME + 
	 "("+COLUMNAS[0]+" INTEGER PRIMARY KEY, "+COLUMNAS[1]+" TEXT)";
	   
	private Context context;
	private SQLiteDatabase db;
	
	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getType(Uri uri) {
		switch(uriMatcher.match(uri)) {
		case ALLROWS: return "vnd.ua.cursor.dir/usuariosprovidercontent";
		case SINGLE_ROW: return "vnd.ua.cursor.item/usuariosprovidercontent";
		default: throw new IllegalArgumentException("URI no soportada: " + uri);
		}
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean onCreate() {
		this.context = getContext();
	    MiOpenHelper openHelper = new MiOpenHelper(this.context);
	    db= openHelper.getWritableDatabase();
	    return true;
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {
		return db.query(TABLE_NAME, COLUMNAS, selection, selectionArgs, null, null, null);
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		// TODO Auto-generated method stub
		return 0;
	}

	private static class MiOpenHelper extends SQLiteOpenHelper {

	      MiOpenHelper(Context context) {
	         super(context, DATABASE_NAME, null, DATABASE_VERSION);
	      }

	      @Override
	      public void onCreate(SQLiteDatabase db) {
	    	 db.execSQL(CREATE_DB);
	      }

	      @Override
	      public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
	         Log.w("SQL", "onUpgrade: eliminando tabla si ésta existe, y creándola de nuevo");
	         db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
	         onCreate(db);
	      }
	   }
}
