
package net.gramene.appcoloma;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for FitxaHorari complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FitxaHorari">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="intIdFitxa" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="intOrdre" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="intDiaDesde" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="intDiaHasta" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="intMesDesde" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="intMesHasta" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="bytdl" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="bytdt" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="bytdc" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="bytdj" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="bytdv" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="bytds" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="bytdg" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="intFinsDia" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="dtmHoraInici" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="dtmHoraFi" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="strDescripcio" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FitxaHorari", propOrder = {
    "intIdFitxa",
    "intOrdre",
    "intDiaDesde",
    "intDiaHasta",
    "intMesDesde",
    "intMesHasta",
    "bytdl",
    "bytdt",
    "bytdc",
    "bytdj",
    "bytdv",
    "bytds",
    "bytdg",
    "intFinsDia",
    "dtmHoraInici",
    "dtmHoraFi",
    "strDescripcio"
})
public class FitxaHorari {

    protected long intIdFitxa;
    protected short intOrdre;
    protected short intDiaDesde;
    protected short intDiaHasta;
    protected short intMesDesde;
    protected short intMesHasta;
    protected boolean bytdl;
    protected boolean bytdt;
    protected boolean bytdc;
    protected boolean bytdj;
    protected boolean bytdv;
    protected boolean bytds;
    protected boolean bytdg;
    protected short intFinsDia;
    @XmlElement(required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dtmHoraInici;
    @XmlElement(required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dtmHoraFi;
    protected String strDescripcio;

    /**
     * Gets the value of the intIdFitxa property.
     * 
     */
    public long getIntIdFitxa() {
        return intIdFitxa;
    }

    /**
     * Sets the value of the intIdFitxa property.
     * 
     */
    public void setIntIdFitxa(long value) {
        this.intIdFitxa = value;
    }

    /**
     * Gets the value of the intOrdre property.
     * 
     */
    public short getIntOrdre() {
        return intOrdre;
    }

    /**
     * Sets the value of the intOrdre property.
     * 
     */
    public void setIntOrdre(short value) {
        this.intOrdre = value;
    }

    /**
     * Gets the value of the intDiaDesde property.
     * 
     */
    public short getIntDiaDesde() {
        return intDiaDesde;
    }

    /**
     * Sets the value of the intDiaDesde property.
     * 
     */
    public void setIntDiaDesde(short value) {
        this.intDiaDesde = value;
    }

    /**
     * Gets the value of the intDiaHasta property.
     * 
     */
    public short getIntDiaHasta() {
        return intDiaHasta;
    }

    /**
     * Sets the value of the intDiaHasta property.
     * 
     */
    public void setIntDiaHasta(short value) {
        this.intDiaHasta = value;
    }

    /**
     * Gets the value of the intMesDesde property.
     * 
     */
    public short getIntMesDesde() {
        return intMesDesde;
    }

    /**
     * Sets the value of the intMesDesde property.
     * 
     */
    public void setIntMesDesde(short value) {
        this.intMesDesde = value;
    }

    /**
     * Gets the value of the intMesHasta property.
     * 
     */
    public short getIntMesHasta() {
        return intMesHasta;
    }

    /**
     * Sets the value of the intMesHasta property.
     * 
     */
    public void setIntMesHasta(short value) {
        this.intMesHasta = value;
    }

    /**
     * Gets the value of the bytdl property.
     * 
     */
    public boolean isBytdl() {
        return bytdl;
    }

    /**
     * Sets the value of the bytdl property.
     * 
     */
    public void setBytdl(boolean value) {
        this.bytdl = value;
    }

    /**
     * Gets the value of the bytdt property.
     * 
     */
    public boolean isBytdt() {
        return bytdt;
    }

    /**
     * Sets the value of the bytdt property.
     * 
     */
    public void setBytdt(boolean value) {
        this.bytdt = value;
    }

    /**
     * Gets the value of the bytdc property.
     * 
     */
    public boolean isBytdc() {
        return bytdc;
    }

    /**
     * Sets the value of the bytdc property.
     * 
     */
    public void setBytdc(boolean value) {
        this.bytdc = value;
    }

    /**
     * Gets the value of the bytdj property.
     * 
     */
    public boolean isBytdj() {
        return bytdj;
    }

    /**
     * Sets the value of the bytdj property.
     * 
     */
    public void setBytdj(boolean value) {
        this.bytdj = value;
    }

    /**
     * Gets the value of the bytdv property.
     * 
     */
    public boolean isBytdv() {
        return bytdv;
    }

    /**
     * Sets the value of the bytdv property.
     * 
     */
    public void setBytdv(boolean value) {
        this.bytdv = value;
    }

    /**
     * Gets the value of the bytds property.
     * 
     */
    public boolean isBytds() {
        return bytds;
    }

    /**
     * Sets the value of the bytds property.
     * 
     */
    public void setBytds(boolean value) {
        this.bytds = value;
    }

    /**
     * Gets the value of the bytdg property.
     * 
     */
    public boolean isBytdg() {
        return bytdg;
    }

    /**
     * Sets the value of the bytdg property.
     * 
     */
    public void setBytdg(boolean value) {
        this.bytdg = value;
    }

    /**
     * Gets the value of the intFinsDia property.
     * 
     */
    public short getIntFinsDia() {
        return intFinsDia;
    }

    /**
     * Sets the value of the intFinsDia property.
     * 
     */
    public void setIntFinsDia(short value) {
        this.intFinsDia = value;
    }

    /**
     * Gets the value of the dtmHoraInici property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDtmHoraInici() {
        return dtmHoraInici;
    }

    /**
     * Sets the value of the dtmHoraInici property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDtmHoraInici(XMLGregorianCalendar value) {
        this.dtmHoraInici = value;
    }

    /**
     * Gets the value of the dtmHoraFi property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDtmHoraFi() {
        return dtmHoraFi;
    }

    /**
     * Sets the value of the dtmHoraFi property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDtmHoraFi(XMLGregorianCalendar value) {
        this.dtmHoraFi = value;
    }

    /**
     * Gets the value of the strDescripcio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrDescripcio() {
        return strDescripcio;
    }

    /**
     * Sets the value of the strDescripcio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrDescripcio(String value) {
        this.strDescripcio = value;
    }

}
