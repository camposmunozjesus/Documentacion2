//
//  UAAppDelegate.h
//  Filmoteca
//
//  Created by Miguel Angel Lozano on 15/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class UAMasterViewController;

@interface UAAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) IBOutlet UITabBarController *tabBarController;
@property (strong, nonatomic) UAMasterViewController *masterViewController;

@end
