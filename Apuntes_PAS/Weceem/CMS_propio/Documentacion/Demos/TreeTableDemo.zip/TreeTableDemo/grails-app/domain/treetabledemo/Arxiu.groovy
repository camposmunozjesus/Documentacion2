package treetabledemo

class Arxiu {

	String nom
	String usuariCreacio
	String usuariModificacio
	
    static constraints = {
    }
}
