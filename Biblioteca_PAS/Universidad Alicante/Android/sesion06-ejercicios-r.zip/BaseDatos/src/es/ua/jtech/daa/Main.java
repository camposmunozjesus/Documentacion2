package es.ua.jtech.daa;

import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class Main extends Activity {
	/** Called when the activity is first created. */
	private TextView textView;
	private DataHelper dataHelper;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		this.textView = (TextView) this.findViewById(R.id.TextView01);

		this.dataHelper = new DataHelper(this);
		
		dataHelper.deleteAll();
		dataHelper.insert("Pablo");
		dataHelper.insert("Boyan");
		dataHelper.insert("Miguel Angel");
		List<String> listado = dataHelper.selectAll();
		for (int i=0;i<listado.size();i++) {
			textView.append(listado.get(i) + "\n");
		}
	}    
    
}