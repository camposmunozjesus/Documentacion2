
package net.gramene.appcoloma;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="agendaPaginadaDataResult" type="{http://www.gramene.net/appcoloma/}BeanRespostaTipus7" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "agendaPaginadaDataResult"
})
@XmlRootElement(name = "agendaPaginadaDataResponse")
public class AgendaPaginadaDataResponse {

    protected BeanRespostaTipus7 agendaPaginadaDataResult;

    /**
     * Gets the value of the agendaPaginadaDataResult property.
     * 
     * @return
     *     possible object is
     *     {@link BeanRespostaTipus7 }
     *     
     */
    public BeanRespostaTipus7 getAgendaPaginadaDataResult() {
        return agendaPaginadaDataResult;
    }

    /**
     * Sets the value of the agendaPaginadaDataResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link BeanRespostaTipus7 }
     *     
     */
    public void setAgendaPaginadaDataResult(BeanRespostaTipus7 value) {
        this.agendaPaginadaDataResult = value;
    }

}
