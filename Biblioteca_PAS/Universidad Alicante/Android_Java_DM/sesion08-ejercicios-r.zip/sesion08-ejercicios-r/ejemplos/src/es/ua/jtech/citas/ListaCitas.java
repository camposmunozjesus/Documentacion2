/*
 * Created on 13-sep-2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package es.ua.jtech.citas;

import java.util.*;
import java.io.*;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ListaCitas extends ArrayList {

	long ts;

	public ListaCitas() {
		this.ts = 0;
	}
	
	public synchronized void addCita(Cita cita) {
		cita.setTs(ts++);
		this.add(cita);
	}
	
	public synchronized Cita [] getCitas() {
		int tam = this.size();
		Cita [] citas = new Cita[tam];
		this.toArray(citas);
		
		return citas;
	}
	
	public synchronized Cita [] getCitas(long tsCliente) {
		ArrayList nuevasCitas = new ArrayList();
		
		Iterator iter = this.iterator();
		while(iter.hasNext()) {
			Cita cita = (Cita)iter.next();
			if(cita.ts >= tsCliente) {
				nuevasCitas.add(cita);
			}
		}

		int tam = nuevasCitas.size();
		Cita [] citas = new Cita[tam];
		nuevasCitas.toArray(citas);
		
		return citas;
	}
	
	public synchronized long getTimeStamp() {
		return ts;
	}
	
	public synchronized SyncItem sincroniza(SyncItem datosCliente) throws IOException {
		long tsCliente = datosCliente.getTs();
		Cita [] citasCliente = datosCliente.getCitas();
		
		Cita [] citasServidor = this.getCitas(tsCliente);
		
		for(int i=0;i<citasCliente.length;i++) {
			this.addCita(citasCliente[i]);
		}
		
		long tsServidor = getTimeStamp();
		
		SyncItem datosServidor = new SyncItem(tsServidor, citasServidor);
		
		return datosServidor;
	}
}
