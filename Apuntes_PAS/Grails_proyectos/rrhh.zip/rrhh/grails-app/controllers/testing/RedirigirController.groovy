package testing

class RedirigirController {

    def index() {
		println "index redirigir"+new Date()
	}
	
	def index2(){
		println "2index2 redirigir"+new Date()
	}
}
