
package gpcxf5;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the gpcxf5 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetMd5Service_QNAME = new QName("http://gpcxf5/", "getMd5Service");
    private final static QName _Md5FileCalculatorResponse_QNAME = new QName("http://gpcxf5/", "md5FileCalculatorResponse");
    private final static QName _SetMd5Service_QNAME = new QName("http://gpcxf5/", "setMd5Service");
    private final static QName _Md5Calculator_QNAME = new QName("http://gpcxf5/", "md5Calculator");
    private final static QName _Md5CalculatorResponse_QNAME = new QName("http://gpcxf5/", "md5CalculatorResponse");
    private final static QName _Md5FileCalculator_QNAME = new QName("http://gpcxf5/", "md5FileCalculator");
    private final static QName _SetMd5ServiceResponse_QNAME = new QName("http://gpcxf5/", "setMd5ServiceResponse");
    private final static QName _GetMd5ServiceResponse_QNAME = new QName("http://gpcxf5/", "getMd5ServiceResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: gpcxf5
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetMd5ServiceResponse }
     * 
     */
    public GetMd5ServiceResponse createGetMd5ServiceResponse() {
        return new GetMd5ServiceResponse();
    }

    /**
     * Create an instance of {@link SetMd5Service }
     * 
     */
    public SetMd5Service createSetMd5Service() {
        return new SetMd5Service();
    }

    /**
     * Create an instance of {@link Md5FileCalculator }
     * 
     */
    public Md5FileCalculator createMd5FileCalculator() {
        return new Md5FileCalculator();
    }

    /**
     * Create an instance of {@link Md5CalculatorResponse }
     * 
     */
    public Md5CalculatorResponse createMd5CalculatorResponse() {
        return new Md5CalculatorResponse();
    }

    /**
     * Create an instance of {@link Md5Calculator }
     * 
     */
    public Md5Calculator createMd5Calculator() {
        return new Md5Calculator();
    }

    /**
     * Create an instance of {@link SetMd5ServiceResponse }
     * 
     */
    public SetMd5ServiceResponse createSetMd5ServiceResponse() {
        return new SetMd5ServiceResponse();
    }

    /**
     * Create an instance of {@link Md5FileCalculatorResponse }
     * 
     */
    public Md5FileCalculatorResponse createMd5FileCalculatorResponse() {
        return new Md5FileCalculatorResponse();
    }

    /**
     * Create an instance of {@link GetMd5Service }
     * 
     */
    public GetMd5Service createGetMd5Service() {
        return new GetMd5Service();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetMd5Service }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://gpcxf5/", name = "getMd5Service")
    public JAXBElement<GetMd5Service> createGetMd5Service(GetMd5Service value) {
        return new JAXBElement<GetMd5Service>(_GetMd5Service_QNAME, GetMd5Service.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Md5FileCalculatorResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://gpcxf5/", name = "md5FileCalculatorResponse")
    public JAXBElement<Md5FileCalculatorResponse> createMd5FileCalculatorResponse(Md5FileCalculatorResponse value) {
        return new JAXBElement<Md5FileCalculatorResponse>(_Md5FileCalculatorResponse_QNAME, Md5FileCalculatorResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetMd5Service }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://gpcxf5/", name = "setMd5Service")
    public JAXBElement<SetMd5Service> createSetMd5Service(SetMd5Service value) {
        return new JAXBElement<SetMd5Service>(_SetMd5Service_QNAME, SetMd5Service.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Md5Calculator }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://gpcxf5/", name = "md5Calculator")
    public JAXBElement<Md5Calculator> createMd5Calculator(Md5Calculator value) {
        return new JAXBElement<Md5Calculator>(_Md5Calculator_QNAME, Md5Calculator.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Md5CalculatorResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://gpcxf5/", name = "md5CalculatorResponse")
    public JAXBElement<Md5CalculatorResponse> createMd5CalculatorResponse(Md5CalculatorResponse value) {
        return new JAXBElement<Md5CalculatorResponse>(_Md5CalculatorResponse_QNAME, Md5CalculatorResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Md5FileCalculator }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://gpcxf5/", name = "md5FileCalculator")
    public JAXBElement<Md5FileCalculator> createMd5FileCalculator(Md5FileCalculator value) {
        return new JAXBElement<Md5FileCalculator>(_Md5FileCalculator_QNAME, Md5FileCalculator.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetMd5ServiceResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://gpcxf5/", name = "setMd5ServiceResponse")
    public JAXBElement<SetMd5ServiceResponse> createSetMd5ServiceResponse(SetMd5ServiceResponse value) {
        return new JAXBElement<SetMd5ServiceResponse>(_SetMd5ServiceResponse_QNAME, SetMd5ServiceResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetMd5ServiceResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://gpcxf5/", name = "getMd5ServiceResponse")
    public JAXBElement<GetMd5ServiceResponse> createGetMd5ServiceResponse(GetMd5ServiceResponse value) {
        return new JAXBElement<GetMd5ServiceResponse>(_GetMd5ServiceResponse_QNAME, GetMd5ServiceResponse.class, null, value);
    }

}
