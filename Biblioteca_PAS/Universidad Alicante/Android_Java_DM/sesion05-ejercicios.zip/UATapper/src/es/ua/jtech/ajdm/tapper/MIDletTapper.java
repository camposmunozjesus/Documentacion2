/*
 * MIDletTapper.java
 * Copyright (C) 2009 Miguel Angel Lozano, Boyan Bonev
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package es.ua.jtech.ajdm.tapper;

import java.io.IOException;

import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

import es.ua.jtech.ajdm.tapper.data.Resources;
import es.ua.jtech.ajdm.tapper.engine.GameEngine;
import es.ua.jtech.ajdm.tapper.engine.GameScene;
import es.ua.jtech.ajdm.tapper.engine.SplashScreen;
import es.ua.jtech.ajdm.tapper.engine.TitleScene;

/**
 * @author Miguel Angel
 */
public class MIDletTapper extends MIDlet {

	private void loadGame() {

		Display d = Display.getDisplay(this);

		
		// Muesta splash screen mientras carga recursos
		try {
			Resources.initSplash(this);

			SplashScreen ss = new SplashScreen();
			d.setCurrent(ss);
			
			Thread t = new Thread(ss);
			t.start();

		} catch(IOException e) {
			showError("Error al cargar recursos");
		}
		
	}
	
	public void showError(String msg) {
		Display d = Display.getDisplay(this);
		Form error = new Form(msg);
		d.setCurrent(error);		
	}
	
	public void showTitle() {

		Display d = Display.getDisplay(this);
		if(d.getCurrent() instanceof GameEngine) {
			GameEngine engine = (GameEngine)d.getCurrent();
			engine.setScene(new TitleScene());			
		} else {			
			GameEngine engine = new GameEngine(new TitleScene()); 
			d.setCurrent(engine); 			
		}

	}
	
	public void startGame() {
		Display d = Display.getDisplay(this);
		if(d.getCurrent() instanceof GameEngine) {
			GameEngine engine = (GameEngine)d.getCurrent();
			engine.setScene(new GameScene());
		} else {			
			GameEngine engine = new GameEngine(new GameScene()); 
			d.setCurrent(engine); 			
		}

	}
	
	public void exitGame() {
		try {
			this.destroyApp(true);
		} catch(MIDletStateChangeException e) {
		}

		this.notifyDestroyed();
	}

	protected void startApp() throws MIDletStateChangeException {

		Display d = Display.getDisplay(this);
		Displayable current = d.getCurrent();

		if(current == null) {
			this.loadGame();
		} else {
			// Reanudar
			Displayable prev = d.getCurrent();
			if(prev instanceof GameEngine) {
				GameEngine pe = (GameEngine)prev;
				pe.start();
			}
		}
	}

	protected void pauseApp() {

		Display d = Display.getDisplay(this);
		Displayable current = d.getCurrent();
		if(current instanceof GameEngine) {
			GameEngine pe = (GameEngine)current;
			pe.stop();
		}
		
	}

	protected void destroyApp(boolean cond) throws MIDletStateChangeException {

		Display d = Display.getDisplay(this);
		Displayable current = d.getCurrent();
		if(current instanceof GameEngine) {
			GameEngine pe = (GameEngine)current;
			pe.stop();
		}

	}

}

