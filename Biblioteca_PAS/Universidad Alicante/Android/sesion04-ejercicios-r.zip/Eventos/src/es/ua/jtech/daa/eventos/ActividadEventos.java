package es.ua.jtech.daa.eventos;

import android.app.Activity;
import android.os.Bundle;

public class ActividadEventos extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(new VistaEventos(this));
    }
}