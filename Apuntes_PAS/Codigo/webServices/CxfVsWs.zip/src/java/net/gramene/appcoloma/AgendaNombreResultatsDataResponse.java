
package net.gramene.appcoloma;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="agendaNombreResultatsDataResult" type="{http://www.gramene.net/appcoloma/}CodiEstat" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "agendaNombreResultatsDataResult"
})
@XmlRootElement(name = "agendaNombreResultatsDataResponse")
public class AgendaNombreResultatsDataResponse {

    protected CodiEstat agendaNombreResultatsDataResult;

    /**
     * Gets the value of the agendaNombreResultatsDataResult property.
     * 
     * @return
     *     possible object is
     *     {@link CodiEstat }
     *     
     */
    public CodiEstat getAgendaNombreResultatsDataResult() {
        return agendaNombreResultatsDataResult;
    }

    /**
     * Sets the value of the agendaNombreResultatsDataResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link CodiEstat }
     *     
     */
    public void setAgendaNombreResultatsDataResult(CodiEstat value) {
        this.agendaNombreResultatsDataResult = value;
    }

}
