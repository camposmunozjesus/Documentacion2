package es.ua.jtech.ajdm.rms.notas;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class VerNota extends Form implements CommandListener {

	Command cmdAtras;

	TextField txtNombre;
	TextField txtTexto;

	MIDlet owner;
	Displayable previo;

	public VerNota(MIDlet owner, Displayable previo, Mensaje nota) {
		super(nota.asunto);
		this.owner = owner;
		this.previo = previo;

		// Añade texto de la nota
		this.append(nota.texto);
		
		// Añade comandos
		cmdAtras = new Command("Atras", Command.BACK, 1);
		this.addCommand(cmdAtras);
		this.setCommandListener(this);
	}

	public synchronized void commandAction(Command cmd, Displayable disp) {
		if(cmd == cmdAtras) {
			// Vuelve atrás
			Display d = Display.getDisplay(owner);
			d.setCurrent(previo);
		} 
	}

}