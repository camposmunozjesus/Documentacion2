
package net.gramene.appcoloma;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BeanRespostaTipus7 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BeanRespostaTipus7">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codiEstat" type="{http://www.gramene.net/appcoloma/}CodiEstat" minOccurs="0"/>
 *         &lt;element name="identificadorFitxa" type="{http://www.gramene.net/appcoloma/}ArrayOfIdentificadorActivitat" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BeanRespostaTipus7", propOrder = {
    "codiEstat",
    "identificadorFitxa"
})
public class BeanRespostaTipus7 {

    protected CodiEstat codiEstat;
    protected ArrayOfIdentificadorActivitat identificadorFitxa;

    /**
     * Gets the value of the codiEstat property.
     * 
     * @return
     *     possible object is
     *     {@link CodiEstat }
     *     
     */
    public CodiEstat getCodiEstat() {
        return codiEstat;
    }

    /**
     * Sets the value of the codiEstat property.
     * 
     * @param value
     *     allowed object is
     *     {@link CodiEstat }
     *     
     */
    public void setCodiEstat(CodiEstat value) {
        this.codiEstat = value;
    }

    /**
     * Gets the value of the identificadorFitxa property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfIdentificadorActivitat }
     *     
     */
    public ArrayOfIdentificadorActivitat getIdentificadorFitxa() {
        return identificadorFitxa;
    }

    /**
     * Sets the value of the identificadorFitxa property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfIdentificadorActivitat }
     *     
     */
    public void setIdentificadorFitxa(ArrayOfIdentificadorActivitat value) {
        this.identificadorFitxa = value;
    }

}
