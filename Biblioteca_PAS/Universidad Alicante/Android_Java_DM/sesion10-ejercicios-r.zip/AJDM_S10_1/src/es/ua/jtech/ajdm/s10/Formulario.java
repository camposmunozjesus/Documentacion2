package es.ua.jtech.ajdm.s10;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.InputFilter;
import android.text.SpannableString;
import android.text.Spanned;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

public class Formulario extends Activity{
    /** Called when the activity is first created. */
	Button siguiente;
	EditText dniEditText;
	
	SharedPreferences prefValidacion;
	boolean validacampo;
	boolean validaboton;

	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        //Registrar listener de cambio de preferencias por defecto
        prefValidacion = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        prefValidacion.registerOnSharedPreferenceChangeListener(new OnSharedPreferenceChangeListener() {
			@Override
			public void onSharedPreferenceChanged(SharedPreferences sharedPreferences,
					String key) {
				getPreferenciasDeValidacion();
				Toast.makeText(Formulario.this,
						"Preferencia de validación actualizada",
						Toast.LENGTH_SHORT).show();
			}
		});
		getPreferenciasDeValidacion();
        
        //Asignar comportamiento al botón "Siguiente"
        siguiente = (Button)findViewById(R.id.Button01);
        siguiente.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				savePreferences();
				String dni = dniEditText.getText().toString();
				if(!validaboton || compruebaLetraDNI(dni)){
					Intent i = new Intent(getApplicationContext(),Resumen.class);
					i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					getApplicationContext().startActivity(i);
				}else{
					Toast.makeText(getApplicationContext(), 
							"Letra del DNI incorrecta.", 
							Toast.LENGTH_SHORT).show();
					dniEditText.requestFocus();
					
				}
				
			}
		});
        
        //Asignar filtro para restringir la escritura del DNI
        dniEditText = (EditText)findViewById(R.id.EditText05);
        InputFilter[] filters = new InputFilter[2];
        filters[0] = new InputFilter() {
            public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            if (end > start) {
                String destTxt = dest.toString();
                String resultingTxt = destTxt.substring(0, dstart) + source.subSequence(start, end) + destTxt.substring(dend);
                //Expresión regular que permite tener desde 0 hasta 8
                //dígitos numéricos y a continuación cero o una letras
                if (validacampo && !resultingTxt.matches("^([0-9]{0,7}|[0-9]{8,8}[a-zA-Z]{0,1})$")) {

	                if (source instanceof Spanned) {
	                    SpannableString sp = new SpannableString("");
	                    return sp;
	                } else {
	                    return "";
	                }

                }
                
            }
            return null;
            }
        };
        filters[1] = new InputFilter.AllCaps();
        dniEditText.setFilters(filters);
    }

    private void savePreferences() {
		String nom = ((EditText)findViewById(R.id.EditText02)).getText().toString();
		String ap1 = ((EditText)findViewById(R.id.EditText03)).getText().toString();
		String ap2 = ((EditText)findViewById(R.id.EditText04)).getText().toString();
		String dni = ((EditText)findViewById(R.id.EditText05)).getText().toString();
		int    dia = ((DatePicker)findViewById(R.id.DatePicker01)).getDayOfMonth();
		int    mes = ((DatePicker)findViewById(R.id.DatePicker01)).getMonth();
		int    hora= ((TimePicker)findViewById(R.id.TimePicker01)).getCurrentHour();
		int    min = ((TimePicker)findViewById(R.id.TimePicker01)).getCurrentMinute();
		
		SharedPreferences preferencias = this.getSharedPreferences("preferenciasDNI", Context.MODE_WORLD_WRITEABLE);
		SharedPreferences.Editor pEditor = preferencias.edit();
		pEditor.putString("nom", nom);
		pEditor.putString("ap1", ap1);
		pEditor.putString("ap2", ap2);
		pEditor.putString("dni", dni);
		pEditor.putInt("dia", dia);
		pEditor.putInt("mes", mes);
		pEditor.putInt("hora", hora);
		pEditor.putInt("min", min);
		pEditor.commit();
	}

	private boolean compruebaLetraDNI(String dni) {
		try{
			int num = Integer.parseInt(dni.substring(0, 8));
			char letra = "TRWAGMYFPDXBNJZSQVHLCKE".charAt(num % 23);
			if(dni.charAt(8)!=letra)
				return false;
		}catch(Exception e){
			Log.i("ValidacionDNI", e.getClass().toString());
			return false;
		}
		return true;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.menu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch(item.getItemId()){
		case R.id.item01:
			Intent i = new Intent(Formulario.this, Preferencias.class);
			startActivity(i);
			// A toast is a view containing a quick little message for the user.
			Toast.makeText(Formulario.this,
					"Esto es un ejemplo de preferencias",
					Toast.LENGTH_SHORT).show();
			
			break;
		case R.id.item02:
			Dialog d = new Dialog(Formulario.this);
			d.getWindow().setFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND, 
					WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
			d.setTitle("Acerca de...");
			TextView tv = new TextView(getApplicationContext());
			tv.setText("Esta aplicación realiza una cita ficticia.");
			d.setContentView(tv);
			d.setCanceledOnTouchOutside(true);
			d.show();
			break;
		}
		return true;
	}

	

	private void getPreferenciasDeValidacion(){
		validacampo = prefValidacion.getBoolean("validacampo", true);
		validaboton = prefValidacion.getBoolean("validaboton", true);
	}


}