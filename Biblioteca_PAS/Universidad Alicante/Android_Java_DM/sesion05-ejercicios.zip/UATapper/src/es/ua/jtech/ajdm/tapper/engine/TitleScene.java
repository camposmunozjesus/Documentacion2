/*
 * Titulo.java
 * Copyright (C) 2004 Miguel Angel Lozano
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package es.ua.jtech.ajdm.tapper.engine;

import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.GameCanvas;

import es.ua.jtech.ajdm.tapper.data.*;

// ------------------------------------------------------------------------------------
// 	Escena de titulo
// ------------------------------------------------------------------------------------

public class TitleScene implements Scene
{
	// Posibles transiciones de estado
	public static final int T_CONTINUA = 0;
	public static final int T_JUEGO = 1;
	public static final int T_SALIR = 2;

	// Numero de frames de cada ciclo de animacion y frame de apagado del texto
	public static final int NUM_FRAMES = 10;
	public static final int FRAME_OFF = 7;

	// Frame actual de la animacion
	int frame;

	// Imagenes
	Image titulo;
	Image fondo;
	Image texto;

	int cx, cy; //Center of the screen

	public TitleScene() {
		frame = 0;
		initGraphics();
	}

	private void initGraphics() {

		// Cargamos las imagenes necesarias de los ficheros
		titulo = Resources.img[Resources.IMG_TIT_TITULO];
		cx = CommonData.SCREEN_WIDTH/2;
		cy = CommonData.SCREEN_HEIGHT/2;

	}

	public void tick(int keyState) {

		// Actualizamos el frame actual

		frame = (frame + 1) % NUM_FRAMES;

		// Comprobamos a que estado debemos pasar

		if((keyState & GameCanvas.FIRE_PRESSED)!=0) {
			Resources.midlet.startGame();
		}
	}

	public void render(Graphics g) {
		// Dibuja los gr�ficos en el contexto gr�fico
		g.setColor(255,255,255);
		g.fillRect(0, 0, CommonData.SCREEN_WIDTH, CommonData.SCREEN_HEIGHT);
		// Imagen de fondo
		g.drawImage(titulo, cx, cy, Graphics.VCENTER | Graphics.HCENTER);

		// Texto intermitente
		if(frame<FRAME_OFF) {
			g.setFont(CommonData.GAME_START_FONT);
			g.setColor(CommonData.GAME_START_COLOR);
			g.drawString(CommonData.GAME_START_TEXT, cx,cy+10, Graphics.TOP | Graphics.HCENTER);
		}
	}

}