package es.ua.jtech.daa.serviciomusica;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

public class MiAudioServicio extends Service {

	MediaPlayer mediaPlayer;
	
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		mediaPlayer.start();
		Log.i("SRV", "onStartCommand: mediaplayer started.");
		return Service.START_STICKY;
	}

	@Override
	public void onCreate() {
		super.onCreate();
		Toast.makeText(this,"Servicio creado ...", Toast.LENGTH_LONG).show();
		mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.ubuntu);
		mediaPlayer.setLooping(true);
		Log.i("SRV","onCreate: Servicio creado, mplayer creado.");
	}

	
	@Override
	public void onDestroy() {
		super.onDestroy();
		Toast.makeText(this,"onDestroy: Servicio destruido ...", Toast.LENGTH_LONG).show();
		mediaPlayer.stop();
		Log.i("SRV","Servicio destruido, mplayer stopped.");
	}

	@Override
	public IBinder onBind(Intent arg0) {
		return null;
	}

}
