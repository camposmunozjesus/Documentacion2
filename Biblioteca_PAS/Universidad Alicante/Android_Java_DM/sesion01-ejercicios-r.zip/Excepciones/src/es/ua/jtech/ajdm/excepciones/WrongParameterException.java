package es.ua.jtech.ajdm.excepciones;

public class WrongParameterException extends Exception {

	private static final long serialVersionUID = -3806363177725900891L;

	public WrongParameterException() {
		super();
	}

	public WrongParameterException(String message, Throwable cause) {
		super(message, cause);
	}

	public WrongParameterException(String message) {
		super(message);
	}

	public WrongParameterException(Throwable cause) {
		super(cause);
	}	
}