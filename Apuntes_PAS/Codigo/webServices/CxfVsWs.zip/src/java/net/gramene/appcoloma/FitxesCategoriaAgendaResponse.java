
package net.gramene.appcoloma;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="fitxesCategoriaAgendaResult" type="{http://www.gramene.net/appcoloma/}BeanRespostaTipus2" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "fitxesCategoriaAgendaResult"
})
@XmlRootElement(name = "fitxesCategoriaAgendaResponse")
public class FitxesCategoriaAgendaResponse {

    protected BeanRespostaTipus2 fitxesCategoriaAgendaResult;

    /**
     * Gets the value of the fitxesCategoriaAgendaResult property.
     * 
     * @return
     *     possible object is
     *     {@link BeanRespostaTipus2 }
     *     
     */
    public BeanRespostaTipus2 getFitxesCategoriaAgendaResult() {
        return fitxesCategoriaAgendaResult;
    }

    /**
     * Sets the value of the fitxesCategoriaAgendaResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link BeanRespostaTipus2 }
     *     
     */
    public void setFitxesCategoriaAgendaResult(BeanRespostaTipus2 value) {
        this.fitxesCategoriaAgendaResult = value;
    }

}
