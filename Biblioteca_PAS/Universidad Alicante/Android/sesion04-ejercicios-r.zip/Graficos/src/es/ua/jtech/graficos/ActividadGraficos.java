package es.ua.jtech.graficos;

import android.app.Activity;
import android.opengl.GLSurfaceView;
import android.os.Bundle;

public class ActividadGraficos extends Activity {
	GLSurfaceView vista;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Gr�ficos 2D
        //setContentView(new VistaGraficos(this));
        
        // Gr�ficos 3D
        //setContentView(new VistaGraficos3D(this));
        
        // Gr�ficos 3D con GLSurfaceView
        vista = new GLSurfaceView(this);
        RendererGraficos renderer = new RendererGraficos();
        vista.setRenderer(renderer);
        vista.setOnTouchListener(renderer);
        setContentView(vista);
    }
    
    @Override
    protected void onPause() {
        super.onPause();
        if(vista!=null) {
            vista.onPause();        	
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(vista!=null) {
            vista.onResume();        	
        }
    }
}