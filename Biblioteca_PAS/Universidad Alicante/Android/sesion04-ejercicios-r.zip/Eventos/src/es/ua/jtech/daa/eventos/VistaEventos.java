package es.ua.jtech.daa.eventos;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

public class VistaEventos extends View implements GestureDetector.OnGestureListener, Runnable {

	private final static int MEDIA_ANCHURA_RECTANGULO = 25;
	private final static int MEDIA_ALTURA_RECTANGULO = 25;

	float x, y;
	float vx, vy;
	boolean colorAzul;

	GestureDetector detectorGestos;
	
	public VistaEventos(Context context) {
		super(context);
		
		detectorGestos = new GestureDetector(this);
	}

	private boolean collidesRectangle(float ex, float ey) {
		return ex >= x - MEDIA_ANCHURA_RECTANGULO
				&& ex <= x + MEDIA_ANCHURA_RECTANGULO
				&& ey >= y - MEDIA_ALTURA_RECTANGULO
				&& ey <= y + MEDIA_ALTURA_RECTANGULO;
	}
	
	@Override
	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		super.onSizeChanged(w, h, oldw, oldh);

		x = this.getWidth() / 2;
		y = this.getHeight() / 2;
	}

	@Override
	protected void onDraw(Canvas canvas) {

		Paint paint = new Paint();
		if(colorAzul) {
			paint.setColor(Color.BLUE);			
		} else {
			paint.setColor(Color.RED);						
		}
		paint.setStyle(Style.FILL);

		canvas.drawColor(Color.WHITE);
		canvas.drawRect(x - MEDIA_ANCHURA_RECTANGULO, y - MEDIA_ALTURA_RECTANGULO,
				x + MEDIA_ANCHURA_RECTANGULO, y + MEDIA_ALTURA_RECTANGULO, paint);

		// Vector velocidad
		paint.setColor(Color.RED);
		canvas.drawLine(x, y, x+vx, y+vy, paint);
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {		
		/*
		if (event.getAction() == MotionEvent.ACTION_DOWN) {
			float ex = event.getX();
			float ey = event.getY();

			return collidesRectangle(ex, ey);
			
		} else if (event.getAction() == MotionEvent.ACTION_MOVE) {
			x = event.getX();
			y = event.getY();				

			this.invalidate();
			return true;
		}

		return true;
		*/
		return detectorGestos.onTouchEvent(event);
	}

	public boolean onDown(MotionEvent e) {
		float ex = e.getX();
		float ey = e.getY();

		return collidesRectangle(ex, ey);
	}

	public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
			float velocityY) {
		vx = velocityX;
		vy = velocityY;
		
		Thread t = new Thread(this);
		t.start();			
		
		return true;
	}

	public void onLongPress(MotionEvent e) {
	}

	public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX,
			float distanceY) {
		x = e2.getX();
		y = e2.getY();				

		this.invalidate();
		return true;
	}

	public void onShowPress(MotionEvent e) {
	}

	public boolean onSingleTapUp(MotionEvent e) {
		colorAzul = !colorAzul;
		this.invalidate();
		return true;
	}

	public void run() {
		float deceleracion = 10;

		float vel = (float)Math.sqrt(vx*vx + vy*vy);

		float coseno = (float)vx / vel;
		float seno = (float)vy / vel;
		
		float dx = deceleracion * coseno;
		float dy = deceleracion * seno;

		while(true) {
			x += vx / 50;
			y += vy / 50;			
			
			float newvx = vx - dx;
			float newvy = vy - dy;

			if(newvx * vx <= 0 || newvy * vy <= 0) {
				vx = 0;
				vy = 0;				
				break;
			} else {
				vx = newvx;
				vy = newvy;
			}
			
			this.postInvalidate();
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) { }
		}
	}
}
