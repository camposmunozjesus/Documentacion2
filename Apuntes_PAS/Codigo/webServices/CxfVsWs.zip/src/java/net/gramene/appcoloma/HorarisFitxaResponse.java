
package net.gramene.appcoloma;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="horarisFitxaResult" type="{http://www.gramene.net/appcoloma/}BeanRespostaTipus4" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "horarisFitxaResult"
})
@XmlRootElement(name = "horarisFitxaResponse")
public class HorarisFitxaResponse {

    protected BeanRespostaTipus4 horarisFitxaResult;

    /**
     * Gets the value of the horarisFitxaResult property.
     * 
     * @return
     *     possible object is
     *     {@link BeanRespostaTipus4 }
     *     
     */
    public BeanRespostaTipus4 getHorarisFitxaResult() {
        return horarisFitxaResult;
    }

    /**
     * Sets the value of the horarisFitxaResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link BeanRespostaTipus4 }
     *     
     */
    public void setHorarisFitxaResult(BeanRespostaTipus4 value) {
        this.horarisFitxaResult = value;
    }

}
