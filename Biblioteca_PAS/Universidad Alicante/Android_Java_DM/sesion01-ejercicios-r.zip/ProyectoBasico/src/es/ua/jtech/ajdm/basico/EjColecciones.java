package es.ua.jtech.ajdm.basico;

import java.util.*;

public class EjColecciones
{
	public static void main(String[] args)
	{
		// Creamos un Vector con 10 cadenas 
		Vector<String> v = new Vector<String>();
		for (int i = 0; i < 10; i++)
			v.addElement("Hola" + i);
		
		// Recorrido mediante Enumeration
		Enumeration<String> en = v.elements();
		System.out.println("Enumeration");
		while (en.hasMoreElements())
		{
			String s = (String)(en.nextElement());
			System.out.println(s);
		}
		
		// Recorrido mediante Iterator
		Iterator<String> it = v.iterator();
		System.out.println("Iterator");
		while (it.hasNext())
		{
			String s = (String)(it.next());
			System.out.println(s);
		}
		
		// Recorrido mediante un bucle for, accediendo a mano a cada posición del vector
		System.out.println("A mano");
		for (int i = 0; i < v.size(); i++)
		{
			String s = (String)(v.elementAt(i));
			System.out.println(s);
		}
	}
}