package es.ua.jtech.ajdm.s10;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;


import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.AdapterView.OnItemSelectedListener;

public class Resumen extends MapActivity {
	TextView tv;
	Spinner spinner;
	Button botonWeb;
	MapView mapView;
	MapController mapController;
	Activity a;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
    	requestWindowFeature(Window.FEATURE_PROGRESS);
		a = this; //Guardarme una referencia a la actividad para el progress bar
    	
    	setContentView(R.layout.resumen);
		
    	tv = (TextView)findViewById(R.id.TextViewResumen);
		
		//Cargar preferencias
		SharedPreferences preferencias = this.getSharedPreferences("preferenciasDNI", Context.MODE_WORLD_READABLE);
		String nom = preferencias.getString("nom", "");
		String ap1 = preferencias.getString("ap1", "");
		String ap2 = preferencias.getString("ap2", "");
		String dni = preferencias.getString("dni", "");
		int dia = preferencias.getInt("dia", 0);
		int mes = preferencias.getInt("mes", 0);
		int hora = preferencias.getInt("hora", 0);
		int min = preferencias.getInt("min", 0);
		
		tv.setText(nom+" "+ap1+" "+ap2+", con DNI "+dni+
				", solicita cita para el día "+dia+"/"+mes+
				"  a las "+hora+":"+min+".");

		
        //Configurar visor de google maps
        mapView = (MapView)findViewById(R.id.map);
        mapView.setSatellite(true);
        mapView.setBuiltInZoomControls(true);
        mapController = mapView.getController();
        mapController.setZoom(18);
		
		//Configurar el selector de oficinas
		spinner = (Spinner)findViewById(R.id.Spinner01);
		spinner.setPrompt("Elige una oficina");
		String[] oficinas = {"Alicante","Elche","San Vicente"};
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,oficinas);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				double longitude=0,latitude=0;
				switch(position){
				case 0:longitude = -0.495232; latitude = 38.340688; break;
				case 1:longitude = -0.685809; latitude = 38.26189; break;
				case 2:longitude = -0.52081; latitude = 38.401739; break;
				}
				//Mover el mapa al punto seleccionado
		        GeoPoint p = new GeoPoint((int)(latitude * 1E6), (int)(longitude * 1E6));
		        mapController.animateTo(p);
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				
			}
		});

        
        //Botón WEB que elimina el mapa y el spinner
        botonWeb = (Button)findViewById(R.id.BotonWeb);
        botonWeb.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
		        //Obtener la referencia al Layout de resumen.xml
		        LinearLayout resumenLayout = (LinearLayout)findViewById(R.id.layout_resumen);
		        //Eliminar algunos views:
				resumenLayout.removeView(mapView);
				resumenLayout.removeView((LinearLayout)findViewById(R.id.layout_spinnerboton));
				resumenLayout.removeView((TextView)findViewById(R.id.TextViewOficina));
				//Añadir view de la web:
				//  <WebView android:id="@+id/WebView01" android:layout_width="fill_parent" android:layout_height="wrap_content"/>
				WebView webView = new WebView(getApplicationContext());
				resumenLayout.addView(webView);
				webView.getSettings().setJavaScriptEnabled(true);
		    	webView.loadUrl("http://www.dnielectronico.es/obtencion_del_dnie/renovar.html");
		    	webView.setInitialScale(60);
		    	//Poner barra de progreso:
				a.setProgress(0);
				a.setProgressBarVisibility(true);

		    	webView.setWebChromeClient(new WebChromeClient() {
		     	   public void onProgressChanged(WebView view, int progress) {
		     	       a.setProgress(progress*100);
		     	   }
		     	 });
		    	//Quitar la barra de progreso:
		    	webView.setWebViewClient(new WebViewClient(){
		    		public void onPageFinished(WebView view, String url){
		    			super.onPageFinished(view, url);
		    			a.setProgressBarVisibility(false);
		    		}
		    	});
	
			}
		});
        
		
        
        
        
	}

	@Override
	protected boolean isRouteDisplayed() {
		return false;
	}

}
