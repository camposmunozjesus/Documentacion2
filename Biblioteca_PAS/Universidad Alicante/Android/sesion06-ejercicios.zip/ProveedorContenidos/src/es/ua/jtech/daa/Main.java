package es.ua.jtech.daa;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.View;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.View.OnClickListener;
import android.view.View.OnCreateContextMenuListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class Main extends Activity {
	/** Called when the activity is first created. */
	private TextView textView;
	private EditText editText;
	private Button plegarButton;
	private ContentResolver cr;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		this.textView = (TextView) this.findViewById(R.id.TextView01);
		cr = getContentResolver();
		
		
		//TODO Eliminar todo lo que había en la base de datos.
		
		//TODO Insertar 3 filas con usuarios diferentes

		//Hacer la query:
		textView.append("Usuarios en la base de datos:\n");
		Cursor cursor = getContentResolver().query(UsuariosProvider.CONTENT_URI, null, null, null, null);
		if (cursor.moveToFirst()) {
			do {
				textView.append(cursor.getString(1) + "\n");
			} while (cursor.moveToNext());
		}
		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}
		
		// Botón para plegar el campo de texto
		plegarButton = ((Button)findViewById(R.id.Button02));
		plegarButton.setOnClickListener(new OnClickListener() {
			private boolean desplegado=true;
			public void onClick(View v) {
				if(desplegado){ //Plegar campo de texto
					textView.setLines(1);
					desplegado = false;
					plegarButton.setText(R.string.desplegar);
				}else{ //Desplegarlo
					textView.setLines(textView.getLineCount());
					desplegado = true;
					plegarButton.setText(R.string.plegar);
				}
				
			}
		});
		
		//List View
		ListView lv = (ListView)findViewById(R.id.ListView01);
		cursor = cr.query(UsuariosProvider.CONTENT_URI, null, null, null, null);
		cursor.setNotificationUri(cr, UsuariosProvider.CONTENT_URI);
		SimpleCursorAdapter adapter = new SimpleCursorAdapter(getApplicationContext(), R.layout.textviewlayout, cursor, UsuariosProvider.COLUMNAS, new int[]{R.id.TextView0DeLaLista,R.id.TextViewDeLaLista});
		lv.setAdapter(adapter);

		lv.setOnCreateContextMenuListener(new OnCreateContextMenuListener() {
			public void onCreateContextMenu(ContextMenu menu, View v,
					ContextMenuInfo menuInfo) {
				AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo)menuInfo;
				long id = ((ListView)v).getAdapter().getItemId(info.position);
				
				//TODO Eliminar ese usuario (el de id)
				
				Toast.makeText(getApplicationContext(), "Eliminado el usuario con id="+id, Toast.LENGTH_SHORT).show();
			}
		});
		
		//Inserción:
		editText = (EditText)findViewById(R.id.EditText01);
		Button insertarButton = (Button)findViewById(R.id.Button01);
		insertarButton.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				
				//TODO insertar el nuevo usuario que hay en el editText y mostar la nueva uri en el Toast
				//Uri nuevaUri = 
				editText.setText("");
				//Toast.makeText(getApplicationContext(), "Nuevo: "+nuevaUri.toString(), Toast.LENGTH_SHORT).show();
			}
		});
	}    
    
}