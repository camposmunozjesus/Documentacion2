package es.ua.jtech.ajdm.basico;

import java.util.*;

public class EjColecciones
{
	public static void main(String[] args)
	{
		// Creamos un Vector con 10 cadenas 
		Vector<String> v = new Vector<String>();
		for (int i = 0; i < 10; i++)
			v.addElement("Hola" + i);
		
		// Recorrido mediante Enumeration
		
		// Recorrido mediante Iterator
		
		// Recorrido mediante un bucle for, accediendo a mano a cada posici�n del vector
	}
}