/*
 * Resources.java
 * Copyright (C) 2004 Miguel Angel Lozano
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package es.ua.jtech.ajdm.cdrilo.data;

import java.io.IOException;

import javax.microedition.lcdui.Image;

import es.ua.jtech.ajdm.cdrilo.MIDletCDrilo;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class Resources {

	public static final int IMG_TIT_TITULO = 0;
	public static final int IMG_SPR_CROC = 1;
	public static final int IMG_BG_STAGE_1 = 2;
	public static final int IMG_CAR_TYPE_1 = 3;
	public static final int IMG_CAR_TYPE_2 = 4;
	public static final int IMG_CAR_TYPE_3 = 5;
	public static final int IMG_FACE_LIVES = 6;

	public static Image[] img;
	public static Image splashImage;

	public static MIDletCDrilo midlet;

	private static String[] imgNames =
		{
			"/title.png",
			"/sprite.png",
			"/stage01.png",
			"/car01.png",
			"/car02.png",
			"/car03.png",
			"/face.png"
		};
	private static String splashImageFile = "/logojava.png";
	private static String stageFile = "/stages.dat";

	public static Image getImage(int imgIndex) {
		return img[imgIndex];
	}

	public static void init() throws IOException {
		// Carga imagenes
		loadCommonImages();

		// TODO: Cargar datos de niveles
	}

	public static void initSplash(MIDletCDrilo pMidlet) throws IOException {
		midlet = pMidlet;
		splashImage = Image.createImage(splashImageFile);
	}

	private static void loadCommonImages() throws IOException {
		// Carga imagenes
		int nImg = imgNames.length;

		img = new Image[nImg];

		for (int i = 0; i < nImg; i++) {
			img[i] = Image.createImage(imgNames[i]);
		}
	}
}
