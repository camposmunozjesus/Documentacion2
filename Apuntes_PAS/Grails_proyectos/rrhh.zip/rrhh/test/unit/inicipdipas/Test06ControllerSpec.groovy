package inicipdipas

import grails.test.mixin.TestFor
import rrhh.Test06Controller;
import spock.lang.Specification

/**
 * See the API for {@link grails.test.mixin.web.ControllerUnitTestMixin} for usage instructions
 */
@TestFor(Test06Controller)
class Test06ControllerSpec extends Specification {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
    }
}
