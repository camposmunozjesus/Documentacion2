package es.ua.jtech.productos;

import java.io.*;
import java.util.Scanner;

public class MenuPrincipal {

	GestorProductos gp;
	Scanner s;

	public MenuPrincipal() {
		gp = new GestorProductos();
		s = new Scanner(System.in);
	}

	public void menu() {
		while(true) {
			System.out.println("(1) Ver productos");
			System.out.println("(2) Nuevo producto");
			System.out.println("(3) Eliminar producto");
			System.out.println("(0) Salir");

			String opcion = s.nextLine();

			if(opcion.trim().equals("1")) {
				listaProductos();
			} else if(opcion.trim().equals("2")) {
				datosProducto();
			} else if(opcion.trim().equals("3")) {
				eliminaProducto(); 
			} else if(opcion.trim().equals("0")) {
				salir();
			} else {
				System.out.println("Opcion invalida");
			}
		}
	}
	
	public void salir() {
		try {
			gp.guardar();
		} catch(IOException e) {
			System.err.println("Error al guardar los datos");
		}
		
		System.exit(0);
	}
	
	public void datosProducto() {		
		
		System.out.println("Titulo: ");
		String titulo = s.nextLine();
		System.out.println("Autor: ");
		String autor = s.nextLine();
		System.out.println("Precio: ");
		
		float precio = 0.0f;
		while(true) {
			String linea = s.nextLine();
			try {
				precio = Float.parseFloat(linea);
				break;
			} catch(Exception e) {
				System.err.println("Introduzca un numero correcto: ");
			}
		}
		
		System.out.println("Disponible (s/n): ");
		boolean disponible = false;
		while(true) {
			String linea = s.nextLine();
			if(linea.toUpperCase().startsWith("S")) {
				disponible = true;
				break;
			} else if(linea.toUpperCase().startsWith("N")) {
				disponible = false;
				break;
			} else {
				System.err.println("Introduzca (s/n): ");
			}
		}
		
		gp.nuevoProducto(new ProductoTO(titulo, autor, precio, disponible));
	}
	
	public void listaProductos() {
		
		for(ProductoTO p: gp.obtenerProductos()) {
			System.out.println("============");
			System.out.println(p);
			System.out.println();
		}
	}
	
	public void eliminaProducto() {
		System.out.println("Indice del producto a eliminar: ");
		
		int indice = 0;
		while(true) {
			String linea = s.nextLine();
			try {
				indice = Integer.parseInt(linea);
				break;
			} catch(Exception e) {
				System.err.println("Introduzca un numero correcto: ");
			}
		}
		
		try {
			gp.eliminaProducto(indice);
		} catch(Exception e) {
			System.err.println("Error: No se puede eliminar el producto");
		}
	}
	
	public static void main(String [] args) {
		MenuPrincipal mp = new MenuPrincipal();
		mp.menu();
	}
}
