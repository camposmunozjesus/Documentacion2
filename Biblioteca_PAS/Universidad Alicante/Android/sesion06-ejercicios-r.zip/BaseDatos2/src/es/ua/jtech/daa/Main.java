package es.ua.jtech.daa;

import java.net.URI;
import java.util.List;

import android.app.Activity;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;

public class Main extends Activity {
	/** Called when the activity is first created. */
	private TextView textView;
	private DataHelper dataHelper;
	private UsuariosProvider provider;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		this.textView = (TextView) this.findViewById(R.id.TextView01);

		this.dataHelper = new DataHelper(this);
		
		dataHelper.deleteAll();
		dataHelper.insert("Pablo");
		dataHelper.insert("Boyan");
		dataHelper.insert("Miguel Angel");
		List<String> listado = dataHelper.selectAll();
		for (int i=0;i<listado.size();i++) {
			textView.append(listado.get(i) + "\n");
		}
		
		Cursor cursor = getContentResolver().query(UsuariosProvider.CONTENT_URI, null, null, null, null);
		if (cursor.moveToFirst()) {
			do {
				textView.append(cursor.getString(1) + "\n");
			} while (cursor.moveToNext());
		}
		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}
	}    
    
}