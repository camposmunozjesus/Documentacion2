//
//  UAMasterViewController.m
//  Filmoteca
//
//  Created by Miguel Angel Lozano on 15/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "UAMasterViewController.h"

#import "UADetailViewController.h"
#import "UAPelicula.h"

@implementation UAMasterViewController

@synthesize detailViewController = _detailViewController;
@synthesize peliculas = _peliculas;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = [NSLocalizedString(@"Titulo", @"Filmoteca") uppercaseString];
                
        UAPelicula *pelicula1 = [[UAPelicula alloc] initWithTitulo:@"El Resplandor"];
        pelicula1.cartel = [UIImage imageNamed:@"resplandor.jpg"];
        UAPelicula *pelicula2 = [[UAPelicula alloc] initWithTitulo:@"Malditos Bastardos"];
        pelicula2.cartel = [UIImage imageNamed:@"bastardos.jpg"];
        pelicula2.calificacion = NR18;
        UAPelicula *pelicula3 = [[UAPelicula alloc] initWithTitulo:@"Robocop"];
        pelicula3.cartel = [UIImage imageNamed:@"robocop.jpg"];
        pelicula3.calificacion = NR13;
        
        self.peliculas = [NSArray arrayWithObjects:pelicula1, pelicula2, pelicula3, nil];
    }
    return self;
}
							

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

// Customize the number of sections in the table view.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.peliculas count];
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;

        UISwitch *interruptor = [[UISwitch alloc] init];
        cell.accessoryView = interruptor;
        
        [interruptor addTarget: self action:@selector(cambioInterruptor:) forControlEvents:UIControlEventValueChanged];
    }

    // Configure the cell.
    UAPelicula *pelicula = [self.peliculas objectAtIndex: indexPath.row];
    cell.textLabel.text = pelicula.titulo; //[NSString stringWithFormat: NSLocalizedString(@"Item", @"Posicion %d"), [indexPath row]];     
    cell.imageView.image = pelicula.cartel;

    return cell;
}

- (IBAction)cambioInterruptor:(id)sender {
    UISwitch *interruptor = sender;
    UITableViewCell *celda = (UITableViewCell*)interruptor.superview;
    
    if(interruptor.on) {
        celda.textLabel.textColor = [UIColor redColor];
        celda.backgroundColor = [UIColor lightGrayColor];
    } else {
        celda.textLabel.textColor = [UIColor blackColor];
        celda.backgroundColor = [UIColor whiteColor];
    }
    //[self.tableView reloadData];
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source.
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (!self.detailViewController) {
        self.detailViewController = [[UADetailViewController alloc] initWithNibName:@"UADetailViewController" bundle:nil];
    }
    self.detailViewController.pelicula = [self.peliculas objectAtIndex: indexPath.row];
    [self.navigationController pushViewController:self.detailViewController animated:YES];
}

@end
