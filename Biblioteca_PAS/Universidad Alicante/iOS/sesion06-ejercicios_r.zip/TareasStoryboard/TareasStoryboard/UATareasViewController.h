//
//  UATareasViewController.h
//  TareasStoryboard
//
//  Created by Miguel Angel Lozano on 08/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UATareaViewController.h"

@interface UATareasViewController : UITableViewController<UATareaViewControllerDelegate>

@property (nonatomic, strong) NSMutableArray *tareas;

- (IBAction)addTarea:(id)sender;

@end
