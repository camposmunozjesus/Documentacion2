
package net.gramene.appcoloma;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BeanRespostaTipus4 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BeanRespostaTipus4">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codiEstat" type="{http://www.gramene.net/appcoloma/}CodiEstat" minOccurs="0"/>
 *         &lt;element name="fitxaHorari" type="{http://www.gramene.net/appcoloma/}ArrayOfFitxaHorari" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BeanRespostaTipus4", propOrder = {
    "codiEstat",
    "fitxaHorari"
})
public class BeanRespostaTipus4 {

    protected CodiEstat codiEstat;
    protected ArrayOfFitxaHorari fitxaHorari;

    /**
     * Gets the value of the codiEstat property.
     * 
     * @return
     *     possible object is
     *     {@link CodiEstat }
     *     
     */
    public CodiEstat getCodiEstat() {
        return codiEstat;
    }

    /**
     * Sets the value of the codiEstat property.
     * 
     * @param value
     *     allowed object is
     *     {@link CodiEstat }
     *     
     */
    public void setCodiEstat(CodiEstat value) {
        this.codiEstat = value;
    }

    /**
     * Gets the value of the fitxaHorari property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfFitxaHorari }
     *     
     */
    public ArrayOfFitxaHorari getFitxaHorari() {
        return fitxaHorari;
    }

    /**
     * Sets the value of the fitxaHorari property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfFitxaHorari }
     *     
     */
    public void setFitxaHorari(ArrayOfFitxaHorari value) {
        this.fitxaHorari = value;
    }

}
