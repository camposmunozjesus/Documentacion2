
package net.gramene.appcoloma;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DocImg complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DocImg">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="intIdFitxa" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="intIdNivell" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="intIdioma" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="strDescripcio" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="intIdNivellRef" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="strExtensio" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="strURL" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DocImg", propOrder = {
    "intIdFitxa",
    "intIdNivell",
    "intIdioma",
    "strDescripcio",
    "intIdNivellRef",
    "strExtensio",
    "strURL"
})
public class DocImg {

    protected long intIdFitxa;
    protected short intIdNivell;
    protected short intIdioma;
    protected String strDescripcio;
    protected short intIdNivellRef;
    protected String strExtensio;
    protected String strURL;

    /**
     * Gets the value of the intIdFitxa property.
     * 
     */
    public long getIntIdFitxa() {
        return intIdFitxa;
    }

    /**
     * Sets the value of the intIdFitxa property.
     * 
     */
    public void setIntIdFitxa(long value) {
        this.intIdFitxa = value;
    }

    /**
     * Gets the value of the intIdNivell property.
     * 
     */
    public short getIntIdNivell() {
        return intIdNivell;
    }

    /**
     * Sets the value of the intIdNivell property.
     * 
     */
    public void setIntIdNivell(short value) {
        this.intIdNivell = value;
    }

    /**
     * Gets the value of the intIdioma property.
     * 
     */
    public short getIntIdioma() {
        return intIdioma;
    }

    /**
     * Sets the value of the intIdioma property.
     * 
     */
    public void setIntIdioma(short value) {
        this.intIdioma = value;
    }

    /**
     * Gets the value of the strDescripcio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrDescripcio() {
        return strDescripcio;
    }

    /**
     * Sets the value of the strDescripcio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrDescripcio(String value) {
        this.strDescripcio = value;
    }

    /**
     * Gets the value of the intIdNivellRef property.
     * 
     */
    public short getIntIdNivellRef() {
        return intIdNivellRef;
    }

    /**
     * Sets the value of the intIdNivellRef property.
     * 
     */
    public void setIntIdNivellRef(short value) {
        this.intIdNivellRef = value;
    }

    /**
     * Gets the value of the strExtensio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrExtensio() {
        return strExtensio;
    }

    /**
     * Sets the value of the strExtensio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrExtensio(String value) {
        this.strExtensio = value;
    }

    /**
     * Gets the value of the strURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrURL() {
        return strURL;
    }

    /**
     * Sets the value of the strURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrURL(String value) {
        this.strURL = value;
    }

}
