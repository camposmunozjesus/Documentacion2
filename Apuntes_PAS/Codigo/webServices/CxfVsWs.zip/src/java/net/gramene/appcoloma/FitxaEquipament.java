
package net.gramene.appcoloma;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FitxaEquipament complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FitxaEquipament">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="intIdFitxa" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="intIdNivell" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="intIdNivellRelacionat" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="intDistricte" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="strBarri" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="strDescripcioCarrer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="strNumeroCarrer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="strDescripcioProvincia" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="strDescripcioPoblacio" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="strCodiPostal" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="strNomResponsable" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="strCognomsResponsable" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="strCentre" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="strTelefonA" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="strTelefonB" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="strTelefonC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="strFax" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="strUrl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FitxaEquipament", propOrder = {
    "intIdFitxa",
    "intIdNivell",
    "intIdNivellRelacionat",
    "intDistricte",
    "strBarri",
    "strDescripcioCarrer",
    "strNumeroCarrer",
    "strDescripcioProvincia",
    "strDescripcioPoblacio",
    "strCodiPostal",
    "strNomResponsable",
    "strCognomsResponsable",
    "strCentre",
    "strTelefonA",
    "strTelefonB",
    "strTelefonC",
    "strFax",
    "strUrl"
})
public class FitxaEquipament {

    protected long intIdFitxa;
    protected short intIdNivell;
    protected short intIdNivellRelacionat;
    protected short intDistricte;
    protected String strBarri;
    protected String strDescripcioCarrer;
    protected String strNumeroCarrer;
    protected String strDescripcioProvincia;
    protected String strDescripcioPoblacio;
    protected String strCodiPostal;
    protected String strNomResponsable;
    protected String strCognomsResponsable;
    protected String strCentre;
    protected String strTelefonA;
    protected String strTelefonB;
    protected String strTelefonC;
    protected String strFax;
    protected String strUrl;

    /**
     * Gets the value of the intIdFitxa property.
     * 
     */
    public long getIntIdFitxa() {
        return intIdFitxa;
    }

    /**
     * Sets the value of the intIdFitxa property.
     * 
     */
    public void setIntIdFitxa(long value) {
        this.intIdFitxa = value;
    }

    /**
     * Gets the value of the intIdNivell property.
     * 
     */
    public short getIntIdNivell() {
        return intIdNivell;
    }

    /**
     * Sets the value of the intIdNivell property.
     * 
     */
    public void setIntIdNivell(short value) {
        this.intIdNivell = value;
    }

    /**
     * Gets the value of the intIdNivellRelacionat property.
     * 
     */
    public short getIntIdNivellRelacionat() {
        return intIdNivellRelacionat;
    }

    /**
     * Sets the value of the intIdNivellRelacionat property.
     * 
     */
    public void setIntIdNivellRelacionat(short value) {
        this.intIdNivellRelacionat = value;
    }

    /**
     * Gets the value of the intDistricte property.
     * 
     */
    public short getIntDistricte() {
        return intDistricte;
    }

    /**
     * Sets the value of the intDistricte property.
     * 
     */
    public void setIntDistricte(short value) {
        this.intDistricte = value;
    }

    /**
     * Gets the value of the strBarri property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrBarri() {
        return strBarri;
    }

    /**
     * Sets the value of the strBarri property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrBarri(String value) {
        this.strBarri = value;
    }

    /**
     * Gets the value of the strDescripcioCarrer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrDescripcioCarrer() {
        return strDescripcioCarrer;
    }

    /**
     * Sets the value of the strDescripcioCarrer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrDescripcioCarrer(String value) {
        this.strDescripcioCarrer = value;
    }

    /**
     * Gets the value of the strNumeroCarrer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrNumeroCarrer() {
        return strNumeroCarrer;
    }

    /**
     * Sets the value of the strNumeroCarrer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrNumeroCarrer(String value) {
        this.strNumeroCarrer = value;
    }

    /**
     * Gets the value of the strDescripcioProvincia property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrDescripcioProvincia() {
        return strDescripcioProvincia;
    }

    /**
     * Sets the value of the strDescripcioProvincia property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrDescripcioProvincia(String value) {
        this.strDescripcioProvincia = value;
    }

    /**
     * Gets the value of the strDescripcioPoblacio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrDescripcioPoblacio() {
        return strDescripcioPoblacio;
    }

    /**
     * Sets the value of the strDescripcioPoblacio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrDescripcioPoblacio(String value) {
        this.strDescripcioPoblacio = value;
    }

    /**
     * Gets the value of the strCodiPostal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrCodiPostal() {
        return strCodiPostal;
    }

    /**
     * Sets the value of the strCodiPostal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrCodiPostal(String value) {
        this.strCodiPostal = value;
    }

    /**
     * Gets the value of the strNomResponsable property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrNomResponsable() {
        return strNomResponsable;
    }

    /**
     * Sets the value of the strNomResponsable property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrNomResponsable(String value) {
        this.strNomResponsable = value;
    }

    /**
     * Gets the value of the strCognomsResponsable property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrCognomsResponsable() {
        return strCognomsResponsable;
    }

    /**
     * Sets the value of the strCognomsResponsable property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrCognomsResponsable(String value) {
        this.strCognomsResponsable = value;
    }

    /**
     * Gets the value of the strCentre property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrCentre() {
        return strCentre;
    }

    /**
     * Sets the value of the strCentre property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrCentre(String value) {
        this.strCentre = value;
    }

    /**
     * Gets the value of the strTelefonA property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrTelefonA() {
        return strTelefonA;
    }

    /**
     * Sets the value of the strTelefonA property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrTelefonA(String value) {
        this.strTelefonA = value;
    }

    /**
     * Gets the value of the strTelefonB property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrTelefonB() {
        return strTelefonB;
    }

    /**
     * Sets the value of the strTelefonB property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrTelefonB(String value) {
        this.strTelefonB = value;
    }

    /**
     * Gets the value of the strTelefonC property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrTelefonC() {
        return strTelefonC;
    }

    /**
     * Sets the value of the strTelefonC property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrTelefonC(String value) {
        this.strTelefonC = value;
    }

    /**
     * Gets the value of the strFax property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrFax() {
        return strFax;
    }

    /**
     * Sets the value of the strFax property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrFax(String value) {
        this.strFax = value;
    }

    /**
     * Gets the value of the strUrl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrUrl() {
        return strUrl;
    }

    /**
     * Sets the value of the strUrl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrUrl(String value) {
        this.strUrl = value;
    }

}
