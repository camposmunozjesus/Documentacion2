
package net.gramene.appcoloma;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="detallsFitxaEquipamentResult" type="{http://www.gramene.net/appcoloma/}BeanRespostaTipus6" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "detallsFitxaEquipamentResult"
})
@XmlRootElement(name = "detallsFitxaEquipamentResponse")
public class DetallsFitxaEquipamentResponse {

    protected BeanRespostaTipus6 detallsFitxaEquipamentResult;

    /**
     * Gets the value of the detallsFitxaEquipamentResult property.
     * 
     * @return
     *     possible object is
     *     {@link BeanRespostaTipus6 }
     *     
     */
    public BeanRespostaTipus6 getDetallsFitxaEquipamentResult() {
        return detallsFitxaEquipamentResult;
    }

    /**
     * Sets the value of the detallsFitxaEquipamentResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link BeanRespostaTipus6 }
     *     
     */
    public void setDetallsFitxaEquipamentResult(BeanRespostaTipus6 value) {
        this.detallsFitxaEquipamentResult = value;
    }

}
