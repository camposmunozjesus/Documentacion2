package es.ua.jtech.daa.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class Actividad2 extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView texto = new TextView(this);
        texto.setText("Actividad2");
        setContentView(texto);
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
    	super.onCreateOptionsMenu(menu);
    	
    	MenuItem actividad2 = menu.add(0,1,Menu.NONE,"Actividad1");
    	actividad2.setIcon(R.drawable.icono1);
    	actividad2.setIntent(new Intent(this, Actividad1.class));
    	MenuItem actividad3 = menu.add(0,2,Menu.NONE,"Actividad3");
    	actividad3.setIcon(R.drawable.icono3);
    	actividad3.setIntent(new Intent(this, Actividad3.class)); 
    	
    	return true;
    }
}