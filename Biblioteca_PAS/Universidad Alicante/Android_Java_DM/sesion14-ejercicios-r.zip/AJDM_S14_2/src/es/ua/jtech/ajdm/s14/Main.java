package es.ua.jtech.ajdm.s14;

import java.util.List;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;

public class Main extends Activity {
	/** Called when the activity is first created. */
	private TextView textView;
	private DataHelper dataHelper;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		this.textView = (TextView) this.findViewById(R.id.TextView01);

		this.dataHelper = new DataHelper(this);
		this.dataHelper.deleteAll();
		this.dataHelper.insert("boyan");
		this.dataHelper.insert("root");
		this.dataHelper.insert("guest");
		List<String> usuarios = this.dataHelper.selectAll();
		textView.append("Usuarios en la base de datos:\n");
		for (String name : usuarios) {
			textView.append(name + "\n");
		}
		
		textView.append("ContentProvider devuelve:\n");
		//Content provider
		//NOTA: UsuariosProvider NO necesita el DataHelper.
		//      Son dos formas diferentes de acceder a la BD.
		Cursor cursor = getContentResolver().query(UsuariosProvider.CONTENT_URI, null, null, null, null);
		if (cursor.moveToFirst()) {
			do {
				textView.append(cursor.getString(1) + "\n");
			} while (cursor.moveToNext());
		}
		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}
		
		
	}    
    
}