
package student.protocols;

import ast.protocols.ip.IPPacket;
import ast.protocols.transportCO.TProtocol;
import ast.protocols.transportCO.TCBlock;
import ast.protocols.tcp.TCPSegment;

import ast.util.CircularQueue;
import ast.util.ByteQueue;

import java.io.IOException;


/**
 * Connection oriented, no control flow, unreliable.
 * We assume an ideal IP layer with no losses and no errors in packets.
 *
 * State diagram:<pre>
                              +---------+
                              |  CLOSED |-------------
                              +---------+             \
                           LISTEN  |                   \
                           ------  |                    | CONNECT
                                   V                    | -------
                              +---------+               | snd SYN
                              |  LISTEN |               |
                              +---------+          +----------+
                                   |               | SYN_SENT |
                                   |               +----------+
                         rcv SYN   |                    |
                         -------   |                    | rcv SYN
                         snd SYN   |                    | -------
                                   |                    |
                                   V                   /
                              +---------+             /
                              |  ESTAB  |<------------
                              +---------+
                       CLOSE    |     |    rcv FIN
                      -------   |     |    -------
 +---------+          snd FIN  /       \                    +---------+
 |  FIN    |<-----------------           ------------------>|  CLOSE  |
 |  WAIT   |------------------           -------------------|  WAIT   |
 +---------+          rcv FIN  \       /   CLOSE            +---------+
                      -------   |      |  -------
                                |      |  snd FIN 
                                V      V
                              +----------+
                              |  CLOSED  |
                              +----------+
 * </pre>
 */
public class TProtocol_Unreliable1 extends TProtocol {
    @Override
    protected TCBlock newTCB(int port) {
        // Create an instance of TCBlock which implements desired protocol
        return new TCBlock_Unreliable1(this, port);
    }

    // We expect PROTO_NUM is not used by other registered protocols
    public static final int PROTO_NUM = 201;

    @Override
    public int getProtoNum() { return PROTO_NUM; }

    @Override
    public void ipInput(IPPacket packet) {
        // To be completed by the student:
        throw new RuntimeException("NOT YET IMPLEMENTED (To be completed by the student)");
        // Compute and verify TCP checksum
        //...
        // Search matching TCB
        //...
        // Process received segment
        //...
    }

    @Override
    protected void sendSegmentTo(TCPSegment segment, int localAddr, int remoteAddr) {
        // compute and set checksum
            segment.setChecksum(0);
            segment.computeChecksum(localAddr, remoteAddr, getProtoNum());
        // To be completed by the student:
        throw new RuntimeException("NOT YET IMPLEMENTED (To be completed by the student)");
    }
}


class TCBlock_Unreliable1 extends TCBlock {
    protected int state;
    protected CircularQueue<TCBlock_Unreliable1> acceptQueue;
    protected ByteQueue rcvQueue;

    // States of FSM (see description in TProtocol_Unreliable1):
    protected final static int CLOSED = 0,
                               LISTEN = 1,
                               SYN_SENT = 2,
                               ESTABLISHED = 3,
                               FIN_WAIT = 4,
                               CLOSE_WAIT = 5;

    TCBlock_Unreliable1(TProtocol proto, int port) {
        super(proto, port);
    }

    // Passive open
    @Override
    public void listen(int backlog) throws IOException {
      lk.lock();
      try {
        log.debug("%1$s->listen()", this);
        if (state != CLOSED) {
            throw new IOException("connection already exists");
        }
        acceptQueue = new CircularQueue<TCBlock_Unreliable1>(backlog);
        state = LISTEN;
        addListenTCB(this);
        logDebugState();
      } finally {
        lk.unlock();
      }
    }

    @Override
    public TCBlock accept() throws IOException {
      lk.lock();
      try {
        log.debug("%1$s->accept()", this);
        if (state != LISTEN) {
            throw new IOException("connection is not LISTEN");
        }
        try {
            // wait some client to connect to me
            while (acceptQueue.empty()) appCV.await();
        } catch (InterruptedException ie) {
            log.warn("Interrupted Exception at accept()");
        }
        TCBlock_Unreliable1 r = acceptQueue.get();
        log.debug("%1$s->accepted", this);
        return r;
      } finally {
        lk.unlock();
      }
    }

    // Active open
    @Override
    public void connect(int addr, int port) throws IOException {
      lk.lock();
      try {
        log.debug("%1$s->connect()", this);
        if (state != CLOSED) {
            throw new IOException("connection already exists");
        }
        initActive(addr, port & 0xffff, SYN_SENT);
        TCPSegment sseg = new TCPSegment();
        sseg.setSourcePort(localPort);
        sseg.setDestinationPort(remotePort);
        sseg.setFlags(TCPSegment.SYN);
        sendSegment(sseg);
        logDebugState();
        try {
            while (state != ESTABLISHED) appCV.await(); // wait SYN is received
        } catch (InterruptedException ie) {
            log.warn("Interrupted Exception in connect()");
        }
        log.debug("%1$s->connected", this);
      } finally {
        lk.unlock();
      }
    }

    // initialize for new connection
    protected void initActive(int remAddr, int remPort, int st) {
        remoteAddr = remAddr;
        remotePort = remPort;
        state = st;
        rcvQueue = new ByteQueue(1000);
        addActiveTCB(this);
    }

    @Override
    public void close() throws IOException {
        lk.lock();
        try {
          log.debug("%1$s->close()", this);
          switch (state) {
            case LISTEN: {
                state = CLOSED;
                removeListenTCB(this);
                logDebugState();
                break;
            }
            case ESTABLISHED:
            case CLOSE_WAIT: {
                TCPSegment sseg = new TCPSegment();
                sseg.setSourcePort(localPort);
                sseg.setDestinationPort(remotePort);
                sseg.setFlags(TCPSegment.FIN);
                sendSegment(sseg);
                if (state == ESTABLISHED) {
                    state = FIN_WAIT;
                } else {
                    state = CLOSED;
                    removeActiveTCB(this);
                }
                logDebugState();
                break;
            }
            default:
                throw new IOException("connection does not exist");
          }
        } finally {
            lk.unlock();
        }
    }

    @Override
    public void sendData(byte[] data, int data_off, int data_len) throws IOException {
        // To be completed by the student:
        throw new RuntimeException("NOT YET IMPLEMENTED (To be completed by the student)");
    }

    @Override
    protected void processReceivedSegment(int sourceAddr, TCPSegment rseg) {
        lk.lock();
        try{
            switch (state) {
            case LISTEN: {
                if (rseg.isSyn()) {
                    if (acceptQueue.full()) {
                        log.warn(
                          "%1$s->processReceivedSegment: Backlog queue is full. SYN IS LOST !!!",
                          this);
                        return;
                    }
                    // create TCB for new connection
                    TCBlock_Unreliable1 ntcb = (TCBlock_Unreliable1) newTCB();
                    ntcb.initActive(sourceAddr, rseg.getSourcePort(), ESTABLISHED);
                    // To be completed by the student:
                    throw new RuntimeException("NOT YET IMPLEMENTED (To be completed by the student)");
                    // prepare the created connection for accept
                    //...
                    // send SYN segment for new connection
                    //...
                    ntcb.logDebugState();
                }
                break;
            }
            case SYN_SENT: {
                if (rseg.isSyn()) {
                    // To be completed by the student:
                    throw new RuntimeException("NOT YET IMPLEMENTED (To be completed by the student)");
                    // Change state and wake up connect() thread
                    //...
                    logDebugState();
                }
                break;
            }
            case ESTABLISHED:
            case FIN_WAIT:
            case CLOSE_WAIT: {
                // Check SYN bit
                if (rseg.isSyn()) {
                    // A SYN is bad if it arrives on a connection in an active state. Ignore it
                    return;
                }
                // Process segment text
                if (rseg.getDataLength() > 0) {
                    if (state == ESTABLISHED || state == FIN_WAIT) {
                        // To be completed by the student:
                        throw new RuntimeException("NOT YET IMPLEMENTED (To be completed by the student)");
                        logDebugState();
                    } else {
                        // This should not occur, since a FIN has been received from the
                        // remote side.  Ignore the segment text.
                    }
                }
                // Check FIN bit
                if (rseg.isFin()) {
                    if (state == ESTABLISHED) {
                        state = CLOSE_WAIT;
                    } else if (state == FIN_WAIT) {
                        state = CLOSED;
                        removeActiveTCB(this);
                    }
                    appCV.signalAll(); // wake up receiveData() thread
                    logDebugState();
                }
                break;
            }
            default:
                // Segment is ignored
            }
        } finally {
            lk.unlock();
        }
    }

    @Override
    public int receiveData(byte[] buf, int off, int len) throws IOException {
        lk.lock();
        try {
            if (state == ESTABLISHED || state == FIN_WAIT || state == CLOSE_WAIT) {
            } else {
                throw new IOException("connection does not exist");
            }
            // wait until receive buffer is not empty or FIN is received
            while (rcvQueue.empty() && !(state == CLOSE_WAIT || state == CLOSED)) {
                try { appCV.await(); } catch (InterruptedException e) {}
            }
            assert !rcvQueue.empty() || state == CLOSE_WAIT || state == CLOSED;
            if (rcvQueue.empty()) {
                // remote endpoint is closed (state is CLOSE_WAIT or CLOSED)
                return -1;
            } else {
                int r = rcvQueue.get(buf, off, len);
                log.debug("%1$s->receivedData: len=%2$d" , this , r);
                return r;
            }
        } finally {
            lk.unlock();
        }
    }

    protected void logDebugState() {
        if (log.debugEnabled()) {
            log.debug("%1$s=> state: %2$s", this, stateToString());
        }
    }

    public String stateToString() {
        StringBuilder buf = new StringBuilder();
        String sst;
        switch (state) {
            case CLOSED:      sst = "CLOSED"; break;
            case LISTEN:      sst = "LISTEN"; break;
            case SYN_SENT:    sst = "SYN_SENT"; break;
            case ESTABLISHED: sst = "ESTABLISHED"; break;
            case FIN_WAIT:    sst = "FIN_WAIT"; break;
            case CLOSE_WAIT:  sst = "CLOSE_WAIT"; break;
            default: sst = "?";
        }
        buf.append("{").append(sst);
        if (rcvQueue == null) {
            // pasive state
            buf.append(",acceptQueue.size=").append(acceptQueue.size());
        } else {
            // active state
            buf.append(",rcvQueue.size=").append(rcvQueue.size());
        }
        return buf.append("}").toString();
    }

}


