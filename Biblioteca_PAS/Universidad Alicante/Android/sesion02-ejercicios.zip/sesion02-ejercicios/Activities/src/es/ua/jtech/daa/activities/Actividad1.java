package es.ua.jtech.daa.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class Actividad1 extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView texto = new TextView(this);
        texto.setText("Actividad1");
        setContentView(texto);
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
    	super.onCreateOptionsMenu(menu);
    	
    	MenuItem actividad2 = menu.add(0,2,Menu.NONE,"Actividad2");
    	actividad2.setIcon(R.drawable.icono2);
    	/** TODO actividad2.setIntent(new Intent(this, Actividad2.class)); */
    	MenuItem actividad3 = menu.add(0,3,Menu.NONE,"Actividad3");
    	actividad3.setIcon(R.drawable.icono3);
    	/** TODO actividad3.setIntent(new Intent(this, Actividad3.class)); */
    	
    	return true;
    }
}