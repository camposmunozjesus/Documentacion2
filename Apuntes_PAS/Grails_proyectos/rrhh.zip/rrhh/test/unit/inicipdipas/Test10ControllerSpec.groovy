package inicipdipas

import grails.test.mixin.TestFor
import rrhh.Test10Controller;
import spock.lang.Specification

/**
 * See the API for {@link grails.test.mixin.web.ControllerUnitTestMixin} for usage instructions
 */
@TestFor(Test10Controller)
class Test10ControllerSpec extends Specification {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
    }
}
