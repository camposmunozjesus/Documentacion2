package es.ua.jtech.graficos.mesh;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.opengles.GL10;

public class Cubo3D {
	
    private FloatBuffer   buffer;
    private ByteBuffer  bufferIndices;

    float vertices[] = {
            -1.0f, -1.0f, -1.0f,
            1.0f, -1.0f, -1.0f,
            1.0f,  1.0f, -1.0f,
            -1.0f,  1.0f, -1.0f,
            -1.0f, -1.0f,  1.0f,
            1.0f, -1.0f,  1.0f,
            1.0f,  1.0f,  1.0f,
            -1.0f,  1.0f,  1.0f
    };

    byte indices[] = {
            0, 4, 5,    
            0, 5, 1,
            1, 5, 6,    
            1, 6, 2,
            2, 6, 7,    
            2, 7, 3,
            3, 7, 4,    
            3, 4, 0,
            4, 7, 6,    
            4, 6, 5,
            3, 0, 1,    
            3, 1, 2
    };
    
	public Cubo3D() {

        ByteBuffer bufferTemporal = ByteBuffer.allocateDirect(vertices.length*4);
        bufferTemporal.order(ByteOrder.nativeOrder());
        buffer = bufferTemporal.asFloatBuffer();
        buffer.put(vertices);
        buffer.position(0);

        bufferIndices = ByteBuffer.allocateDirect(indices.length);
        bufferIndices.put(indices);
        bufferIndices.position(0);
    }

    public void dibujar(GL10 gl)
    {
        gl.glVertexPointer(3, GL10.GL_FLOAT, 0, buffer);
        gl.glDrawElements(GL10.GL_TRIANGLES, 36, GL10.GL_UNSIGNED_BYTE, bufferIndices);
    }
}
