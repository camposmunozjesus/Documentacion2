//
//  ConfiguracionController.h
//  Filmoteca
//
//  Created by Miguel Angel Lozano on 28/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UAConfiguracionViewController : UIViewController

@end
