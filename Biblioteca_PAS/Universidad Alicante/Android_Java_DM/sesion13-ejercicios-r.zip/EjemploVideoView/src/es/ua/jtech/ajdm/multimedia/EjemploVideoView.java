package es.ua.jtech.ajdm.multimedia;

import es.ua.jtech.ajdm.multimedia.R;

import android.app.Activity;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.VideoView;

public class EjemploVideoView extends Activity {
    /** Called when the activity is first created. */
	
	Button botonIniciar;
	Button botonParar;
	Button botonPausar;
	
	VideoView videoView;
	
	boolean pausado;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        // Accedemos a los botones y dejamos activado tan solo el de iniciar el video
        botonIniciar = (Button)findViewById(R.id.iniciar);
        botonPausar = (Button)findViewById(R.id.pausar);
        botonParar = (Button)findViewById(R.id.parar);
        botonPausar.setEnabled(false);
        botonParar.setEnabled(false);
        
        // Accedemos al control Video View y preparamos el video a reproducir
        videoView = (VideoView)findViewById(R.id.surface);
        videoView.setKeepScreenOn(true);
        videoView.setVideoPath("/sdcard/coche.3gp");
        
        funcionalidadBotones();
    }
    
    // M�todo para inicializar los manejadores de eventos de los botones
    private void funcionalidadBotones() {
    	botonIniciar.setOnClickListener(new OnClickListener () {
    		@Override
    	    public void onClick(View v) {
    	      // Comenzamos el video
    			videoView.seekTo(0);
    			videoView.start();
    			
    		  // Desactivamos el bot�n de inicio y activamos los otros dos
    		  botonIniciar.setEnabled(false);
    		  botonPausar.setEnabled(true);
    		  botonParar.setEnabled(true);
    		  pausado = false;
    		}
    	});
    	
    	botonParar.setOnClickListener(new OnClickListener () {
    		@Override
    	    public void onClick(View v) {
    	      // Comenzamos el video
    			videoView.pause(); // El m�todo stop playback destruye el video
    			
    		  // Desactivamos el bot�n de inicio y activamos los otros dos
    		  botonIniciar.setEnabled(true);
    		  botonPausar.setEnabled(false);
    		  botonParar.setEnabled(false);
    		}
    	});
    	
    	botonPausar.setOnClickListener(new OnClickListener () {
    		@Override
    	    public void onClick(View v) {
    	      if (pausado) {
    	    	  botonPausar.setText(R.string.pausar);
    	    	  videoView.start(); // el m�todo resume no parece funcionar
    	    	  pausado = false;
    	      } else {
    	    	  botonPausar.setText(R.string.reiniciar);
    	    	  videoView.pause();
    	    	  pausado = true;
    	      }
    		}
    	});
    	
    	// Manejador en el caso de terminar el video
    	videoView.setOnCompletionListener(new OnCompletionListener() {
    		@Override
    	    public void onCompletion(MediaPlayer mp) {
    			botonIniciar.setEnabled(true);
    			botonPausar.setEnabled(false);
    			botonParar.setEnabled(false);
    		}
    	});
    }
    
}