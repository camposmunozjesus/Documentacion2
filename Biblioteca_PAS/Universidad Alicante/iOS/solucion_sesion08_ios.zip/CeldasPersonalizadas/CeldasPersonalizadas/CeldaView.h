//
//  CeldaView.h
//  CeldasPersonalizadas
//
//  Created by Javier Aznar on 04/12/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CeldaView : UITableViewCell

@end
