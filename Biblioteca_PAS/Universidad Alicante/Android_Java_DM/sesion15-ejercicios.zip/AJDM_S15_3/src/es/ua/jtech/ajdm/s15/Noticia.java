package es.ua.jtech.ajdm.s15;


public class Noticia {

}
