package es.ua.jtech.daa.eventos;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

public class VistaEventos extends View {

	private final static int MEDIA_ANCHURA_RECTANGULO = 25;
	private final static int MEDIA_ALTURA_RECTANGULO = 25;

	float x, y;

	public VistaEventos(Context context) {
		super(context);
	}

	private boolean collidesRectangle(float ex, float ey) {
		return ex >= x - MEDIA_ANCHURA_RECTANGULO
				&& ex <= x + MEDIA_ANCHURA_RECTANGULO
				&& ey >= y - MEDIA_ALTURA_RECTANGULO
				&& ey <= y + MEDIA_ALTURA_RECTANGULO;
	}
	
	@Override
	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		super.onSizeChanged(w, h, oldw, oldh);

		x = this.getWidth() / 2;
		y = this.getHeight() / 2;
	}

	@Override
	protected void onDraw(Canvas canvas) {

		Paint paint = new Paint();
		paint.setColor(Color.BLUE);			
		paint.setStyle(Style.FILL);

		canvas.drawColor(Color.WHITE);
		canvas.drawRect(x - MEDIA_ANCHURA_RECTANGULO, y - MEDIA_ALTURA_RECTANGULO,
				x + MEDIA_ANCHURA_RECTANGULO, y + MEDIA_ALTURA_RECTANGULO, paint);

	}

}
