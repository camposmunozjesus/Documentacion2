package es.ua.jtech.productos;

public class ProductoTO {

	String titulo;
	String autor;
	float precio;
	boolean stock;

	public ProductoTO(String titulo, String autor, float precio, boolean stock) {
		this.titulo = titulo;
		this.autor = autor;
		this.precio = precio;
		this.stock = stock;
	}
	
	public ProductoTO() {		
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public float getPrecio() {
		return precio;
	}

	public void setPrecio(float precio) {
		this.precio = precio;
	}

	public boolean isStock() {
		return stock;
	}

	public void setStock(boolean stock) {
		this.stock = stock;
	}

	public String toString() {
		String s = "";
		s += "Titulo: \t" + titulo + "\n";
		s += "Autor: \t" + autor + "\n";
		s += "Precio: \t" + precio + "\n";
		s += stock?"En stock":"Agotado" + "\n";
		
		return s;
	}
}
