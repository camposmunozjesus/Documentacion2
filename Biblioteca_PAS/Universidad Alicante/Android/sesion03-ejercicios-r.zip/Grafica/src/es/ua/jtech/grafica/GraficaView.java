package es.ua.jtech.grafica;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Paint.Align;
import android.graphics.Paint.Style;
import android.util.AttributeSet;
import android.view.View;

public class GraficaView extends View {

	private static final int DEFAULT_SIZE = 50;

	private static final int PADDING = 2;

	private static final int LIGHT_RED = 0xffff0000;
	private static final int DARK_RED = 0xff770000;
	private static final int LIGHT_BLUE = 0xff0000ff;
	private static final int DARK_BLUE = 0xff000077;
		
	int percentage = 0;
	
	public GraficaView(Context context) {
		super(context);
	}

	public GraficaView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		this.init(attrs);
	}

	public GraficaView(Context context, AttributeSet attrs) {
		super(context, attrs);
		this.init(attrs);
	}

	private void init(AttributeSet attrs) {
		TypedArray ta = this.getContext().obtainStyledAttributes(attrs, R.styleable.Grafica);
		this.percentage = ta.getInt(R.styleable.Grafica_percentage, 0);
	}
	
	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}
	
	@Override
	protected void onDraw(Canvas canvas) {
		float sweep = (360.0f * percentage) / 100.0f;
		float remainder = 360.0f - sweep;
		
		float centroX = this.getWidth() / 2;
		float centroY = this.getHeight() / 2;
		float radio = Math.min(centroX, centroY) - PADDING;
		
		float left = PADDING;
		float top = PADDING;
		float right = this.getWidth() - PADDING;
		float bottom = this.getHeight() - PADDING;
		RectF area = new RectF(left, top, right, bottom);
		
		Paint p = new Paint();

		// Sector rojo
		p.setStyle(Style.FILL_AND_STROKE);
		p.setShader(new RadialGradient(centroX, centroY, radio, DARK_RED, LIGHT_RED, Shader.TileMode.CLAMP));
		canvas.drawArc(area, 0, sweep, true, p);

		// Sector azul
		p.setShader(new RadialGradient(centroX, centroY, radio, DARK_BLUE, LIGHT_BLUE, Shader.TileMode.CLAMP));
		canvas.drawArc(area, sweep, remainder, true, p);
		
		// Borde rojo
		p.setStyle(Style.STROKE);
		p.setShader(null);
		p.setColor(DARK_RED);
		p.setStrokeWidth(2);
		canvas.drawArc(area, 0, sweep, true, p);

		// Borde azul
		p.setColor(DARK_BLUE);
		canvas.drawArc(area, sweep, remainder, true, p);
		
		// Texto
		String texto = "" + percentage + "%";
		p.setTextAlign(Align.CENTER);
		p.setColor(Color.WHITE);
		p.setAntiAlias(true);
		p.setStrokeWidth(1);
		canvas.drawText(texto, centroX, this.getHeight() - p.descent(), p);
	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		int widthMode = MeasureSpec.getMode(widthMeasureSpec);
        int widthSize = MeasureSpec.getSize(widthMeasureSpec);
		int heightMode = MeasureSpec.getMode(heightMeasureSpec);
        int heightSize = MeasureSpec.getSize(heightMeasureSpec);
        	
        int width = DEFAULT_SIZE;
        int height = DEFAULT_SIZE;
                
        switch(widthMode) {
        case MeasureSpec.EXACTLY:
        	width = widthSize;
        	break;
        case MeasureSpec.AT_MOST:
        	if(width > widthSize) {
        		width = widthSize;
        	}
        	break;
        }

        switch(heightMode) {
        case MeasureSpec.EXACTLY:
        	height = heightSize;
        	break;
        case MeasureSpec.AT_MOST:
        	if(height > heightSize) {
            	height = heightSize;
        	}
        	break;
        }

        this.setMeasuredDimension(width, height);
	}
	
}
